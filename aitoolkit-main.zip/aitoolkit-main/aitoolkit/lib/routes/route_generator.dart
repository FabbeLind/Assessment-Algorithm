import 'package:aitoolkit/features/assessment/screens/assessment_dashboard_screen.dart';
import 'package:aitoolkit/features/assessment/screens/assessment_screen.dart';
import 'package:aitoolkit/features/assessment/screens/assessment_value_selection_screen.dart';
import 'package:aitoolkit/features/assessment/screens/complete_assessment_screen.dart';
import 'package:aitoolkit/features/assessment/screens/start_assessment_screen.dart';
import 'package:aitoolkit/features/dashboard/screens/dashboard_screen.dart';
import 'package:aitoolkit/features/home/screen/home_screen.dart';
import 'package:aitoolkit/features/implementation/screens/create_implementation_screen.dart';
import 'package:aitoolkit/features/implementation/screens/view_edit_implementation_screen.dart';
import 'package:aitoolkit/features/initiatives/screens/initiative_screen.dart';
import 'package:aitoolkit/features/profile/screens/profile_screen.dart';
import 'package:aitoolkit/features/security/screens/roles_screen.dart';
import 'package:aitoolkit/features/security/screens/security_screen.dart';
import 'package:aitoolkit/features/security/screens/users_screen.dart';
import 'package:aitoolkit/routes/route_arguments.dart';
import 'package:aitoolkit/routes/routes.dart';
import 'package:aitoolkit/widgets/default_route_widget.dart';
import 'package:flutter/cupertino.dart';

import '../features/assessment/model/assessment_model.dart';
import '../features/authentication/screens/authentication_screen.dart';

class RouteGenerator {
  static Route<dynamic> generateRoute(RouteSettings settings) {
    var argument = settings.arguments;
    switch (settings.name) {
      case Routes.authScreen:
        return CupertinoPageRoute(
          builder: (_) => const AuthenticationScreen(),
        );
      case Routes.dashBoardScreen:
        return CupertinoPageRoute(
          builder: (_) => const DashBoardScreen(),
        );
      case Routes.homeScreen:
        return CupertinoPageRoute(
          builder: (_) => const HomeScreen(),
        );
      case Routes.profileScreen:
        return CupertinoPageRoute(
          builder: (_) => const ProfileScreen(),
        );
      case Routes.initiativeScreen:
        return CupertinoPageRoute(
          builder: (_) =>
              InitiativeScreen(argument: argument as InitiativeRouteArgument),
        );
      case Routes.createImplementationScreen:
        return CupertinoPageRoute(
          builder: (_) =>
              CreateImplementationScreen(userId: argument as String),
        );
      case Routes.viewEditImplementationScreen:
        return CupertinoPageRoute(
          builder: (_) => const ViewEditImplementationScreen(),
        );
      case Routes.assessmentDashboardScreen:
        return CupertinoPageRoute(
          builder: (_) => AssessmentDashboardScreen(
              argument: argument as AssessmentDashboardRouteArgument),
        );
      case Routes.startAssessmentScreen:
        argument as AssessmentModel;
        return CupertinoPageRoute(
          builder: (_) => StartAssessmentScreen(assessment: argument),
        );
      case Routes.assessmentScreen:
        argument as AssessmentRouteArgument;
        return CupertinoPageRoute(
          builder: (_) => AssessmentScreen(assessmentArgs: argument),
        );
      case Routes.completeAssessmentScreen:
        return CupertinoPageRoute(
          builder: (_) => const CompleteAssessmentScreen(),
        );
      case Routes.assessmentValueSelectionScreen:
        return CupertinoPageRoute(
          builder: (_) => AssessmentValueSelectionScreen(
              argument: argument as AssessmentValueSectionRouteArgument),
        );
      case Routes.securityScreen:
        return CupertinoPageRoute(
          builder: (_) => const SecurityScreen(),
        );
      case Routes.usersScreen:
        return CupertinoPageRoute(
          builder: (_) => const UsersScreen(),
        );
      case Routes.rolesScreen:
        return CupertinoPageRoute(
          builder: (_) => const RolesScreen(),
        );
      default:
        return CupertinoPageRoute(
          builder: (_) => DefaultRouteWidget(screenName: settings.name ?? ""),
        );
    }
  }
}
