class Routes {
  static const String authScreen = 'auth_screen';
  static const String dashBoardScreen = 'dash_board';
  static const String homeScreen = 'home_screen';
  static const String profileScreen = 'profile_screen';
  static const String initiativeScreen = 'initiative_screen';
  static const String createImplementationScreen = 'create_implementation_screen';
  static const String assessmentDashboardScreen = 'assessment_dashboard_screen';
  static const String startAssessmentScreen = 'start_assessment_screen';
  static const String assessmentScreen = 'assessment_screen';
  static const String completeAssessmentScreen = 'complete_assessment_screen';
  static const String viewEditImplementationScreen = 'view_edit_implementation_screen';
  static const String assessmentValueSelectionScreen = 'assessment_value_selection_screen';
  static const String securityScreen = 'security_screen';
  static const String usersScreen = 'users_screen';
  static const String rolesScreen = 'roles_screen';
}
