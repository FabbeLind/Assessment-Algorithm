import 'package:aitoolkit/features/assessment/model/report_model.dart';
import 'package:app_utils/app_utils.dart';

import '../features/assessment/entities/assessment_answer_model.dart';
import '../features/assessment/model/assessment_model.dart';
import '../features/initiatives/model/initiative_model.dart';

class AssessmentRouteArgument {
  final bool preview;
  final AssessmentModel assessment;
  final List<AssessmentAnswerModel> assessmentAnswerList;
  final ReportModel? report;

  const AssessmentRouteArgument({
    required this.assessment,
    required this.assessmentAnswerList,
    this.preview = false,
    this.report,
  });
}

class AssessmentValueSectionRouteArgument {
  final AssessmentValueSelectionType selectionType;
  final int defaultIndex;

  const AssessmentValueSectionRouteArgument({
    required this.selectionType,
    this.defaultIndex = -1,
  });
}

class InitiativeRouteArgument {
  final List<InitiativeModel> initiativeList;
  final String implementationId;
  final AppBarStatus status;

  const InitiativeRouteArgument({
    required this.initiativeList,
    required this.implementationId,
    this.status = AppBarStatus.none,
  });
}

class AssessmentDashboardRouteArgument {
  final List<AssessmentModel> assessmentList;
  final String implementationId;

  const AssessmentDashboardRouteArgument({
    required this.assessmentList,
    required this.implementationId,
  });
}
