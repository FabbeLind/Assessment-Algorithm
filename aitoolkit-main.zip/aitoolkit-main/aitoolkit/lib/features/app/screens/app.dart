import 'package:aitoolkit/features/app/bloc/app_bloc.dart';
import 'package:aitoolkit/features/assessment/bloc/assessment_bloc.dart';
import 'package:aitoolkit/features/home/bloc/home_bloc.dart';
import 'package:aitoolkit/features/initiatives/bloc/initiative_bloc.dart';
import 'package:aitoolkit/features/security/bloc/security_bloc.dart';
import 'package:app_utils/app_theme.dart';
import 'package:app_utils/constants/constants.dart';
import 'package:app_utils/utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../routes/route_generator.dart';
import '../../../routes/routes.dart';

class App extends StatelessWidget {
  const App({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider<AppBloc>(create: (context) => AppBloc()..add(AppInitialEvent())),
        BlocProvider<InitiativeBloc>(create: (context) => InitiativeBloc()),
        BlocProvider<AssessmentBloc>(create: (context) => AssessmentBloc()),
        BlocProvider<SecurityBloc>(create: (context) => SecurityBloc()),
        BlocProvider(create: (context) => HomeBloc()),
      ],
      child: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<AppBloc, AppState>(
      buildWhen: (previous, current) => (current is AppUserUpdated) ? false : true,
      builder: (_, state) {
        kNavigatorKey = GlobalKey<NavigatorState>();
        return MaterialApp(
          title: kAppName,
          navigatorKey: kNavigatorKey,
          debugShowCheckedModeBanner: false,
          initialRoute: (state is AppUserLoggedIn) ? Routes.dashBoardScreen : Routes.authScreen,
          onGenerateRoute: RouteGenerator.generateRoute,
          theme: AppThemeData.selectedThemeData,
          builder: (context, child) {
            ScreenUtil.init(
              context,
              designSize: const Size(430, 932),
              splitScreenMode: false,
            );
            return Stack(
              children: [
                GestureDetector(
                  onTap: () {
                    Utils.hideKeyboardInApp(context);
                    Utils.closePopUp();
                  },
                  child: ScrollConfiguration(
                    behavior: const CustomScrollConfiguration(),
                    child: child ?? Container(),
                  ),
                ),
              ],
            );
          },
        );
      },
    );
  }
}

class CustomScrollConfiguration extends ScrollBehavior {
  const CustomScrollConfiguration();

  @override
  ScrollPhysics getScrollPhysics(BuildContext context) {
    switch (getPlatform(context)) {
      case TargetPlatform.iOS:
        return const BouncingScrollPhysics(parent: ClampingScrollPhysics());
      case TargetPlatform.macOS:
      case TargetPlatform.android:
        return const BouncingScrollPhysics();
      case TargetPlatform.fuchsia:
      case TargetPlatform.linux:
      case TargetPlatform.windows:
        return const ClampingScrollPhysics();
    }
  }
}
