import 'dart:async';

import 'package:aitoolkit/storage/app_storage.dart';
import 'package:app_utils/app_utils.dart';
import 'package:bloc/bloc.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';

import '../../authentication/model/user_model.dart';

part 'app_event.dart';
part 'app_state.dart';

class AppBloc extends Bloc<AppEvent, AppState> {
  AppBloc() : super(AppStateInitial()) {
    on<AppInitialEvent>(_appInitialEvent);
    on<AppUserLogoutEvent>(_appUserLogoutEvent);
  }

  UserModel? user;

  Future<void> _appInitialEvent(AppInitialEvent event, Emitter<AppState> emit) async {
    try {
      String? uid = AppStorage.authUid;
      if (uid != null) {
        emit(AppUserLoggedIn());
        DocumentSnapshot userSnapshot = await FirebaseFirestore.instance.collection("Users").doc(uid).get();
        var userData = userSnapshot.data() as Map<String, dynamic>;
        user = UserModel.fromJson(userData);
        emit(AppUserUpdated());
      }
    } catch (e) {
      Debug.log(e);
    }
  }

  Future<void> _appUserLogoutEvent(AppUserLogoutEvent event, Emitter<AppState> emit) async {
    try {
      if (user?.loginType == LoginType.google) {
        GoogleSignIn().signOut();
      }
      await FirebaseAuth.instance.signOut();
      AppStorage.clear();
      emit(AppUserLoggedOut());
    } catch (e) {
      Debug.log(e);
    }
  }
}
