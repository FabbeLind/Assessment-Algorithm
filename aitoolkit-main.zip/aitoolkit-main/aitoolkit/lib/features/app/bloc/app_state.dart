part of 'app_bloc.dart';

abstract class AppState {}

class AppStateInitial extends AppState {}

class AppStateLoading extends AppState {}

class AppUserLoggedIn extends AppState {}

class AppUserLoggedOut extends AppState {}

class AppUserUpdated extends AppState {}
