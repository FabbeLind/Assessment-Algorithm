part of 'app_bloc.dart';

abstract class AppEvent {}

class AppInitialEvent extends AppEvent {}

class AppUserLoginEvent extends AppEvent {}

class AppUserLogoutEvent extends AppEvent {}
