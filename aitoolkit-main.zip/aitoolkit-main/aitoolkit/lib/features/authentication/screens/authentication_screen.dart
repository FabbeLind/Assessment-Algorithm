import 'dart:io';

import 'package:aitoolkit/widgets/loader.dart';
import 'package:aitoolkit/widgets/primary_button.dart';
import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../routes/routes.dart';
import '../../app/bloc/app_bloc.dart';
import '../bloc/auth_bloc.dart';

class AuthenticationScreen extends StatefulWidget {
  const AuthenticationScreen({super.key});

  @override
  State<AuthenticationScreen> createState() => _AuthenticationScreenState();
}

class _AuthenticationScreenState extends State<AuthenticationScreen> with WidgetsBindingObserver {
  @override
  void initState() {
    BlocProvider(create: (context) => AuthBloc());
    WidgetsBinding.instance.addObserver(this);
    super.initState();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      Loader.dismiss(context);
    }
    super.didChangeAppLifecycleState(state);
  }

  @override
  Widget build(BuildContext context) {
    var theme = Theme.of(context).colorScheme;
    AuthBloc authBloc = AuthBloc();

    return Scaffold(
      body: BlocConsumer<AuthBloc, AuthState>(
        bloc: authBloc,
        listener: (context, state) {
          if (state is AuthLoadingState) {
            Loader.show(context);
          } else if (state is AuthSuccessState) {
            context.read<AppBloc>().add(AppInitialEvent());
            Loader.dismiss(context);
            Navigator.pushNamedAndRemoveUntil(
              context,
              Routes.dashBoardScreen,
              (route) => false,
            );
          } else {
            Loader.dismiss(context);
          }
        },
        builder: (context, state) {
          return Container(
            height: context.height,
            width: context.width,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: AppThemeData.primaryGradientColor,
                begin: Alignment.topCenter,
                end: Alignment.bottomRight,
                stops: [0.5, 0.8],
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                _buildAppLogo(),
                SizedBox(height: 36.h),
                _buildAppName(),
                SizedBox(height: 85.h),
                if (Platform.isIOS) ...[
                  _buildAppleButton(authBloc, theme),
                  SizedBox(height: 24.h),
                ],
                _buildGoogleButton(authBloc, theme),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildGoogleButton(AuthBloc authBloc, ColorScheme theme) {
    return PrimaryButton.icon(
      color: theme.secondary,
      label: AppString.signInWithGoogle,
      padding: EdgeInsets.symmetric(vertical: 7.h),
      labelStyle: AppTextStyle.headline.copyWith(height: 1.0),
      width: 218.w,
      height: 40.h,
      icon: AppAsset.google,
      iconSize: 18.h,
      iconSpace: 12.w,
      onPressed: () {
        authBloc.add(AuthGoogleLoginEvent());
      },
    );
  }

  Widget _buildAppleButton(AuthBloc authBloc, ColorScheme theme) {
    return PrimaryButton.icon(
      color: theme.secondary,
      label: AppString.signInWithApple,
      padding: EdgeInsets.symmetric(vertical: 7.h),
      labelStyle: AppTextStyle.headline.copyWith(height: 1.35),
      width: 218.w,
      height: 40.h,
      icon: AppAsset.apple,
      onPressed: () {
        authBloc.add(AuthAppleLoginEvent());
      },
    );
  }

  Widget _buildAppName() {
    return Text(
      AppString.appName,
      style: AppTextStyle.defaultF40W6White,
    );
  }

  Widget _buildAppLogo() {
    return Image.asset(
      AppAsset.appLogo,
      height: 125.w,
      width: 125.w,
      color: AppThemeData.white,
    );
  }
}
