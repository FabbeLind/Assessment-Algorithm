import 'package:app_utils/enums/app_enums.dart';

class UserModel {
  final String uid;
  final String? name;
  final String? email;
  final String? profileImage;
  final LoginType loginType;
  final DateTime createdAt;
  final String accessToken;

  UserModel({
    required this.uid,
    required this.name,
    required this.email,
    required this.profileImage,
    required this.loginType,
    required this.createdAt,
    required this.accessToken,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) => UserModel(
        uid: json["uid"],
        name: json["name"],
        email: json["email"],
        profileImage: json["profileImage"],
        loginType: json["loginType"] == "google" ? LoginType.google : LoginType.apple,
        createdAt: DateTime.fromMillisecondsSinceEpoch(json["createdAt"]),
        accessToken: json["accessToken"],
      );

  Map<String, dynamic> toJson() => {
        "uid": uid,
        "name": name,
        "email": email,
        "profileImage": profileImage,
        "loginType": loginType.name,
        "createdAt": createdAt.millisecondsSinceEpoch,
        "accessToken": accessToken,
      };

  UserModel copyWith({
    String? uid,
    String? name,
    String? email,
    String? profileImage,
    LoginType? loginType,
    DateTime? createdAt,
    String? accessToken,
  }) =>
      UserModel(
        uid: uid ?? this.uid,
        name: name ?? this.name,
        email: email ?? this.email,
        profileImage: profileImage ?? this.profileImage,
        loginType: loginType ?? this.loginType,
        createdAt: createdAt ?? this.createdAt,
        accessToken: accessToken ?? this.accessToken,
      );

  @override
  String toString() {
    return toJson().toString();
  }
}
