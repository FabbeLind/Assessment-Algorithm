part of 'auth_bloc.dart';

abstract class AuthState {}

class AuthInitialState extends AuthState {}

class AuthLoadingState extends AuthState {}

class AuthSuccessState extends AuthState {
  UserModel user;

  AuthSuccessState({required this.user});
}

class AuthErrorState extends AuthState {}
