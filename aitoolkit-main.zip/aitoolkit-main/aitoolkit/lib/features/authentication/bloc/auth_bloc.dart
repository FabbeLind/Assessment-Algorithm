import 'dart:async';

import 'package:aitoolkit/features/authentication/model/user_model.dart';
import 'package:aitoolkit/features/authentication/repository/auth_repo.dart';
import 'package:aitoolkit/storage/app_storage.dart';
import 'package:app_utils/app_utils.dart';
import 'package:bloc/bloc.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:sign_in_with_apple/sign_in_with_apple.dart';

part 'auth_event.dart';
part 'auth_state.dart';

class AuthBloc extends Bloc<AuthEvent, AuthState> {
  AuthBloc() : super(AuthInitialState()) {
    on<AuthAppleLoginEvent>(_loginWithApple);
    on<AuthGoogleLoginEvent>(_loginWithGoogle);
  }

  final AuthRepo _authRepo = AuthRepo.instance;
  UserModel? user;

  Future<void> _loginWithApple(AuthAppleLoginEvent event, Emitter<AuthState> emit) async {
    try {
      emit(AuthLoadingState());
      AuthorizationCredentialAppleID? credential = await _authRepo.signInWithApple();
      if (credential != null) {
        if (credential.identityToken != null && (credential.identityToken?.isNotEmpty ?? false)) {
          OAuthCredential oauthCredential = OAuthProvider("apple.com").credential(
            idToken: credential.identityToken,
          );
          UserCredential userCredential = await FirebaseAuth.instance.signInWithCredential(oauthCredential);
          if (userCredential.user != null) {
            User userData = userCredential.user!;
            user = UserModel(
              uid: userData.uid,
              name: "${credential.givenName} ${credential.familyName}",
              email: credential.email,
              profileImage: userData.photoURL,
              loginType: LoginType.apple,
              createdAt: DateTime.now(),
              accessToken: credential.identityToken!,
            );
            await AppStorage.setAuthUid(userData.uid);
            bool userExist = await _authRepo.checkUserExist(user!.uid);
            if (!userExist) {
              Debug.log("New User --->>> $user");
              await _authRepo.registerUser(user!);
            }
          }
          Debug.log("User --->>> $user");
          emit(AuthSuccessState(user: user!));
        }
      }
    } catch (e, st) {
      emit(AuthErrorState());
      Debug.log(e, st);
    }
  }

  Future<void> _loginWithGoogle(AuthGoogleLoginEvent event, Emitter<AuthState> emit) async {
    try {
      emit(AuthLoadingState());
      GoogleSignInAccount? credential = await _authRepo.signInWithGoogle();
      if (credential != null) {
        final GoogleSignInAuthentication googleAuth = await credential.authentication;
        final signInCredential = GoogleAuthProvider.credential(
          accessToken: googleAuth.accessToken,
          idToken: googleAuth.idToken,
        );
        UserCredential userCredential = await FirebaseAuth.instance.signInWithCredential(signInCredential);

        if (userCredential.user != null) {
          User userData = userCredential.user!;

          user = UserModel(
            uid: userData.uid,
            name: userData.displayName,
            email: userData.email,
            profileImage: userData.photoURL,
            loginType: LoginType.google,
            createdAt: DateTime.now(),
            accessToken: googleAuth.idToken!,
          );
          await AppStorage.setAuthUid(userData.uid);
          bool userExist = await _authRepo.checkUserExist(user!.uid);
          if (!userExist) {
            await _authRepo.registerUser(user!);
          }
        }
        Debug.log("User --->>> $user");
        emit(AuthSuccessState(user: user!));
      }
    } catch (e, st) {
      emit(AuthErrorState());
      Debug.log(e, st);
    }
  }
}
