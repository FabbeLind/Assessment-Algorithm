part of 'auth_bloc.dart';

abstract class AuthEvent {}

class AuthAppleLoginEvent extends AuthEvent {}

class AuthGoogleLoginEvent extends AuthEvent {}
