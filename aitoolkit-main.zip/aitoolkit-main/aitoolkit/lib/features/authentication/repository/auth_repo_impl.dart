part of "auth_repo.dart";

class _AuthRepoImpl extends AuthRepo {
  @override
  Future<AuthorizationCredentialAppleID?> signInWithApple() async {
    try {
      if (await SignInWithApple.isAvailable()) {
        final AuthorizationCredentialAppleID credential = await SignInWithApple.getAppleIDCredential(
          scopes: [
            AppleIDAuthorizationScopes.email,
            AppleIDAuthorizationScopes.fullName,
          ],
        );
        Debug.log("User login apple --->>> $credential");
        return credential;
      }
      return null;
    } catch (e) {
      rethrow;
    }
  }

  @override
  Future<GoogleSignInAccount?> signInWithGoogle() async {
    try {
      String oAuthIos = Platform.environment['OAUTH_IOS'] ?? dotenv.get('OAUTH_IOS');
      String oAuthAndroid = Platform.environment['OAUTH_IOS'] ?? dotenv.get('OAUTH_ANDROID');

      final GoogleSignInAccount? credential = await GoogleSignIn(
        signInOption: SignInOption.standard,
        clientId: Platform.isIOS ? oAuthIos : oAuthAndroid,
        scopes: ['email', 'profile'],
      ).signIn();
      if (credential != null) {
        return credential;
      }
      return null;
    } catch (e) {
      rethrow;
    }
  }

  @override
  Future<bool> checkUserExist(String uid) async {
    try {
      QuerySnapshot<Object?> userData =
          await FirebaseFirestoreService.userCollection.where("uid", isEqualTo: uid).get();

      return userData.size > 0;
    } catch (e, st) {
      Debug.log(e, st);
      rethrow;
    }
  }

  @override
  Future<void> registerUser(UserModel user) async {
    try {
      await FirebaseFirestoreService.userCollection.doc(user.uid).set(user.toJson());
    } catch (e, st) {
      Debug.log(e, st);
      rethrow;
    }
  }
}
