import 'dart:io';

import 'package:aitoolkit/features/authentication/model/user_model.dart';
import 'package:app_services/firebase/firebase_firestore_service.dart';
import 'package:app_utils/debug_log_utils.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:sign_in_with_apple/sign_in_with_apple.dart';

part "auth_repo_impl.dart";

abstract class AuthRepo {
  static final AuthRepo _instance = _AuthRepoImpl();

  Future<AuthorizationCredentialAppleID?> signInWithApple();

  Future<GoogleSignInAccount?> signInWithGoogle();

  Future<bool> checkUserExist(String uid);

  Future<void> registerUser(UserModel user);

  static AuthRepo get instance => _instance;
}
