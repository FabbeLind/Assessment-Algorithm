import 'package:app_utils/constants/constants.dart';
import 'package:app_utils/extensions/extensions.dart';
import 'package:flutter/material.dart';

class ImplementationBgImageWidget extends StatelessWidget {
  const ImplementationBgImageWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.bottomRight,
      child: Image.asset(
        AppAsset.implementationBgImage,
        height: context.height * 0.92,
        fit: BoxFit.cover,
        alignment: Alignment.bottomRight,
      ),
    );
  }
}
