import 'package:aitoolkit/features/implementation/bloc/implementation_bloc.dart';
import 'package:aitoolkit/features/implementation/widgets/implementation_bg_image_widget.dart';
import 'package:aitoolkit/routes/routes.dart';
import 'package:aitoolkit/widgets/app_snackbar.dart';
import 'package:aitoolkit/widgets/loader.dart';
import 'package:aitoolkit/widgets/primary_button.dart';
import 'package:aitoolkit/widgets/primary_text_field.dart';
import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';

class CreateImplementationScreen extends StatefulWidget {
  const CreateImplementationScreen({
    super.key,
    required this.userId,
  });

  final String userId;

  @override
  State<CreateImplementationScreen> createState() => _CreateImplementationScreenState();
}

class _CreateImplementationScreenState extends State<CreateImplementationScreen> {
  final TextEditingController implementationName = TextEditingController();
  late FocusNode focusNode;
  ImplementationBloc implementationBloc = ImplementationBloc();

  @override
  void initState() {
    focusNode = FocusNode();
    super.initState();
  }

  @override
  void dispose() {
    focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        child: Stack(
          children: [
            const ImplementationBgImageWidget(),
            BlocConsumer<ImplementationBloc, ImplementationState>(
              bloc: implementationBloc,
              listener: (context, state) {
                if (state is AddImplementationLoadingState) {
                  Loader.show(context);
                } else if (state is AddImplementationErrorState) {
                  Loader.dismiss(context);
                  AppSnackBar.showError(context, state.message);
                } else if (state is AddImplementationSuccessState) {
                  Loader.dismiss(context);
                  Navigator.pushNamedAndRemoveUntil(
                    context,
                    Routes.dashBoardScreen,
                    (route) => false,
                  );
                } else {
                  Loader.dismiss(context);
                }
              },
              builder: (context, state) {
                return Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    _buildNewImplementationText(),
                    SizedBox(height: 20.h),
                    _buildNewImplementationDescText(),
                    SizedBox(height: 30.h),
                    _buildImplementationTextField(),
                    SizedBox(height: 20.h),
                    _buildCreateImplementationButton(),
                    SizedBox(height: context.bottomViewInset),
                  ],
                );
              },
            ).paddingSymmetric(horizontal: 38.w),
            _buildCloseButton(context)
          ],
        ),
      ),
    );
  }

  Widget _buildCloseButton(BuildContext context) {
    return Align(
      alignment: Alignment.topRight,
      child: GestureDetector(
        onTap: () {
          Navigator.pop(context);
        },
        child: Container(
          color: Colors.transparent,
          padding: const EdgeInsets.all(20.0),
          child: SvgPicture.asset(
            AppAsset.cross,
            height: 24.w,
            width: 24.w,
          ),
        ),
      ),
    );
  }

  Widget _buildCreateImplementationButton() {
    return PrimaryButton(
      label: AppString.create,
      onPressed: () {
        implementationBloc.add(AddImplementationEvent(
          widget.userId,
          implementationName.text,
        ));
      },
    );
  }

  Widget _buildImplementationTextField() {
    return PrimaryTextField(
      controller: implementationName,
      labelText: AppString.name,
      borderColor: AppThemeData.lightBorderColor,
      filled: true,
      fillColor: AppThemeData.white,
      focusNode: focusNode,
      contentPadding: EdgeInsets.symmetric(
        vertical: 12.h,
        horizontal: 16.w,
      ),
      suffixEnabled: true,
    );
  }

  Text _buildNewImplementationDescText() {
    return Text(
      AppString.newImplementationDesc,
      textAlign: TextAlign.center,
      style: AppTextStyle.body,
    );
  }

  Text _buildNewImplementationText() {
    return Text(
      AppString.newImplementation,
      style: AppTextStyle.title1,
    );
  }
}
