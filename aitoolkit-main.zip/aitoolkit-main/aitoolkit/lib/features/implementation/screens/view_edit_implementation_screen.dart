import 'package:aitoolkit/features/home/bloc/home_bloc.dart';
import 'package:aitoolkit/features/implementation/bloc/implementation_bloc.dart';
import 'package:aitoolkit/features/implementation/widgets/implementation_bg_image_widget.dart';
import 'package:aitoolkit/widgets/app_snackbar.dart';
import 'package:aitoolkit/widgets/primary_app_bar.dart';
import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../../routes/routes.dart';
import '../../../widgets/loader.dart';

class ViewEditImplementationScreen extends StatefulWidget {
  const ViewEditImplementationScreen({super.key});

  @override
  State<ViewEditImplementationScreen> createState() => _ViewEditImplementationScreenState();
}

class _ViewEditImplementationScreenState extends State<ViewEditImplementationScreen> {
  final TextEditingController implementationName = TextEditingController();
  String implementationId = "";
  late HomeBloc homeBloc;
  late ImplementationBloc implementationBloc;

  @override
  void initState() {
    BlocProvider(
      create: (context) => ImplementationBloc(),
    );
    implementationBloc = ImplementationBloc()..add(ViewImplementationInitialEvent());
    homeBloc = context.read<HomeBloc>();
    if (homeBloc.implementation != null) {
      implementationName.text = homeBloc.implementation?.name ?? "";
      implementationId = homeBloc.implementation?.id ?? "";
    }
    Debug.log("Implementation -> ${homeBloc.implementation?.id} ${homeBloc.implementation?.name}");
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: _buildAppBar(),
      body: Stack(
        children: [
          const ImplementationBgImageWidget(),
          BlocConsumer<ImplementationBloc, ImplementationState>(
            bloc: implementationBloc,
            listener: (context, state) {
              Debug.log("Implementation Bloc -> $state");
              if (state is EditImplementationLoadingState) {
                Loader.show(context);
              } else if (state is EditImplementationErrorState) {
                Loader.dismiss(context);
                AppSnackBar.showError(context, state.message);
              } else if (state is EditImplementationSuccessState) {
                Loader.dismiss(context);
                Navigator.pushNamedAndRemoveUntil(context, Routes.dashBoardScreen, (route) => false);
              } else {
                Loader.dismiss(context);
              }
            },
            builder: (context, state) {
              return Column(
                children: [
                  PrimaryAppBar(
                    title: getImplementationTitle(state),
                    appBarActive: true,
                    status: (state is EditImplementationState) ? AppBarStatus.edit : AppBarStatus.view,
                    labelText: AppString.name,
                    prefixIcon: (
                      widget: _prefixIconWidget(state),
                      onTap: _prefixOnTap(state),
                    ),
                    suffixIcon: (
                      widget: _suffixIconWidget(state),
                      onTap: _suffixOnTap(state),
                    ),
                    controller: implementationName,
                  ),
                  Expanded(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text(
                          AppString.implementation,
                          style: AppTextStyle.defaultF16W7Primary,
                        ),
                        SizedBox(height: 35.h),
                        Text(
                          AppString.implementationDesc,
                          textAlign: TextAlign.center,
                          style: AppTextStyle.title3.copyWith(
                            fontWeight: FontWeight.w300,
                          ),
                        ),
                      ],
                    ).paddingSymmetric(horizontal: 40.w),
                  )
                ],
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _suffixIconWidget(ImplementationState state) {
    return SvgPicture.asset(
      (state is EditImplementationState) ? AppAsset.tickActive : AppAsset.editActive,
      height: 24.w,
      width: 24.w,
    );
  }

  Function() _suffixOnTap(ImplementationState state) {
    return () {
      if (state is EditImplementationState) {
        implementationBloc.add(EditImplementationEvent(
          implementationId,
          implementationName.text,
        ));
      } else {
        implementationBloc.add(EditImplementationInitialEvent());
      }
    };
  }

  Function() _prefixOnTap(ImplementationState state) {
    return () {
      if (state is EditImplementationState) {
        implementationName.text = homeBloc.implementation?.name ?? "";
        implementationBloc.add(ViewImplementationInitialEvent());
      } else {
        Navigator.pop(context);
      }
    };
  }

  Widget _prefixIconWidget(ImplementationState state) {
    return SvgPicture.asset(
      (state is EditImplementationState) ? AppAsset.crossActive : AppAsset.backArrowActive,
      height: 24.w,
      width: 24.w,
    );
  }

  AppBar _buildAppBar() {
    return AppBar(
      toolbarHeight: 0,
      automaticallyImplyLeading: false,
      centerTitle: true,
      backgroundColor: AppThemeData.white,
      systemOverlayStyle: const SystemUiOverlayStyle(
        statusBarColor: AppThemeData.white,
        statusBarIconBrightness: Brightness.dark, // For Android (dark icons)
        statusBarBrightness: Brightness.light, // For iOS (dark icons)
      ),
    );
  }

  String getImplementationTitle(ImplementationState state) {
    if (state is EditImplementationState) {
      return AppString.editImplementation;
    } else {
      return AppString.viewImplementation;
    }
  }
}
