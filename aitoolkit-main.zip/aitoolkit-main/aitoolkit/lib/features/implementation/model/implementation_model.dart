import 'package:cloud_firestore/cloud_firestore.dart';

class ImplementationModel {
  final String id;
  final String name;
  final List<String> uidList;
  final String createdBy;
  final DateTime createdAt;
  final DateTime updatedAt;

  const ImplementationModel({
    required this.id,
    required this.name,
    required this.uidList,
    required this.createdBy,
    required this.createdAt,
    required this.updatedAt,
  });

  ImplementationModel copyWith({
    String? id,
    String? name,
    List<String>? uidList,
    String? createdBy,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) =>
      ImplementationModel(
        id: id ?? this.id,
        name: name ?? this.name,
        uidList: uidList ?? this.uidList,
        createdBy: createdBy ?? this.createdBy,
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
      );

  factory ImplementationModel.fromMap(Map<String, dynamic> json) => ImplementationModel(
        id: json["id"],
        name: json["name"],
        uidList: json["uidList"] == null ? [] : List<String>.from(json["uidList"]!.map((x) => x)),
        createdBy: json["createdBy"],
        createdAt: (json["createdAt"] as Timestamp).toDate(),
        updatedAt: (json["updatedAt"] as Timestamp).toDate(),
      );

  Map<String, dynamic> toMap() => {
        "id": id,
        "name": name,
        "uidList": List<dynamic>.from(uidList.map((x) => x).toList()),
        "createdBy": createdBy,
        "createdAt": Timestamp.fromDate(createdAt),
        "updatedAt": Timestamp.fromDate(updatedAt),
      };

  @override
  String toString() {
    return toMap().toString();
  }
}
