part of 'implementation_repo.dart';

class _ImplementationRepoImpl extends ImplementationRepo {
  @override
  Future<void> editImplementation({
    required String implId,
    required Map<String, dynamic> updatedImplMap,
  }) async {
    try {
      await FirebaseFirestoreService.updateImplementation(implId, updatedImplMap);
    } catch (e) {
      rethrow;
    }
  }
}
