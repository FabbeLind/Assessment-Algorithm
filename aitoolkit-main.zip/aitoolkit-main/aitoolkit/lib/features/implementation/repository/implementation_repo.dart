import 'package:app_services/firebase/firebase_firestore_service.dart';

part 'implementation_repo_impl.dart';

abstract class ImplementationRepo {
  static final ImplementationRepo _instance = _ImplementationRepoImpl();

  Future<void> editImplementation({
    required String implId,
    required Map<String, dynamic> updatedImplMap,
  });

  static ImplementationRepo get instance => _instance;
}
