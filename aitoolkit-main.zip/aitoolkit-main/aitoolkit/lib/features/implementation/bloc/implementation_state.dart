part of 'implementation_bloc.dart';

abstract class ImplementationState {}

class ImplementationInitial extends ImplementationState {}

abstract class AddImplementationState extends ImplementationState {}

abstract class EditImplementationState extends ImplementationState {}

abstract class ViewImplementationState extends ImplementationState {}

class AddImplementationLoadingState extends AddImplementationState {}

class AddImplementationErrorState extends AddImplementationState {
  final String message;

  AddImplementationErrorState(this.message);
}

class AddImplementationSuccessState extends AddImplementationState {}

class EditImplementationInitialState extends EditImplementationState {}

class EditImplementationLoadingState extends EditImplementationState {}

class EditImplementationErrorState extends EditImplementationState {
  final String message;

  EditImplementationErrorState(this.message);
}

class EditImplementationSuccessState extends EditImplementationState {}

class ViewImplementationInitialState extends ViewImplementationState {}

class ViewImplementationLoadingState extends ViewImplementationState {}

class ViewImplementationErrorState extends ViewImplementationState {
  final String message;

  ViewImplementationErrorState(this.message);
}

class ViewImplementationSuccessState extends ViewImplementationState {}
