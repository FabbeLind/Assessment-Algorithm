part of 'implementation_bloc.dart';

abstract class ImplementationEvent {}

class AddImplementationEvent extends ImplementationEvent {
  final String userId;
  final String implementationName;

  AddImplementationEvent(this.userId, this.implementationName);
}

class ViewImplementationInitialEvent extends ImplementationEvent {}

class EditImplementationInitialEvent extends ImplementationEvent {}

class EditImplementationEvent extends ImplementationEvent {
  final String implId;
  final String implementationName;

  EditImplementationEvent(this.implId, this.implementationName);
}
