import 'dart:async';

import 'package:aitoolkit/features/implementation/model/implementation_model.dart';
import 'package:aitoolkit/features/implementation/repository/implementation_repo.dart';
import 'package:app_services/firebase/firebase_firestore_service.dart';
import 'package:app_utils/constants/constants.dart';
import 'package:app_utils/debug_log_utils.dart';
import 'package:bloc/bloc.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

part 'implementation_event.dart';
part 'implementation_state.dart';

class ImplementationBloc extends Bloc<ImplementationEvent, ImplementationState> {
  ImplementationBloc() : super(ImplementationInitial()) {
    on<AddImplementationEvent>(_addImplementation);
    on<EditImplementationEvent>(_editImplementation);
    on<EditImplementationInitialEvent>(_editImplementationInitialEvent);
    on<ViewImplementationInitialEvent>(_viewImplementation);
  }

  final ImplementationRepo _implementationRepo = ImplementationRepo.instance;

  Future<void> _addImplementation(AddImplementationEvent event, Emitter<ImplementationState> emit) async {
    try {
      if (event.userId.isNotEmpty && event.implementationName.isNotEmpty) {
        emit(AddImplementationLoadingState());
        DateTime now = DateTime.now();
        ImplementationModel implementation = ImplementationModel(
          id: "",
          name: event.implementationName,
          uidList: [event.userId],
          createdBy: event.userId,
          createdAt: now,
          updatedAt: now,
        );
        await FirebaseFirestoreService.addImplementation(event.userId, implementation.toMap());
        emit(AddImplementationSuccessState());
      } else {
        emit(AddImplementationErrorState(AppString.nameIsRequired));
      }
    } catch (e, st) {
      emit(AddImplementationErrorState("Error while adding implementation"));
      Debug.log("Error while adding implementation --->>> $e \n $st");
    }
  }

  Future<void> _editImplementation(EditImplementationEvent event, Emitter<ImplementationState> emit) async {
    try {
      if (event.implId.isNotEmpty && event.implementationName.isNotEmpty) {
        emit(EditImplementationLoadingState());
        DateTime now = DateTime.now();
        Map<String, dynamic> updatedImplementationMap = {
          "name": event.implementationName,
          "updatedAt": Timestamp.fromDate(now),
        };
        await _implementationRepo.editImplementation(
          implId: event.implId,
          updatedImplMap: updatedImplementationMap,
        );
        emit(EditImplementationSuccessState());
      } else {
        emit(EditImplementationErrorState(AppString.nameIsRequired));
      }
    } catch (e, st) {
      emit(EditImplementationErrorState("Error while updating implementation"));
      Debug.log("Error while adding implementation --->>> $e \n $st");
    }
  }

  Future<void> _viewImplementation(ViewImplementationInitialEvent event, Emitter<ImplementationState> emit) async {
    try {
      emit(ViewImplementationLoadingState());
      emit(ViewImplementationSuccessState());
    } catch (e, st) {
      emit(ViewImplementationErrorState("Error while view implementation"));
      Debug.log("Error while viewing implementation --->>> $e \n $st");
    }
  }

  Future<void> _editImplementationInitialEvent(
      EditImplementationInitialEvent event, Emitter<ImplementationState> emit) async {
    try {
      emit(EditImplementationInitialState());
    } catch (e, st) {
      emit(EditImplementationErrorState("Error while initializing edit implementation"));
      Debug.log("Error while viewing implementation --->>> $e \n $st");
    }
  }
}
