import 'dart:async';

import 'package:app_utils/app_utils.dart';
import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';

part 'security_event.dart';

part 'security_state.dart';

class SecurityBloc extends Bloc<SecurityEvent, SecurityState> {
  SecurityBloc() : super(SecurityInitial()) {
    on<EditUserInitialEvent>(_editUserInitialEvent);
    on<UsersInitialEvent>(_usersInitialEvent);
    on<RolesInitialEvent>(_rolesInitialEvent);
    on<AddRolesInitialEvent>(_addRolesInitialEvent);
    on<EditRolesInitialEvent>(_editRolesInitialEvent);
  }

  Future<void> _editUserInitialEvent(
      EditUserInitialEvent event, Emitter<SecurityState> emit) async {
    emit(UserActionState(
        appBarStatus: AppBarStatus.edit, status: UserActionStateEnum.success));
  }

  Future<void> _usersInitialEvent(
      UsersInitialEvent event, Emitter<SecurityState> emit) async {
    emit(UsersSuccessState());
  }

  Future<void> _rolesInitialEvent(
      RolesInitialEvent event, Emitter<SecurityState> emit) async {
    emit(RolesSuccessState());
  }

  Future<void> _addRolesInitialEvent(
      AddRolesInitialEvent event, Emitter<SecurityState> emit) async {
    emit(RoleActionState(
      appBarStatus: AppBarStatus.add,
      status: UserActionStateEnum.initial,
    ));
  }

  Future<void> _editRolesInitialEvent(
      EditRolesInitialEvent event, Emitter<SecurityState> emit) async {
    emit(RoleActionState(
      appBarStatus: AppBarStatus.edit,
      status: UserActionStateEnum.initial,
    ));
  }
}
