part of 'security_bloc.dart';

enum UserActionStateEnum { loading, success, error, initial }

@immutable
sealed class SecurityState {}

class UserActionState extends SecurityState {
  final UserActionStateEnum status;
  final AppBarStatus appBarStatus;
  final String? message;

  UserActionState({
    this.status = UserActionStateEnum.initial,
    this.appBarStatus = AppBarStatus.none,
    this.message,
  });

  UserActionState copyWith({
    UserActionStateEnum? status,
    AppBarStatus? appBarStatus,
    String? message,
  }) {
    return UserActionState(
      status: status ?? this.status,
      appBarStatus: appBarStatus ?? this.appBarStatus,
      message: message ?? this.message,
    );
  }
}

class RoleActionState extends SecurityState {
  final UserActionStateEnum status;
  final AppBarStatus appBarStatus;
  final String? message;

  RoleActionState({
    this.status = UserActionStateEnum.initial,
    this.appBarStatus = AppBarStatus.none,
    this.message,
  });

  RoleActionState copyWith({
    UserActionStateEnum? status,
    AppBarStatus? appBarStatus,
    String? message,
  }) {
    return RoleActionState(
      status: status ?? this.status,
      appBarStatus: appBarStatus ?? this.appBarStatus,
      message: message ?? this.message,
    );
  }
}

final class UsersInitialState extends SecurityState {}

final class UsersLoadingState extends SecurityState {}

final class UsersErrorState extends SecurityState {}

final class UsersSuccessState extends SecurityState {}

final class RolesInitialState extends SecurityState {}

final class RolesLoadingState extends SecurityState {}

final class RolesErrorState extends SecurityState {}

final class RolesSuccessState extends SecurityState {}

final class SecurityInitial extends SecurityState {}
