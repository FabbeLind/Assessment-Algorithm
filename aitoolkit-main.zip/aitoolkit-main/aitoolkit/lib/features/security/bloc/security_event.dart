part of 'security_bloc.dart';

@immutable
sealed class SecurityEvent {}

class UsersInitialEvent extends SecurityEvent {}

class RolesInitialEvent extends SecurityEvent {}

class AddRolesInitialEvent extends SecurityEvent {}

class EditRolesInitialEvent extends SecurityEvent {}

class EditUserInitialEvent extends SecurityEvent {}
