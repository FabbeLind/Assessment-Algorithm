import 'package:aitoolkit/widgets/app_snackbar.dart';
import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../../widgets/app_image.dart';
import '../../../widgets/primary_container.dart';

class UserCard extends StatelessWidget {
  const UserCard({
    super.key,
    this.onEditTap,
  });

  final Function()? onEditTap;

  @override
  Widget build(BuildContext context) {
    /// TODO : Add dynamic from database
    return PrimaryContainer(
      padding: EdgeInsets.symmetric(horizontal: 20.w),
      child: Row(
        children: [
          AppImage(
            AppAsset.userProfileImagePlaceholder,
            size: 32,
            borderRadius: 100.r,
          ),
          SizedBox(width: 15.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text("Adam Sandler", style: AppTextStyle.headline),
                Text("adamsandler@email.com",
                    style: AppTextStyle.defaultF12W5Primary),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              GestureDetector(
                onTap: onEditTap,
                child: SvgPicture.asset(
                  AppAsset.editActive,
                  height: 24.w,
                  width: 24.w,
                ).addTapAreaAll(10.w),
              ),
              SizedBox(height: 5.h),
              Container(
                padding: EdgeInsets.symmetric(vertical: 3.h, horizontal: 7.w),
                decoration: BoxDecoration(
                  color: AppThemeData.saffronYellow,
                  borderRadius: BorderRadius.circular(8.r),
                ),
                child: Text("Sales manager",
                    style: AppTextStyle.defaultF12W5HintColor),
              ),
              SizedBox(height: 15.h),
            ],
          )
        ],
      ),
    );
  }
}
