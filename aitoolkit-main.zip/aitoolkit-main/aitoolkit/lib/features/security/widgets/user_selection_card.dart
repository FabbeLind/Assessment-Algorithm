import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../../widgets/app_image.dart';
import '../../../widgets/primary_container.dart';

class UserSelectionCard extends StatefulWidget {
  const UserSelectionCard({super.key});

  @override
  State<UserSelectionCard> createState() => _UserSelectionCardState();
}

class _UserSelectionCardState extends State<UserSelectionCard> {
  bool isSelected = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        setState(() {
          isSelected = !isSelected;
        });
      },
      child: PrimaryContainer(
        padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 12.w),
        child: Row(
          children: [
            AppImage(
              AppAsset.userProfileImagePlaceholder,
              size: 32,
              borderRadius: 100.r,
            ),
            SizedBox(width: 15.w),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("Adam Sandler", style: AppTextStyle.headline),
                  Text("adamsandler@email.com",
                      style: AppTextStyle.defaultF12W5Primary),
                ],
              ),
            ),
            Container(
              height: 18.w,
              width: 18.w,
              padding: EdgeInsets.all(4.w),
              decoration: BoxDecoration(
                color: Colors.transparent,
                shape: BoxShape.circle,
                border: Border.all(
                  color: AppThemeData.secondaryBorderColor,
                  width: 1.w,
                ),
              ),
              child: isSelected
                  ? SvgPicture.asset(
                      AppAsset.tickOutlined,
                      colorFilter: const ColorFilter.mode(
                          AppThemeData.secondaryBorderColor, BlendMode.srcIn),
                    )
                  : null,
            )
          ],
        ),
      ),
    );
  }
}
