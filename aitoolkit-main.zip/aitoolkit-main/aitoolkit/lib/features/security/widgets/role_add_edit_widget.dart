import 'package:aitoolkit/features/security/widgets/user_selection_card.dart';
import 'package:aitoolkit/widgets/app_search_text_field.dart';
import 'package:app_utils/app_utils.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class RoleAddEditWidget extends StatefulWidget {
  const RoleAddEditWidget({super.key});

  @override
  State<RoleAddEditWidget> createState() => _RoleAddEditWidgetState();
}

class _RoleAddEditWidgetState extends State<RoleAddEditWidget> {
  late FocusNode focusNode;
  final TextEditingController search = TextEditingController();

  @override
  void initState() {
    super.initState();
    focusNode = FocusNode();
  }

  @override
  void dispose() {
    super.dispose();
    focusNode.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          AppString.users,
          textAlign: TextAlign.left,
          style: AppTextStyle.title2.copyWith(fontWeight: FontWeight.w500),
        ).paddingOnly(left: 16.w),
        SizedBox(height: 8.h),
        _buildUsersSearchField(),
        SizedBox(height: 25.h),
        ListView.separated(
          itemCount: 5,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemBuilder: (context, index) {
            return const UserSelectionCard();
          },
          separatorBuilder: (context, index) => SizedBox(height: 10.h),
        ),
      ],
    );
  }

  Widget _buildUsersSearchField() {
    return AppSearchTextField(
      focusNode: focusNode,
      controller: search,
      iconColor: AppThemeData.grey700,
      border: Border.all(
        color: AppThemeData.grey700,
        width: 1.w,
      ),
      onChange: (value) {
        /// TODO: Add user search logic
      },
    );
  }
}
