import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../../widgets/app_image.dart';
import '../../../widgets/primary_container.dart';

class RoleCardWidget extends StatelessWidget {
  const RoleCardWidget({
    super.key,
    this.onEditTap,
  });

  final Function()? onEditTap;

  @override
  Widget build(BuildContext context) {
    int userLength = 4;
    return Stack(children: [
      PrimaryContainer(
        padding: EdgeInsets.fromLTRB(24.w, 10.w, 20.w, 10.w),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("Managers",
                      style: AppTextStyle.headline
                          .copyWith(fontWeight: FontWeight.w700)),
                  SizedBox(height: 5.h),
                  _buildStackImageView(userLength),
                ],
              ).paddingSymmetric(vertical: 10.w),
            ),
          ],
        ),
      ),
      GestureDetector(
        onTap: onEditTap,
        child: Align(
          alignment: Alignment.topRight,
          child: SvgPicture.asset(
            AppAsset.editActive,
            height: 24.w,
            width: 24.w,
          ).addTapAreaOnly(left: 10.w, right: 24.w, top: 5.w, bottom: 10.w),
        ),
      ),
    ]);
  }

  Widget _buildStackImageView(int userLength) {
    double stackWidth = userLength % 2 == 0
        ? (32.w * (userLength / 2)) + 16.w
        : (32.w * (userLength / 2));
    return SizedBox(
      height: 32.w,
      width: stackWidth,
      child: Align(
        alignment: Alignment.centerLeft,
        child: Stack(
          children: [
            for (int i = (userLength - 1); i >= 0; i--)
              Positioned(
                top: 0,
                left: (16.w * i),
                child: AppImage(
                  AppAsset.userProfileImagePlaceholder,
                  size: 32.w,
                ),
              ),
          ],
        ),
      ),
    );
  }
}
