import 'package:aitoolkit/widgets/app_pop_up_item.dart';
import 'package:aitoolkit/widgets/primary_container.dart';
import 'package:aitoolkit/widgets/primary_pop_up.dart';
import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class EditRoleOptionPopUp extends StatelessWidget {
  const EditRoleOptionPopUp({
    super.key,
    required this.deleteRoleTap,
  });

  final Function() deleteRoleTap;

  @override
  Widget build(BuildContext context) {
    return PrimaryPopUp(
      icon: SvgPicture.asset(AppAsset.more),
      child: PrimaryContainer(
        child: AppPopUpItem(
          title: AppString.deleteRole,
          icon: AppAsset.deleteOutlined,
          onTap: () {},
        ),
      ),
    );
  }
}
