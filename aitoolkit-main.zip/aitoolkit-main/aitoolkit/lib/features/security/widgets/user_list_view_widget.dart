import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import 'user_card_widget.dart';

class UserListViewWidget extends StatelessWidget {
  const UserListViewWidget({
    super.key,
    required this.onEditTap,
  });

  final Function() onEditTap;

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      itemCount: 2,
      itemBuilder: (context, index) {
        return UserCard(onEditTap: onEditTap);
      },
      padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 20.h),
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      separatorBuilder: (context, index) => SizedBox(height: 20.h),
    );
  }
}
