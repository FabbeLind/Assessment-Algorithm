import 'dart:io';

import 'package:app_utils/app_utils.dart';
import 'package:app_utils/file_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../../widgets/app_underline_text_field.dart';
import '../../../widgets/primary_animated_container.dart';

class EditUserWidget extends StatefulWidget {
  const EditUserWidget({super.key});

  @override
  State<EditUserWidget> createState() => _EditUserWidgetState();
}

class _EditUserWidgetState extends State<EditUserWidget> {
  final TextEditingController firstName = TextEditingController();
  final TextEditingController lastName = TextEditingController();
  final TextEditingController email = TextEditingController();
  String? userImage;

  @override
  void dispose() {
    super.dispose();
    firstName.dispose();
    lastName.dispose();
    email.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return PrimaryAnimatedContainer(
      title: AppString.name,
      child: Column(
        children: [
          AppUnderlineTextField(
            controller: firstName,
            hintText: AppString.firstName,
          ),
          AppUnderlineTextField(
            controller: lastName,
            hintText: AppString.lastName,
          ),
          AppUnderlineTextField(
            controller: email,
            hintText: AppString.email,
          ),
          SizedBox(height: 5.h),
          Align(
            alignment: Alignment.centerRight,
            child: GestureDetector(
              onTap: () async {
                String? image = await FileUtil().pickImage();
                if (image != null) {
                  userImage = image;
                  setState(() {});
                }
              },
              child: userImage != null
                  ? ClipRRect(
                      borderRadius: BorderRadius.circular(2.r),
                      child: Image.file(
                        File(userImage!),
                        height: 21.w,
                        width: 21.w,
                        fit: BoxFit.cover,
                      ),
                    ).addTapAreaOnly(
                      left: 20.w, right: 20.w, bottom: 15.w, top: 5.w)
                  : _buildIcon(AppAsset.media),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildIcon(String icon, {Function()? onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: SvgPicture.asset(
        icon,
        height: 21.w,
        width: 21.w,
      ).addTapAreaOnly(left: 20.w, right: 20.w, bottom: 15.w, top: 5.w),
    );
  }
}
