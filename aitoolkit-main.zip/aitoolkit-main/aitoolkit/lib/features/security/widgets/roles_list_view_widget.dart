import 'package:aitoolkit/features/security/widgets/role_card_widget.dart';
import 'package:aitoolkit/widgets/primary_container.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class RolesListViewWidget extends StatelessWidget {
  const RolesListViewWidget({
    super.key,
    required this.onEditTap,
  });

  final Function() onEditTap;

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      itemCount: 2,
      itemBuilder: (context, index) {
        return RoleCardWidget(onEditTap: onEditTap);
      },
      padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 20.h),
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      separatorBuilder: (context, index) => SizedBox(height: 20.h),
    );
  }
}
