import 'package:aitoolkit/widgets/primary_app_bar.dart';
import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../routes/routes.dart';
import '../../../widgets/app_option_widget.dart';
import '../../../widgets/app_widget.dart';
import '../../../widgets/primary_container.dart';

class SecurityScreen extends StatelessWidget {
  const SecurityScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            _buildAppBar(context),
            SizedBox(height: 20.h),
            PrimaryContainer(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  AppOptionWidget(
                    title: AppString.users,
                    iconPath: AppAsset.users,
                    onTap: () {
                      Navigator.pushNamed(context, Routes.usersScreen);
                    },
                  ),
                  _buildDivider(),
                  AppOptionWidget(
                    title: AppString.roles,
                    iconPath: AppAsset.roles,
                    onTap: () {
                      Navigator.pushNamed(context, Routes.rolesScreen);
                    },
                  ),
                ],
              ),
            ).defaultPadding,
          ],
        ),
      ),
    );
  }

  Widget _buildDivider() {
    return Row(
      children: [
        SizedBox(width: 59.w),
        Expanded(
          child: Divider(thickness: 1.h, height: 0.h),
        ),
      ],
    );
  }

  Widget _buildAppBar(BuildContext context) {
    return PrimaryAppBar(
      title: AppString.security,
      iconAndLabelColor: AppThemeData.primaryTextColor,
      prefixIcon: (
        widget: AppWidget.backArrowIcon(),
        onTap: _prefixOnTap(context)
      ),
      suffixIcon: (widget: AppWidget.suffixSpace(), onTap: () {}),
    );
  }

  Function() _prefixOnTap(BuildContext context) {
    return () {
      Navigator.pop(context);
    };
  }
}
