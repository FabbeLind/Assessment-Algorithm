import 'package:aitoolkit/features/security/bloc/security_bloc.dart';
import 'package:aitoolkit/features/security/widgets/edit_user_widget.dart';
import 'package:aitoolkit/features/security/widgets/user_list_view_widget.dart';
import 'package:aitoolkit/widgets/app_search_text_field.dart';
import 'package:aitoolkit/widgets/app_snackbar.dart';
import 'package:aitoolkit/widgets/app_widget.dart';
import 'package:aitoolkit/widgets/primary_app_bar.dart';
import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../../widgets/dialogs/primary_text_field_dialog.dart';

class UsersScreen extends StatefulWidget {
  const UsersScreen({super.key});

  @override
  State<UsersScreen> createState() => _UsersScreenState();
}

class _UsersScreenState extends State<UsersScreen> {
  late FocusNode focusNode;
  final TextEditingController userId = TextEditingController();
  final TextEditingController searchController = TextEditingController();
  late SecurityBloc securityBloc;

  @override
  void initState() {
    securityBloc = context.read<SecurityBloc>();
    securityBloc.add(UsersInitialEvent());
    focusNode = FocusNode();
    super.initState();
  }

  @override
  void dispose() {
    userId.dispose();
    searchController.dispose();
    focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: BlocConsumer<SecurityBloc, SecurityState>(
          listener: _userListener,
          builder: (context, state) {
            return Column(
              children: [
                _buildAppBar(state),
                Expanded(
                  child: Scrollbar(
                    child: SingleChildScrollView(
                      child: Column(
                        children: [
                          if (state is UserActionState) ...[
                            SizedBox(height: 20.h),
                            const EditUserWidget().defaultPadding
                          ],
                          if (state is! UserActionState) ...[
                            _buildSearchField().defaultPadding,
                            UserListViewWidget(
                              onEditTap: () {
                                securityBloc.add(EditUserInitialEvent());
                              },
                            ),
                          ]
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  void _userListener(BuildContext context, SecurityState state) {
    if (state is UserActionState) {}
  }

  Widget _buildSearchField() {
    return AppSearchTextField(
      focusNode: focusNode,
      controller: searchController,
      onChange: (value) {
        /// TODO: Add search user logic
      },
      border: Border.all(
        color: AppThemeData.cyanAccent,
        width: 1.w,
      ),
    );
  }

  String _getTitle(SecurityState state) {
    String title = AppString.users;
    if (state is UserActionState && state.appBarStatus == AppBarStatus.edit) {
      title = AppString.editUser;
    }
    return title;
  }

  Widget _buildAppBar(SecurityState state) {
    return PrimaryAppBar(
      controller: userId,
      labelText: AppString.userId,
      title: _getTitle(state),
      appBarActive: state is UserActionState,
      status:
          (state is UserActionState) ? state.appBarStatus : AppBarStatus.none,
      iconAndLabelColor: AppThemeData.primaryTextColor,
      prefixIcon: (widget: _prefixIcon(state), onTap: _prefixOnTap(state)),
      suffixIcon: (widget: _suffixIcon(state), onTap: _suffixOnTap(state)),
      moreSuffixIcon: SvgPicture.asset(AppAsset.more),
      showMoreOption:
          (state is UserActionState && state.appBarStatus == AppBarStatus.edit),
    );
  }

  Widget _suffixIcon(SecurityState state) {
    String icon = AppAsset.inviteUser;
    if (state is UserActionState && state.appBarStatus == AppBarStatus.edit) {
      icon = AppAsset.tickActive;
    }
    return SvgPicture.asset(
      icon,
      height: 24.w,
      width: 24.w,
    );
  }

  Widget _prefixIcon(SecurityState state) {
    if (state is UserActionState && state.appBarStatus == AppBarStatus.edit) {
      return AppWidget.closeIcon();
    }
    return AppWidget.backArrowIcon();
  }

  Function() _suffixOnTap(SecurityState state) => () {
        if (state is UserActionState &&
            state.appBarStatus == AppBarStatus.edit) {
          securityBloc.add(UsersInitialEvent());
        } else {
          final TextEditingController email = TextEditingController();
          PrimaryTextFieldDialog.show(
            context,
            title: AppString.inviteANewUser,
            description: AppString.inviteANewUserDesc,
            controller: email,
            hintText: AppString.typeUserEmailHere,
            suffixText: AppString.invite,
            suffixOnTap: () {
              Navigator.pop(context);
              AppSnackBar.showError(context, "Invite user is not implemented");

              /// TODO: Add invite user logic
            },
          );
        }
      };

  Function() _prefixOnTap(SecurityState state) => () {
        if (state is UserActionState &&
            state.appBarStatus == AppBarStatus.edit) {
          securityBloc.add(UsersInitialEvent());
        } else {
          Navigator.pop(context);
        }
      };
}
