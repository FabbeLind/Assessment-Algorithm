import 'package:aitoolkit/features/security/widgets/pop_up/edit_role_option_pop_up.dart';
import 'package:aitoolkit/features/security/widgets/role_add_edit_widget.dart';
import 'package:aitoolkit/widgets/app_widget.dart';
import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../../widgets/app_search_text_field.dart';
import '../../../widgets/primary_app_bar.dart';
import '../bloc/security_bloc.dart';
import '../widgets/roles_list_view_widget.dart';

class RolesScreen extends StatefulWidget {
  const RolesScreen({super.key});

  @override
  State<RolesScreen> createState() => _RolesScreenState();
}

class _RolesScreenState extends State<RolesScreen> {
  late FocusNode focusNode;
  final TextEditingController title = TextEditingController();
  final TextEditingController searchController = TextEditingController();
  late SecurityBloc securityBloc;

  @override
  void initState() {
    securityBloc = context.read<SecurityBloc>();
    securityBloc.add(RolesInitialEvent());
    focusNode = FocusNode();
    super.initState();
  }

  @override
  void dispose() {
    title.dispose();
    searchController.dispose();
    focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: BlocConsumer<SecurityBloc, SecurityState>(
          listener: _rolesListener,
          builder: (context, state) {
            return Column(
              children: [
                _buildAppBar(state),
                Expanded(
                  child: Scrollbar(
                    child: SingleChildScrollView(
                      child: Column(
                        children: [
                          if (state is RoleActionState) ...[
                            SizedBox(height: 20.h),
                            const RoleAddEditWidget().defaultPadding
                          ],
                          if (state is! RoleActionState) ...[
                            _buildSearchField().defaultPadding,
                            RolesListViewWidget(
                              onEditTap: () {
                                securityBloc.add(EditRolesInitialEvent());
                              },
                            ),
                          ]
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  void _rolesListener(BuildContext context, SecurityState state) {}

  Widget _buildSearchField() {
    return AppSearchTextField(
      focusNode: focusNode,
      controller: searchController,
      onChange: (value) {
        /// TODO: Add search roles logic
      },
      border: Border.all(
        color: AppThemeData.cyanAccent,
        width: 1.w,
      ),
    );
  }

  Widget _buildAppBar(SecurityState state) {
    return PrimaryAppBar(
      controller: title,
      labelText: AppString.title,
      title: _getTitle(state),
      appBarActive: state is RoleActionState,
      status:
          (state is RoleActionState) ? state.appBarStatus : AppBarStatus.none,
      iconAndLabelColor: AppThemeData.primaryTextColor,
      prefixIcon: (widget: _prefixIcon(state), onTap: _prefixOnTap(state)),
      suffixIcon: (widget: _suffixIcon(state), onTap: _suffixOnTap(state)),
      moreSuffixIcon: _buildOptionPopUp(),
      showMoreOption:
          (state is RoleActionState && state.appBarStatus == AppBarStatus.edit),
    );
  }

  Widget _buildOptionPopUp() {
    return EditRoleOptionPopUp(
      deleteRoleTap: () {
        /// TODO: Add delete role logic
      },
    );
  }

  String _getTitle(SecurityState state) {
    String title = AppString.roles;
    if (state is RoleActionState && state.appBarStatus == AppBarStatus.add) {
      title = AppString.newRole;
    } else if (state is RoleActionState &&
        state.appBarStatus == AppBarStatus.edit) {
      title = AppString.editRole;
    }
    return title;
  }

  Function() _prefixOnTap(SecurityState state) {
    return () {
      if (state is RoleActionState) {
        securityBloc.add(RolesInitialEvent());
      } else {
        Navigator.pop(context);
      }
    };
  }

  Widget _prefixIcon(SecurityState state) {
    if (state is RoleActionState) {
      return AppWidget.crossIcon();
    } else {
      return AppWidget.backArrowIcon();
    }
  }

  Function() _suffixOnTap(SecurityState state) {
    return () {
      if (state is RoleActionState && state.appBarStatus == AppBarStatus.add) {
        securityBloc.add(RolesInitialEvent());
      } else if (state is RoleActionState &&
          state.appBarStatus == AppBarStatus.edit) {
        securityBloc.add(RolesInitialEvent());
      } else {
        securityBloc.add(AddRolesInitialEvent());
      }
    };
  }

  Widget _suffixIcon(SecurityState state) {
    String icon = AppAsset.addActive;
    if (state is RoleActionState) {
      icon = AppAsset.tickActive;
    }
    return SvgPicture.asset(
      icon,
      height: 24.w,
      width: 24.w,
    );
  }
}
