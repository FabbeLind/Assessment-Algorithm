import 'package:aitoolkit/features/initiatives/widgets/initiative_add_edit_view_widget.dart';
import 'package:aitoolkit/features/initiatives/widgets/initiative_list_view_widget.dart';
import 'package:aitoolkit/features/initiatives/widgets/initiative_more_option_popup.dart';
import 'package:aitoolkit/widgets/app_snackbar.dart';
import 'package:aitoolkit/widgets/loader.dart';
import 'package:aitoolkit/widgets/primary_app_bar.dart';
import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../../routes/route_arguments.dart';
import '../../app/bloc/app_bloc.dart';
import '../bloc/initiative_bloc.dart';
import '../model/initiative_model.dart';

class InitiativeScreen extends StatefulWidget {
  const InitiativeScreen({
    super.key,
    required this.argument,
  });

  final InitiativeRouteArgument argument;

  @override
  State<InitiativeScreen> createState() => _InitiativeScreenState();
}

class _InitiativeScreenState extends State<InitiativeScreen> {
  late ScrollController scrollController;

  final double _originalHeight = 50.h;
  double _searchBarHeight = 0;
  double _textFieldOpacity = 1.0;
  bool isScrolling = false;
  bool isAppBarActive = false;
  late InitiativeBloc initiativeBloc;
  TextEditingController title = TextEditingController();
  TextEditingController searchController = TextEditingController();
  FocusNode searchFocusNode = FocusNode();
  bool isShowPopup = false;
  String uid = "";

  @override
  void initState() {
    initiativeBloc = context.read<InitiativeBloc>();
    scrollController = ScrollController(initialScrollOffset: _originalHeight);
    _addScrollListener();
    _initBloc();
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
    scrollController.removeListener(() {});
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<InitiativeBloc, InitiativeState>(
      listener: (context, state) {
        if ((state is AddInitiativeLoadingState) ||
            (state is ViewInitiativeLoadingState) ||
            (state is EditInitiativeLoadingState) ||
            (state is DeleteInitiativeLoadingState)) {
          Loader.show(context);
        } else if (state is InitiativeErrorState) {
          AppSnackBar.showError(context, state.message);
        } else if (state is AddInitiativeErrorState) {
          AppSnackBar.showError(context, state.message);
        } else if ((state is AddInitiativeSuccessState) || (state is DeleteInitiativeSuccessState)) {
          setScrollToDefault();
          Loader.dismiss(context);
          _searchBarHeight = 0;
          _textFieldOpacity = 1.0;
          scrollController.animateTo(_originalHeight, duration: const Duration(seconds: 0), curve: Curves.ease);
          initiativeBloc.add(GetInitiativeListEvent(widget.argument.implementationId));
        } else if (state is EditInitiativeSuccessState) {
          Loader.dismiss(context);
          title.text = state.initiative.title;
          initiativeBloc.add(
            ViewInitiativeEvent(
              userId: uid,
              initiative: state.initiative,
            ),
          );
        } else if (state is ViewInitiativeSuccessState) {
          title.text = state.initiative.title;
          Loader.dismiss(context);
        } else if (state is InitiativeSuccessState) {
          setScrollToDefault();
          Loader.dismiss(context);
        } else if (state is AddInitiative) {
          title.clear();
        } else {
          Loader.dismiss(context);
        }
      },
      builder: (context, state) {
        bool appBarActive = (state is InitiativeActionState);
        isAppBarActive = appBarActive ? true : isScrolling;
        return Scaffold(
          extendBodyBehindAppBar: true,
          resizeToAvoidBottomInset: false,
          appBar: _buildAppBar(),
          backgroundColor: AppThemeData.cyanAccent,
          body: Stack(
            children: [
              _buildInitiativesBackgroundImage(),
              SafeArea(
                child: Column(
                  children: [
                    PrimaryAppBar(
                      controller: title,
                      title: _getInitiativeTitle(state),
                      appBarActive: isAppBarActive,
                      status: getInitiativeActiveStatus(state),
                      prefixIcon: (widget: _prefixIcon(state), onTap: _prefixOnTap(state)),
                      suffixIcon: (widget: _suffixIcon(state), onTap: _suffixOnTap(state)),
                      moreSuffixIcon: _buildMoreIcon(state),
                      showMoreOption: getInitiativeActiveStatus(state) == AppBarStatus.view,
                    ),
                    (state is InitiativeActionState)
                        ? InitiativeAddEditViewWidget(
                            readOnly: getInitiativeActiveStatus(state) == AppBarStatus.view,
                            initiativeStatus: getInitiativeActiveStatus(state),
                            initiativeBloc: initiativeBloc,
                          )
                        : InitiativeListViewWidget(
                            scrollController: scrollController,
                            searchController: searchController,
                            focusNode: searchFocusNode,
                            textFieldOpacity: _textFieldOpacity,
                            searchBarHeight: _searchBarHeight,
                            initiativeList: (state is InitiativeSuccessState)
                                ? state.initiativeList
                                : widget.argument.initiativeList,
                            onWorkTap: (InitiativeModel initiative) {
                              title.clear();
                              initiativeBloc.add(
                                ViewInitiativeEvent(
                                  userId: uid,
                                  initiative: initiative,
                                ),
                              );
                            },
                            createInitiativeOnTap: () {
                              if (state is InitiativeSuccessState) {
                                initiativeBloc.add(InitiativeStatusChange(AppBarStatus.add));
                              }
                            },
                          ),
                    SizedBox(height: context.bottomViewInset),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  void setScrollToDefault() {
    _searchBarHeight = 0;
    _textFieldOpacity = 1.0;
    isScrolling = false;
    isAppBarActive = false;
    if (scrollController.hasClients) {
      scrollController.animateTo(_originalHeight, duration: const Duration(seconds: 0), curve: Curves.ease);
    }
    setState(() {});
  }

  void _initBloc() {
    if (widget.argument.status == AppBarStatus.none) {
      initiativeBloc.add(GetInitiativeListEvent(widget.argument.implementationId));
    } else {
      initiativeBloc.add(InitiativeStatusChange(widget.argument.status));
    }
    uid = context.read<AppBloc>().user!.uid;
  }

  void _addScrollListener() {
    scrollController.addListener(() {
      double offset = scrollController.offset;
      double newHeight = _originalHeight - offset;
      if (newHeight < 0) newHeight = 0;
      if (newHeight > _originalHeight) newHeight = _originalHeight;

      double newOpacity = newHeight / _originalHeight;
      if (newOpacity < 0.8) newOpacity = 0;

      _searchBarHeight = newHeight;
      _textFieldOpacity = newOpacity;

      if (scrollController.offset >= 70.h) {
        setState(() {
          isScrolling = true;
        });
      } else {
        setState(() {
          isScrolling = false;
        });
      }
    });
    isAppBarActive = isScrolling;
  }

  Function() _suffixOnTap(InitiativeState state) {
    return () {
      if (state is AddInitiative) {
        initiativeBloc.add(AddInitiativeEvent(
          userId: uid,
          implementationId: widget.argument.implementationId,
          initiativeTitle: title.text,
        ));
      } else if (state is InitiativeSuccessState) {
        initiativeBloc.add(InitiativeStatusChange(AppBarStatus.add));
      } else if (state is ViewInitiativeSuccessState) {
        initiativeBloc
          ..add(InitiativeStatusChange(AppBarStatus.edit))
          ..add(EditInitiativeInitialEvent(userId: uid, initiative: state.initiative));
      } else if ((state is EditInitiativeUpdateState)) {
        initiativeBloc.add(EditInitiativeDataEvent(
          implementationId: widget.argument.implementationId,
          initiativeTitle: title.text,
          userId: uid,
          initiative: state.initiative,
        ));
      }
    };
  }

  Function() _prefixOnTap(InitiativeState state) {
    return () {
      if (state is InitiativeActionState) {
        initiativeBloc.add(GetInitiativeListEvent(widget.argument.implementationId));
      } else {
        Navigator.pop(context);
      }
    };
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      toolbarHeight: 0,
      automaticallyImplyLeading: false,
      centerTitle: true,
      backgroundColor: isAppBarActive ? AppThemeData.white : Colors.transparent,
      systemOverlayStyle: SystemUiOverlayStyle(
        statusBarColor: isAppBarActive ? AppThemeData.white : Colors.transparent,
        statusBarIconBrightness: Brightness.dark, // For Android (dark icons)
        statusBarBrightness: Brightness.light, // For iOS (dark icons)
      ),
    );
  }

  Widget _buildInitiativesBackgroundImage() {
    return Align(
      alignment: Alignment.centerRight,
      child: Image.asset(
        AppAsset.initiativeBgImage,
        color: AppThemeData.cyan,
      ),
    );
  }

  String _getInitiativeTitle(InitiativeState state) {
    String title = AppString.initiatives;
    if (state is AddInitiative) {
      title = AppString.addInitiative;
    } else if (state is ViewInitiative || (state is DeleteInitiative)) {
      title = AppString.viewInitiative;
    } else if (state is EditInitiative) {
      title = AppString.editInitiative;
    }
    return title;
  }

  AppBarStatus getInitiativeActiveStatus(InitiativeState status) {
    if ((status is AddInitiative)) {
      return AppBarStatus.add;
    } else if ((status is ViewInitiative) || (status is DeleteInitiative)) {
      return AppBarStatus.view;
    } else if (status is EditInitiative) {
      return AppBarStatus.edit;
    } else {
      return AppBarStatus.none;
    }
  }

  Widget _prefixIcon(InitiativeState state) {
    String prefixIcon = AppAsset.backArrow;
    if (state is AddInitiative) {
      prefixIcon = AppAsset.crossActive;
    } else if (state is ViewInitiative || (state is DeleteInitiative)) {
      prefixIcon = AppAsset.backArrowActive;
    } else if (state is EditInitiative) {
      prefixIcon = AppAsset.crossActive;
    } else if (state is InitiativeSuccessState && isScrolling) {
      prefixIcon = AppAsset.backArrowActive;
    }
    return SvgPicture.asset(
      prefixIcon,
      height: 24.w,
      width: 24.w,
    );
  }

  Widget _suffixIcon(InitiativeState state) {
    String suffixIcon = AppAsset.add;
    if (state is AddInitiative) {
      suffixIcon = AppAsset.tickActive;
    } else if (state is ViewInitiative || (state is DeleteInitiative)) {
      suffixIcon = AppAsset.editActive;
    } else if (state is EditInitiative) {
      suffixIcon = AppAsset.tickActive;
    } else if (state is InitiativeSuccessState && isScrolling) {
      suffixIcon = AppAsset.addActive;
    }
    return SvgPicture.asset(
      suffixIcon,
      height: 24.w,
      width: 24.w,
    );
  }

  Widget _buildMoreIcon(InitiativeState state) {
    return InitiativeMoreOptionPopup(
      onDeleteTap: () {
        Navigator.pushNamed(context, "Invite collaboration screen");
      },
      onInviteTap: () async {
        if (state is ViewInitiativeSuccessState) {
          isShowPopup = false;
          initiativeBloc.add(DeleteInitiativeEvent(
            implementationId: widget.argument.implementationId,
            initiativeId: state.initiative.id ?? "",
          ));
        }
      },
    );
  }
}
