abstract class SectionModel {
  final String? id;
  final String? refId;
  final String? title;
  final int? type;
  final int? index;
  final String? createdBy;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  SectionModel({
    this.id,
    this.refId,
    this.title,
    this.type,
    this.index,
    this.createdBy,
    this.createdAt,
    this.updatedAt,
  });
}
