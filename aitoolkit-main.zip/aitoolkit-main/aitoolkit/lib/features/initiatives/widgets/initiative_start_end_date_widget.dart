import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../../widgets/primary_container.dart';

class InitiativeStartEndDateWidget extends StatelessWidget {
  const InitiativeStartEndDateWidget({
    super.key,
    required this.startDate,
    required this.endDate,
    required this.startTimeOnTap,
    required this.endTimeOnTap,
  });

  final DateTime? startDate;
  final DateTime? endDate;
  final Function()? startTimeOnTap;
  final Function()? endTimeOnTap;

  @override
  Widget build(BuildContext context) {
    bool showProgress = (startDate != null && endDate != null);
    double? progressValue = showProgress ? Utils.getProgressBetweenDateTime(startDate!, endDate!) : null;
    return PrimaryContainer(
      width: double.infinity,
      gradient: LinearGradient(
        colors: const [AppThemeData.saffronYellow, AppThemeData.white],
        stops: progressValue != null ? [progressValue, progressValue] : [0.5, 0.5],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          GestureDetector(
            onTap: startTimeOnTap,
            child: Container(
              padding: EdgeInsets.fromLTRB(10.w, 8.h, 0.w, 8.h),
              color: Colors.transparent,
              child: Row(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  SvgPicture.asset(
                    AppAsset.timer,
                    height: 15.w,
                    width: 15.w,
                    colorFilter: const ColorFilter.mode(AppThemeData.darkTeal, BlendMode.srcIn),
                  ),
                  SizedBox(width: 10.w),
                  Text(
                    AppString.startDate,
                    style: AppTextStyle.defaultF10W5Primary.copyWith(color: AppThemeData.darkTeal),
                  ),
                  buildVerticalDivider(),
                  Text(
                    (startDate != null) ? startDate!.appDefaultDateFormat : "YYYY-MM-DD",
                    style: AppTextStyle.defaultF10W5Primary.copyWith(color: AppThemeData.darkTeal),
                  ),
                ],
              ),
            ),
          ),
          GestureDetector(
            onTap: endTimeOnTap,
            child: Container(
              padding: EdgeInsets.fromLTRB(0.w, 8.h, 10.w, 8.h),
              color: Colors.transparent,
              child: Row(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.end,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    (endDate != null) ? endDate!.appDefaultDateFormat : "YYYY-MM-DD",
                    style: AppTextStyle.defaultF10W5Primary.copyWith(color: AppThemeData.grey700),
                  ),
                  buildVerticalDivider(),
                  Text(
                    AppString.endDate,
                    style: AppTextStyle.defaultF10W5Primary.copyWith(color: AppThemeData.grey700),
                  ),
                  SizedBox(width: 10.w),
                  SvgPicture.asset(
                    AppAsset.timer,
                    height: 15.w,
                    width: 15.w,
                    colorFilter: ColorFilter.mode(AppThemeData.grey700, BlendMode.srcIn),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget buildVerticalDivider() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 10.w),
      height: 11.h,
      width: 1.w,
      color: AppThemeData.lightYellow,
    );
  }
}
