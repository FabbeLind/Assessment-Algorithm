import 'package:app_utils/app_theme.dart';
import 'package:app_utils/constants/constants.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../../widgets/primary_container.dart';

class AddInitiativeOptionCard extends StatelessWidget {
  const AddInitiativeOptionCard({
    super.key,
    required this.icon,
    required this.title,
  });

  final String icon;
  final String title;

  @override
  Widget build(BuildContext context) {
    return PrimaryContainer(
      padding: EdgeInsets.all(4.w),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          SvgPicture.asset(
            icon,
            height: 24.w,
            width: 24.w,
            colorFilter: const ColorFilter.mode(AppThemeData.lightYellow, BlendMode.srcIn),
          ),
          SizedBox(width: 7.w),
          Text(
            title.toUpperCase(),
            style: AppTextStyle.defaultF10W7Primary.copyWith(height: 1.3),
          ),
          SizedBox(width: 6.w),
          SvgPicture.asset(
            AppAsset.add,
            height: 24.w,
            width: 24.w,
            colorFilter: const ColorFilter.mode(AppThemeData.deepBlue, BlendMode.srcIn),
          )
        ],
      ),
    );
  }
}
