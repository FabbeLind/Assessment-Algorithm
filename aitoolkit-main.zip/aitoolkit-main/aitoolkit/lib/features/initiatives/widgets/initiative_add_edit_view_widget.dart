import 'package:aitoolkit/features/initiatives/bloc/initiative_bloc.dart';
import 'package:aitoolkit/features/initiatives/model/task_model.dart';
import 'package:aitoolkit/features/initiatives/widgets/add_initiative_option_card.dart';
import 'package:aitoolkit/features/initiatives/widgets/initiative_list_section_card.dart';
import 'package:aitoolkit/features/initiatives/widgets/initiative_text_section_card.dart';
import 'package:aitoolkit/widgets/app_snackbar.dart';
import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../widgets/dialogs/primary_date_picker.dart';
import '../model/initiative_active_option_model.dart';
import 'initiative_start_end_date_widget.dart';

class InitiativeAddEditViewWidget extends StatefulWidget {
  const InitiativeAddEditViewWidget({
    super.key,
    required this.initiativeStatus,
    required this.initiativeBloc,
    required this.readOnly,
  });

  final AppBarStatus initiativeStatus;
  final InitiativeBloc initiativeBloc;
  final bool readOnly;

  @override
  State<InitiativeAddEditViewWidget> createState() => _InitiativeAddEditViewWidgetState();
}

class _InitiativeAddEditViewWidgetState extends State<InitiativeAddEditViewWidget> {
  @override
  void initState() {
    if (widget.initiativeStatus == AppBarStatus.add) {
      widget.initiativeBloc.setDefaultInitiativeData();
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Scrollbar(
        child: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(height: 20.h),
              _buildInitiativeStartEndDateWidget(context).paddingSymmetric(horizontal: 15.w),
              SizedBox(height: 25.h),
              if (widget.initiativeBloc.activeOptionList.isNotEmpty) ...[
                Theme(
                  data: Theme.of(context).copyWith(
                    canvasColor: Colors.transparent,
                    shadowColor: Colors.transparent,
                  ),
                  child: ReorderableListView(
                    physics: const NeverScrollableScrollPhysics(),
                    shrinkWrap: true,
                    buildDefaultDragHandles: !widget.readOnly,
                    onReorderStart: (index) {
                      HapticFeedback.heavyImpact();
                    },
                    onReorderEnd: (index) {
                      HapticFeedback.lightImpact();
                    },
                    onReorder: (int oldIndex, int newIndex) {
                      setState(() {
                        if (oldIndex < newIndex) {
                          newIndex -= 1;
                        }
                        final item = widget.initiativeBloc.activeOptionList.removeAt(oldIndex);
                        widget.initiativeBloc.activeOptionList.insert(newIndex, item);
                      });
                    },
                    children: widget.initiativeBloc.activeOptionList.map((element) => element.widget).toList(),
                  ),
                ),
                SizedBox(height: 20.h),
              ],
              if (!widget.readOnly) _buildAddInitiativeOptionWidget().paddingSymmetric(horizontal: 15.w),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInitiativeStartEndDateWidget(BuildContext context) {
    return InitiativeStartEndDateWidget(
      startDate: widget.initiativeBloc.startTime,
      endDate: widget.initiativeBloc.endTime,
      startTimeOnTap: (!widget.readOnly)
          ? () async {
              await PrimaryDatePickerBottomSheet.show(
                context,
                onDateTimeChanged: (value) {
                  widget.initiativeBloc.startTime = value.startTimeOfDate;
                  setState(() {});
                },
              ).then((_) {
                if (widget.initiativeBloc.startTime == null) {
                  setState(() {
                    widget.initiativeBloc.startTime = DateTime.now().startTimeOfDate;
                  });
                }
              });
            }
          : null,
      endTimeOnTap: (!widget.readOnly)
          ? () async {
              if (widget.initiativeBloc.startTime != null) {
                await PrimaryDatePickerBottomSheet.show(
                  context,
                  onDateTimeChanged: (value) {
                    widget.initiativeBloc.endTime = value.endTimeOfDate;
                    setState(() {});
                  },
                ).then((_) {
                  if (widget.initiativeBloc.endTime == null) {
                    setState(() {
                      widget.initiativeBloc.endTime = DateTime.now().endTimeOfDate;
                    });
                  }
                });
              } else {
                AppSnackBar.showError(context, AppString.selectStartDate);
              }
            }
          : null,
    );
  }

  Widget _buildAddInitiativeOptionWidget() {
    return Align(
      alignment: Alignment.centerLeft,
      child: Wrap(
        alignment: WrapAlignment.start,
        runAlignment: WrapAlignment.start,
        crossAxisAlignment: WrapCrossAlignment.start,
        runSpacing: 20.h,
        spacing: 20.w,
        children: List.generate(
          widget.initiativeBloc.optionList.length,
          (index) {
            final option = widget.initiativeBloc.optionList[index];
            return GestureDetector(
              onTap: () {
                widget.initiativeBloc.optionList.removeAt(index);
                onAddOptionClick(option);
                setState(() {});
              },
              child: AddInitiativeOptionCard(
                icon: option.icon,
                title: option.title,
              ),
            );
          },
        ),
      ),
    );
  }

  void onAddOptionClick(InitiativeOptionEnum option) {
    switch (option.title) {
      case AppString.goals:
        widget.initiativeBloc.activeOptionList.add(
          InitiativeActiveOptionModel(
            option: InitiativeOptionEnum.goals,
            index: widget.initiativeBloc.activeOptionList.length,
            sectionType: SectionType.list,
            widget: _buildTaskOptionCard(
              option: option,
              index: widget.initiativeBloc.activeOptionList.length,
              taskList: widget.initiativeBloc.goalList,
            ),
          ),
        );
        break;
      case AppString.objectives:
        widget.initiativeBloc.activeOptionList.add(
          InitiativeActiveOptionModel(
            option: InitiativeOptionEnum.objectives,
            index: widget.initiativeBloc.activeOptionList.length,
            sectionType: SectionType.list,
            widget: _buildTaskOptionCard(
              option: option,
              index: widget.initiativeBloc.activeOptionList.length,
              taskList: widget.initiativeBloc.objectiveList,
            ),
          ),
        );
        break;
      case AppString.vision:
        widget.initiativeBloc.activeOptionList.add(
          InitiativeActiveOptionModel(
            option: InitiativeOptionEnum.vision,
            index: widget.initiativeBloc.activeOptionList.length,
            sectionType: SectionType.text,
            widget: _buildTextOptionCard(
              option: option,
              index: widget.initiativeBloc.activeOptionList.length,
              controller: widget.initiativeBloc.vision,
            ),
          ),
        );
        break;
      case AppString.description:
        widget.initiativeBloc.activeOptionList.add(
          InitiativeActiveOptionModel(
            option: InitiativeOptionEnum.description,
            index: widget.initiativeBloc.activeOptionList.length,
            sectionType: SectionType.text,
            widget: _buildTextOptionCard(
              option: option,
              index: widget.initiativeBloc.activeOptionList.length,
              controller: widget.initiativeBloc.description,
            ),
          ),
        );
        break;
    }
  }

  Widget _buildTaskOptionCard({
    required InitiativeOptionEnum option,
    required int index,
    required List<TaskModel> taskList,
  }) {
    return InitiativeOptionTaskInputCard(
      key: Key(option.title),
      option: option,
      readOnly: widget.readOnly,
      onCloseTap: () {
        widget.initiativeBloc.optionList.add(option);
        widget.initiativeBloc.activeOptionList.removeWhere((element) => element.option.title == option.title);
        taskList.clear();
        setState(() {});
      },
      taskList: taskList,
      onChanged: (updatedList) {
        taskList.clear();
        taskList.addAll(updatedList);
        setState(() {});
      },
    );
  }

  Widget _buildTextOptionCard({
    required InitiativeOptionEnum option,
    required int index,
    required TextEditingController controller,
  }) {
    return InitiativeTextSectionCard(
      readOnly: widget.readOnly,
      key: Key(option.title),
      option: option,
      controller: controller,
      onCloseTap: () {
        widget.initiativeBloc.optionList.add(option);
        widget.initiativeBloc.activeOptionList.removeWhere((element) => element.option.title == option.title);
        controller.clear();
        setState(() {});
      },
    );
  }
}
