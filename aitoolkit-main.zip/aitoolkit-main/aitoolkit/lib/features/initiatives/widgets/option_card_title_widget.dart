import 'package:app_utils/app_theme.dart';
import 'package:app_utils/constants/constants.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';

class OptionCardTitleWidget extends StatelessWidget {
  const OptionCardTitleWidget({
    super.key,
    required this.iconPath,
    required this.title,
    required this.onCloseTap,
    required this.readOnly,
  });

  final String iconPath;
  final String title;
  final Function() onCloseTap;
  final bool readOnly;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              SvgPicture.asset(
                iconPath,
                height: 10.w,
                width: 10.w,
                colorFilter: const ColorFilter.mode(AppThemeData.yellow500, BlendMode.srcIn),
              ),
              SizedBox(width: 6.w),
              Text(
                title,
                style: AppTextStyle.title3.copyWith(height: 1.25),
              ),
            ],
          ),
        ),
        readOnly
            ? SizedBox(
                height: 24.w,
                width: 24.w,
              )
            : GestureDetector(
                onTap: onCloseTap,
                child: Container(
                  color: Colors.transparent,
                  child: SvgPicture.asset(
                    AppAsset.remove,
                    height: 24.w,
                    width: 24.w,
                  ),
                ),
              ),
      ],
    );
  }
}
