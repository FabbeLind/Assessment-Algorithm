import 'package:aitoolkit/widgets/get_started_widget.dart';
import 'package:app_utils/constants/constants.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class CreateInitiativeInfoCard extends StatelessWidget {
  const CreateInitiativeInfoCard({
    super.key,
    required this.onTap,
    this.width,
  });

  final Function() onTap;
  final double? width;

  @override
  Widget build(BuildContext context) {
    return GetStartedCardWidget(
      width: width,
      image: AppAsset.rocket,
      imageSize: 30.h,
      title: AppString.createInitiative,
      description: AppString.createInitiativeDesc,
      onTap: onTap,
    );
  }
}
