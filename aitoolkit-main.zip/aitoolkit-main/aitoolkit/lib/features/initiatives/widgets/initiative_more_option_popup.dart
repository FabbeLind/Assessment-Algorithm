import 'package:aitoolkit/widgets/primary_pop_up.dart';
import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../../widgets/app_pop_up_item.dart';
import '../../../widgets/primary_container.dart';

class InitiativeMoreOptionPopup extends StatelessWidget {
  const InitiativeMoreOptionPopup({
    super.key,
    required this.onDeleteTap,
    required this.onInviteTap,
  });

  final Function() onDeleteTap;
  final Function() onInviteTap;

  @override
  Widget build(BuildContext context) {
    return PrimaryPopUp(
      icon: _buildMoreIcon(),
      child: PrimaryContainer(
        radius: 8.r,
        width: 194.w,
        boxShadow: [
          BoxShadow(
            offset: const Offset(1, 2),
            blurRadius: 5,
            spreadRadius: 0,
            color: AppThemeData.secondaryShadowColor,
          )
        ],
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            AppPopUpItem(
              title: AppString.inviteCollaborator,
              icon: AppAsset.invite,
              onTap: onInviteTap,
            ),
            Divider(
              color: AppThemeData.lightDividerColor,
              thickness: 1.h,
              height: 0,
            ),
            AppPopUpItem(
              title: AppString.deleteInitiative,
              icon: AppAsset.delete,
              onTap: onDeleteTap,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMoreIcon() {
    return SvgPicture.asset(
      AppAsset.more,
      height: 22.w,
      width: 22.w,
    ).addTapAreaAll(10.w);
  }
}
