import 'package:aitoolkit/features/initiatives/widgets/delete_action_pane.dart';
import 'package:aitoolkit/features/initiatives/widgets/option_card_title_widget.dart';
import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../../widgets/primary_container.dart';
import '../../../widgets/primary_text_field.dart';

class InitiativeTextSectionCard extends StatefulWidget {
  const InitiativeTextSectionCard({
    super.key,
    required this.controller,
    required this.option,
    required this.onCloseTap,
    required this.readOnly,
  });

  final TextEditingController controller;
  final InitiativeOptionEnum option;
  final Function() onCloseTap;
  final bool readOnly;

  @override
  State<InitiativeTextSectionCard> createState() => _InitiativeTextSectionCardState();
}

class _InitiativeTextSectionCardState extends State<InitiativeTextSectionCard> {
  late FocusNode focusNode;

  @override
  void initState() {
    super.initState();
    focusNode = FocusNode();
  }

  @override
  void dispose() {
    focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        if (!focusNode.hasFocus) {
          focusNode.requestFocus();
        }
      },
      child: Slidable(
        endActionPane: !widget.readOnly
            ? ActionPane(
                motion: const DrawerMotion(),
                extentRatio: 0.3,
                dragDismissible: false,
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: () {
                        widget.onCloseTap.call();
                        setState(() {});
                      },
                      child: const DeleteActionPane(),
                    ),
                  ),
                ],
              )
            : null,
        child: Builder(builder: (context) {
          return PrimaryContainer(
            margin: EdgeInsets.symmetric(vertical: 10.h, horizontal: 15.w),
            constraints: BoxConstraints(minHeight: 158.h),
            padding: EdgeInsets.only(
              left: 25.w,
              right: 15.w,
              top: 5.h,
              bottom: 45.h,
            ),
            child: Stack(
              children: [
                Column(
                  children: [
                    OptionCardTitleWidget(
                      title: widget.option.title,
                      iconPath: widget.option.icon,
                      readOnly: widget.readOnly,
                      onCloseTap: () {
                        final controller = Slidable.of(context)!;
                        final isClosed = controller.actionPaneType.value ==
                            ActionPaneType.none; // you can use this to check if its closed
                        if (isClosed) {
                          controller.openEndActionPane();
                        } else {
                          controller.close();
                        }
                      },
                    ),
                    SizedBox(height: 20.h),
                    PrimaryTextField(
                      isDense: true,
                      focusNode: focusNode,
                      readOnly: widget.readOnly,
                      controller: widget.controller,
                      contentPadding: EdgeInsets.zero,
                      keyboardType: TextInputType.multiline,
                      border: InputBorder.none,
                    ),
                  ],
                ),
                if (!widget.readOnly)
                  Align(
                    alignment: Alignment.topCenter,
                    child: _buildDragIcon(),
                  ),
              ],
            ),
          );
        }),
      ),
    );
  }

  Widget _buildDragIcon() {
    return Container(
      color: Colors.transparent,
      child: SvgPicture.asset(
        AppAsset.dragCard,
        height: 15.w,
      ),
    );
  }
}
