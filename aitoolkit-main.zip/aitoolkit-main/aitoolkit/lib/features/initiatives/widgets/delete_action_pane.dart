import 'package:app_utils/app_theme.dart';
import 'package:app_utils/constants/constants.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class DeleteActionPane extends StatelessWidget {
  const DeleteActionPane({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox.expand(
      child: Container(
        margin: EdgeInsets.symmetric(vertical: 10.h),
        decoration: BoxDecoration(
            color: AppThemeData.red,
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(8.r),
              bottomLeft: Radius.circular(8.r),
            )),
        child: Center(
          child: Text(
            AppString.delete,
            textAlign: TextAlign.center,
            style: AppTextStyle.defaultF16W7Secondary,
          ),
        ),
      ),
    );
  }
}
