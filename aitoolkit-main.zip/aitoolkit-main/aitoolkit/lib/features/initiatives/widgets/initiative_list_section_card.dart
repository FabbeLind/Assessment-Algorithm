import 'package:aitoolkit/features/initiatives/model/task_model.dart';
import 'package:aitoolkit/features/initiatives/widgets/delete_action_pane.dart';
import 'package:aitoolkit/features/initiatives/widgets/option_card_title_widget.dart';
import 'package:aitoolkit/widgets/primary_container.dart';
import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../../widgets/primary_text_field.dart';

class InitiativeOptionTaskInputCard extends StatefulWidget {
  const InitiativeOptionTaskInputCard({
    super.key,
    required this.onCloseTap,
    required this.taskList,
    required this.onChanged,
    required this.option,
    required this.readOnly,
  });

  final InitiativeOptionEnum option;
  final bool readOnly;
  final List<TaskModel> taskList;
  final Function() onCloseTap;
  final Function(List<TaskModel> taskList) onChanged;

  @override
  State<InitiativeOptionTaskInputCard> createState() => _InitiativeOptionTaskInputCardState();
}

class _InitiativeOptionTaskInputCardState extends State<InitiativeOptionTaskInputCard>
    with SingleTickerProviderStateMixin {
  List<TextEditingController> taskControllerList = [];
  List<FocusNode> focusNodeList = [];

  @override
  void initState() {
    taskControllerList.clear();
    focusNodeList.clear();
    for (int i = 0; i < widget.taskList.length; i++) {
      taskControllerList.add(TextEditingController(text: widget.taskList[i].text));
      focusNodeList.add(FocusNode());
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Slidable(
      endActionPane: !widget.readOnly
          ? ActionPane(
              motion: const DrawerMotion(),
              extentRatio: 0.3,
              dragDismissible: false,
              children: [
                Expanded(
                  child: GestureDetector(
                    onTap: () {
                      widget.onCloseTap.call();
                      setState(() {});
                    },
                    child: const DeleteActionPane(),
                  ),
                ),
              ],
            )
          : null,
      child: Builder(builder: (context) {
        return PrimaryContainer(
          constraints: BoxConstraints(minHeight: 158.h),
          margin: EdgeInsets.symmetric(vertical: 10.h, horizontal: 15.w),
          padding: EdgeInsets.only(top: 5.h, bottom: 20.h),
          child: Stack(
            children: [
              Column(
                children: [
                  OptionCardTitleWidget(
                    title: widget.option.title,
                    iconPath: widget.option.icon,
                    readOnly: widget.readOnly,
                    onCloseTap: () {
                      final controller = Slidable.of(context)!;
                      final isClosed = controller.actionPaneType.value ==
                          ActionPaneType.none; // you can use this to check if its closed
                      if (isClosed) {
                        controller.openEndActionPane();
                      } else {
                        controller.close();
                      }
                    },
                  ).paddingOnly(left: 25.w, right: 15.w),
                  SizedBox(height: 20.h),
                  if (widget.taskList.isNotEmpty)
                    ReorderableListView(
                      buildDefaultDragHandles: !widget.readOnly,
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      padding: EdgeInsets.only(
                        left: 4.w,
                        right: 25.w,
                      ),
                      children: [
                        for (int index = 0; index < taskControllerList.length; index++)
                          Column(
                            key: Key(index.toString()),
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Row(
                                children: [
                                  widget.readOnly
                                      ? SizedBox(width: 15.w)
                                      : ReorderableDragStartListener(
                                          key: ValueKey<int>(index),
                                          index: index,
                                          child: Container(
                                            padding: EdgeInsets.all(3.w),
                                            child: SvgPicture.asset(
                                              AppAsset.dragList,
                                              height: 15.w,
                                              width: 15.w,
                                            ),
                                          ),
                                        ),
                                  SizedBox(width: 4.w),
                                  Expanded(
                                    child: PrimaryTextField(
                                      isDense: true,
                                      maxLines: 1,
                                      style: AppTextStyle.title3,
                                      border: InputBorder.none,
                                      readOnly: widget.readOnly,
                                      controller: taskControllerList[index],
                                      focusNode: focusNodeList[index],
                                      contentPadding: EdgeInsets.zero,
                                      onChanged: (value) {
                                        updateTaskList();
                                      },
                                    ),
                                  ),
                                  if (!widget.readOnly)
                                    GestureDetector(
                                      onTap: () {
                                        setState(() {
                                          taskControllerList.removeAt(index);
                                          focusNodeList.removeAt(index);
                                          updateTaskList();
                                        });
                                      },
                                      child: SvgPicture.asset(
                                        AppAsset.crossActive,
                                        height: 18.w,
                                        width: 18.w,
                                      ),
                                    ),
                                ],
                              ),
                              _buildDivider().paddingOnly(left: 19.w),
                            ],
                          )
                      ],
                      onReorderStart: (index) {
                        HapticFeedback.heavyImpact();
                      },
                      onReorderEnd: (index) {
                        HapticFeedback.lightImpact();
                      },
                      onReorder: (oldIndex, newIndex) {
                        setState(() {
                          if (oldIndex < newIndex) {
                            newIndex -= 1;
                          }
                          final item = taskControllerList.removeAt(oldIndex);
                          final focusNode = focusNodeList.removeAt(oldIndex);
                          taskControllerList.insert(newIndex, item);
                          focusNodeList.insert(newIndex, focusNode);
                          updateTaskList();
                        });
                      },
                    ),
                  if (!widget.readOnly) _buildAddMoreWidget(),
                ],
              ),
              if (!widget.readOnly)
                Align(
                  alignment: Alignment.topCenter,
                  child: _buildDragIcon(),
                )
            ],
          ),
        );
      }),
    );
  }

  Widget _buildDragIcon() {
    return Container(
      color: Colors.transparent,
      child: SvgPicture.asset(
        AppAsset.dragCard,
        height: 15.w,
      ),
    );
  }

  void updateTaskList() {
    List<TaskModel> taskList = [];
    for (int i = 0; i < taskControllerList.length; i++) {
      taskList.add(TaskModel(
        text: taskControllerList[i].text,
        index: i,
      ));
    }
    widget.onChanged.call(taskList);
    setState(() {});
  }

  Widget _buildDivider() {
    return Divider(
      height: 16.h,
      thickness: 1.h,
      color: AppThemeData.lightDividerColor,
    );
  }

  Widget _buildAddMoreWidget() {
    return GestureDetector(
      onTap: () {
        taskControllerList.add(TextEditingController());
        focusNodeList.add(FocusNode());
        updateTaskList();
        focusNodeList.last.requestFocus();
        setState(() {});
      },
      child: Container(
        color: Colors.transparent,
        padding: EdgeInsets.only(
          left: 4.w,
          right: 25.w,
        ),
        child: Row(
          children: [
            SizedBox(width: 19.w),
            Expanded(
              child: Text(
                AppString.addMore,
                style: AppTextStyle.title3.copyWith(
                  fontStyle: FontStyle.italic,
                  color: AppThemeData.grey700,
                ),
              ),
            ),
            SvgPicture.asset(
              AppAsset.addActive,
              height: 18.w,
              width: 18.w,
            ),
          ],
        ),
      ),
    );
  }
}
