import 'package:aitoolkit/features/initiatives/widgets/create_initiative_info_card.dart';
import 'package:aitoolkit/widgets/app_search_text_field.dart';
import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../widgets/work_info_card.dart';
import '../../app/bloc/app_bloc.dart';
import '../model/initiative_model.dart';

class InitiativeListViewWidget extends StatefulWidget {
  const InitiativeListViewWidget({
    super.key,
    required this.scrollController,
    required this.initiativeList,
    required this.onWorkTap,
    required this.searchController,
    required this.focusNode,
    required this.createInitiativeOnTap,
    required this.searchBarHeight,
    required this.textFieldOpacity,
  });

  final ScrollController scrollController;
  final List<InitiativeModel> initiativeList;
  final Function(InitiativeModel) onWorkTap;
  final TextEditingController searchController;
  final FocusNode focusNode;
  final Function() createInitiativeOnTap;
  final double searchBarHeight;
  final double textFieldOpacity;

  @override
  State<InitiativeListViewWidget> createState() => _InitiativeListViewWidgetState();
}

class _InitiativeListViewWidgetState extends State<InitiativeListViewWidget> {
  List<InitiativeModel> searchInitiativeList = [];

  @override
  Widget build(BuildContext context) {
    var theme = Theme.of(context).colorScheme;
    AppBloc appBloc = context.read<AppBloc>();

    if (widget.initiativeList.isNotEmpty) {
      return Expanded(
        child: Stack(
          children: [
            ((widget.searchController.text.isEmpty && widget.initiativeList.isNotEmpty) ||
                    (widget.searchController.text.isNotEmpty && searchInitiativeList.isNotEmpty))
                ? Scrollbar(
                    controller: widget.scrollController,
                    child: ListView.separated(
                      controller: widget.scrollController,
                      padding: EdgeInsets.only(
                        top: widget.initiativeList.length > 3 ? 70.h : 10.h,
                        bottom: 20.h,
                        left: 15.w,
                        right: 15.w,
                      ),
                      itemCount: widget.searchController.text.isNotEmpty
                          ? searchInitiativeList.length
                          : widget.initiativeList.length,
                      itemBuilder: (context, index) {
                        final initiative = widget.searchController.text.isNotEmpty
                            ? searchInitiativeList[index]
                            : widget.initiativeList[index];
                        final progress = Utils.getProgressBetweenDateTime(initiative.startTime, initiative.endTime);
                        return GestureDetector(
                          onTap: () {
                            widget.onWorkTap.call(initiative);
                          },
                          child: WorkInfoCard(
                            progress: progress,
                            title: initiative.title,
                            desc: AppString.aiEnhancedVirtualFittingDesc,
                            profileImage: appBloc.user?.profileImage,
                            workEndDate: initiative.endTime,
                          ),
                        );
                      },
                      separatorBuilder: (context, index) => SizedBox(height: 20.h),
                    ),
                  )
                : const SizedBox.shrink(),
            widget.initiativeList.length > 3 ? _buildSearchBar(theme) : const SizedBox.shrink(),
          ],
        ),
      );
    } else {
      return CreateInitiativeInfoCard(
        onTap: widget.createInitiativeOnTap,
      ).paddingSymmetric(
        horizontal: 15.w,
        vertical: 5.h,
      );
    }
  }

  Widget _buildSearchBar(ColorScheme theme) {
    return Positioned(
        top: 0,
        left: 15.w,
        right: 15.w,
        child: AppSearchTextField(
          focusNode: widget.focusNode,
          searchBarHeight: widget.searchBarHeight,
          textFieldOpacity: widget.textFieldOpacity,
          controller: widget.searchController,
          onChange: (value) {
            filterSearchInitiativeList(value);
          },
        ));
  }

  void filterSearchInitiativeList(String searchText) {
    searchInitiativeList.clear();
    for (int i = 0; i < widget.initiativeList.length; i++) {
      if (widget.initiativeList[i].title.toLowerCase().contains(searchText.toLowerCase())) {
        searchInitiativeList.add(widget.initiativeList[i]);
      }
    }
    setState(() {});
  }
}
