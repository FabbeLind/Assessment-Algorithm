import 'package:aitoolkit/features/initiatives/entities/section_model.dart';
import 'package:aitoolkit/features/initiatives/model/task_model.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class ListSectionModel extends SectionModel {
  ListSectionModel({
    super.id,
    super.refId,
    required super.title,
    super.type = 1,
    super.createdBy,
    super.createdAt,
    super.updatedAt,
    required super.index,
    this.list = const <TaskModel>[],
  });

  final List<TaskModel> list;

  factory ListSectionModel.fromMap(Map<String, dynamic> json) => ListSectionModel(
        id: json["id"],
        refId: json["refId"],
        title: json["title"],
        type: json["type"],
        index: json["index"],
        createdBy: json["createdBy"],
        createdAt: (json["createdAt"] as Timestamp).toDate(),
        updatedAt: (json["updatedAt"] as Timestamp).toDate(),
      );

  Map<String, dynamic> toMap() {
    DateTime now = DateTime.now();
    return {
      "id": id,
      "refId": refId,
      "title": title,
      "type": type,
      "index": index,
      "createdBy": createdBy,
      "createdAt": Timestamp.fromDate(createdAt ?? now),
      "updatedAt": Timestamp.fromDate(updatedAt ?? now),
    };
  }

  ListSectionModel copyWith({
    String? id,
    String? refId,
    String? title,
    int? type,
    int? index,
    String? createdBy,
    DateTime? createdAt,
    DateTime? updatedAt,
    List<TaskModel>? list,
  }) {
    return ListSectionModel(
      id: id ?? this.id,
      refId: refId ?? this.refId,
      title: title ?? this.title,
      type: type ?? this.type,
      index: index ?? this.index,
      createdBy: createdBy ?? this.createdBy,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      list: list ?? this.list,
    );
  }

  @override
  String toString() {
    return toMap().toString();
  }
}
