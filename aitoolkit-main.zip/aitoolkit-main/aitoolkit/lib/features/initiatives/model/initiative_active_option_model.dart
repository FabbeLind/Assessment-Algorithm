import 'package:aitoolkit/features/initiatives/entities/section_model.dart';
import 'package:app_utils/enums/app_enums.dart';
import 'package:flutter/cupertino.dart';

class InitiativeActiveOptionModel {
  final SectionModel? section;
  final InitiativeOptionEnum option;
  final int index;
  final SectionType sectionType;
  final Widget widget;

  InitiativeActiveOptionModel({
    required this.option,
    required this.index,
    required this.sectionType,
    required this.widget,
    this.section,
  });

  InitiativeActiveOptionModel copyWith({
    InitiativeOptionEnum? option,
    int? index,
    SectionType? sectionType,
    Widget? widget,
    SectionModel? section,
  }) {
    return InitiativeActiveOptionModel(
      option: option ?? this.option,
      index: index ?? this.index,
      sectionType: sectionType ?? this.sectionType,
      widget: widget ?? this.widget,
      section: section ?? this.section,
    );
  }
}
