class TaskModel {
  final String text;
  final int index;

  TaskModel({
    required this.text,
    required this.index,
  });

  factory TaskModel.fromMap(Map<String, dynamic> json) => TaskModel(
        text: json["text"],
        index: json["index"],
      );

  Map<String, dynamic> toMap() => {
        "text": text,
        "index": index,
      };

  @override
  String toString() {
    return toMap().toString();
  }
}
