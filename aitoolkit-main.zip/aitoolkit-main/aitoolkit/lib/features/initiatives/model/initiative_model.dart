import 'package:cloud_firestore/cloud_firestore.dart';

class InitiativeModel {
  final String? id;
  final String refId;
  final String title;
  final DateTime startTime;
  final DateTime endTime;
  final String createdBy;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  const InitiativeModel({
    this.id,
    required this.refId,
    required this.title,
    required this.startTime,
    required this.endTime,
    required this.createdBy,
    this.createdAt,
    this.updatedAt,
  });

  InitiativeModel copyWith({
    String? id,
    String? refId,
    String? title,
    DateTime? startTime,
    DateTime? endTime,
    String? createdBy,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return InitiativeModel(
      id: id ?? this.id,
      refId: refId ?? this.refId,
      title: title ?? this.title,
      startTime: startTime ?? this.startTime,
      endTime: endTime ?? this.endTime,
      createdBy: createdBy ?? this.createdBy,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  factory InitiativeModel.fromMap(Map<String, dynamic> json) => InitiativeModel(
        id: json["id"],
        refId: json["refId"],
        title: json["title"],
        startTime: (json["startTime"] as Timestamp).toDate(),
        endTime: (json["endTime"] as Timestamp).toDate(),
        createdBy: json["createdBy"],
        createdAt: (json["createdAt"] as Timestamp).toDate(),
        updatedAt: (json["updatedAt"] as Timestamp).toDate(),
      );

  Map<String, dynamic> toMap() => {
        "id": id,
        "refId": refId,
        "title": title,
        "startTime": Timestamp.fromDate(startTime),
        "endTime": Timestamp.fromDate(endTime),
        "createdBy": createdBy,
        "createdAt": (createdAt != null) ? Timestamp.fromDate(createdAt!) : null,
        "updatedAt": (updatedAt != null) ? Timestamp.fromDate(updatedAt!) : null,
      };

  @override
  String toString() {
    return toMap().toString();
  }
}
