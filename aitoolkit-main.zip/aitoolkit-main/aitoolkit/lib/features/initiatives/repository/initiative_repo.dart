import 'package:aitoolkit/features/initiatives/entities/section_model.dart';
import 'package:aitoolkit/features/initiatives/model/initiative_model.dart';
import 'package:aitoolkit/features/initiatives/model/list_section_model.dart';
import 'package:aitoolkit/features/initiatives/model/task_model.dart';
import 'package:aitoolkit/features/initiatives/model/text_section_model.dart';
import 'package:app_services/firebase/firebase_firestore_service.dart';
import 'package:app_utils/app_utils.dart';

part 'initiative_repo_impl.dart';

abstract class InitiativeRepo {
  static final InitiativeRepo _instance = _InitiativeRepoImpl();

  Future<List<InitiativeModel>> getInitiative({required String implementationId});

  Future<List<SectionModel>> getSection({
    required String implementationId,
    required String initiativeId,
  });

  Future<void> deleteInitiative({
    required String implementationId,
    required String initiativeId,
  });

  Future<void> addInitiative({
    required String implementationId,
    required List<SectionModel> section,
    required InitiativeModel initiativeModel,
  });

  Future<void> editInitiative({
    required String implementationId,
    required List<SectionModel> sectionModel,
    required InitiativeModel initiative,
    required Map<String, dynamic> updatedInitiative,
  });

  static InitiativeRepo get instance => _instance;
}
