part of 'initiative_repo.dart';

class _InitiativeRepoImpl extends InitiativeRepo {
  @override
  Future<List<InitiativeModel>> getInitiative({required String implementationId}) async {
    try {
      final initiativeData =
          await FirebaseFirestoreService.implementationCollection.doc(implementationId).collection("Initiatives").get();
      Debug.log("Initiatives list -->> ${initiativeData.docs.length}");
      List<InitiativeModel> initiativeList = [];
      if (initiativeData.docs.isNotEmpty) {
        for (var element in initiativeData.docs) {
          InitiativeModel initiative = InitiativeModel.fromMap(element.data());
          initiativeList.add(initiative);
        }
      }
      return initiativeList;
    } catch (e) {
      rethrow;
    }
  }

  @override
  Future<void> addInitiative({
    required String implementationId,
    required List<SectionModel> section,
    required InitiativeModel initiativeModel,
  }) async {
    try {
      DateTime now = DateTime.now();

      var initiative = initiativeModel.copyWith(id: '', createdAt: now, updatedAt: now);

      String initiativesId =
          await FirebaseFirestoreService.addInitiatives(implementationId, initiativesMap: initiative.toMap());

      if (section.isNotEmpty) {
        for (var element in section) {
          if (element.type == 0) {
            (element as TextSectionModel);
            var textSection = element.copyWith(id: '', refId: initiativesId, createdAt: now, updatedAt: now);

            await FirebaseFirestoreService.addInitiativesSection(implementationId, initiativesId,
                sectionMap: textSection.toMap(), dataText: textSection.text);
          } else if (element.type == 1) {
            (element as ListSectionModel);
            var listSection = element.copyWith(id: '', refId: initiativesId, updatedAt: now, createdAt: now);

            await FirebaseFirestoreService.addInitiativesSection(implementationId, initiativesId,
                sectionMap: listSection.toMap(), dataTextList: listSection.list.map((e) => e.toMap()).toList());
          }
        }
      }
    } catch (e) {
      rethrow;
    }
  }

  @override
  Future<List<SectionModel>> getSection({required String implementationId, required String initiativeId}) async {
    try {
      var sectionData = await FirebaseFirestoreService.getInitiativesSection(implementationId, initiativeId);
      if (sectionData.isNotEmpty) {
        List<SectionModel> sectionList = [];
        for (var element in sectionData) {
          switch (element["type"]) {
            case 0:
              TextSectionModel textSection = TextSectionModel.fromMap(element);
              List<Map<String, dynamic>> textSectionData =
                  await FirebaseFirestoreService.getSectionData(implementationId, initiativeId, textSection.id ?? '');
              textSection = textSection.copyWith(text: textSectionData.first["text"]);
              sectionList.add(textSection);
              break;
            case 1:
              ListSectionModel listSection = ListSectionModel.fromMap(element);
              List<Map<String, dynamic>> listSectionData =
                  await FirebaseFirestoreService.getSectionData(implementationId, initiativeId, listSection.id ?? '');
              List<TaskModel> taskList = [];
              if (listSectionData.isNotEmpty) {
                for (var element in listSectionData) {
                  taskList.add(TaskModel.fromMap(element));
                }
                taskList.sort((a, b) => a.index.compareTo(b.index));
                listSection = listSection.copyWith(list: taskList);
              }
              sectionList.add(listSection);
              break;
          }
        }
        if (sectionList.length > 1) {
          sectionList.sort((a, b) => a.index!.compareTo(b.index!));
        }
        return sectionList;
      }
      return [];
    } catch (e) {
      rethrow;
    }
  }

  @override
  Future<void> editInitiative({
    required String implementationId,
    required List<SectionModel> sectionModel,
    required InitiativeModel initiative,
    required Map<String, dynamic> updatedInitiative,
  }) async {
    try {
      List<String> removeSectionList = InitiativeOptionEnum.values.map((e) => e.title).toList();
      for (var element in sectionModel) {
        removeSectionList.removeWhere((e) => e == element.title);
      }
      if (removeSectionList.isNotEmpty) {
        await FirebaseFirestoreService.deleteInitiativesSection(
            section: removeSectionList, implId: implementationId, initiativesId: initiative.id ?? "");
      }

      if (updatedInitiative.isNotEmpty) {
        await FirebaseFirestoreService.updateInitiatives(
            implId: implementationId, initiativesId: initiative.id ?? '', initiativesMap: updatedInitiative);
      }

      for (var element in sectionModel) {
        switch (element.type) {
          case 0:
            element as TextSectionModel;
            await FirebaseFirestoreService.updateInitiativesSection(
              implId: implementationId,
              initiativesId: initiative.id ?? '',
              sectionId: element.id ?? '',
              sectionMap: element.toMap(),
              dataText: element.text,
            );
            Debug.log('editInitiative TextSectionModel: ${element.text} $element');
            break;
          case 1:
            element as ListSectionModel;
            await FirebaseFirestoreService.updateInitiativesSection(
              implId: implementationId,
              initiativesId: initiative.id ?? '',
              sectionId: element.id ?? '',
              sectionMap: element.toMap(),
              dataTextList: element.list.map((e) => e.toMap()).toList(),
            );
            Debug.log('editInitiative ListSectionModel: ${element.list} $element');
            break;
        }
      }
    } catch (e) {
      rethrow;
    }
  }

  @override
  Future<void> deleteInitiative({required String implementationId, required String initiativeId}) async {
    try {
      await FirebaseFirestoreService.deleteInitiatives(
        implId: implementationId,
        initiativesId: initiativeId,
      );
    } catch (e) {
      rethrow;
    }
  }
}
