part of 'initiative_bloc.dart';

abstract class InitiativeEvent {}

class InitiativeStatusChange extends InitiativeEvent {
  final AppBarStatus status;
  final InitiativeModel? initiative;

  InitiativeStatusChange(this.status, {this.initiative});
}

class GetInitiativeListEvent extends InitiativeEvent {
  final String implementationId;

  GetInitiativeListEvent(this.implementationId);
}

class AddInitiativeEvent extends InitiativeEvent {
  final String implementationId;
  final String userId;
  final String initiativeTitle;

  AddInitiativeEvent({
    required this.implementationId,
    required this.initiativeTitle,
    required this.userId,
  });
}

class ViewInitiativeEvent extends InitiativeEvent {
  final String userId;
  final InitiativeModel initiative;

  ViewInitiativeEvent({
    required this.userId,
    required this.initiative,
  });
}

class EditInitiativeInitialEvent extends InitiativeEvent {
  final String userId;
  final InitiativeModel initiative;

  EditInitiativeInitialEvent({
    required this.userId,
    required this.initiative,
  });
}

class EditInitiativeDataEvent extends InitiativeEvent {
  final String implementationId;
  final String userId;
  final String initiativeTitle;
  final InitiativeModel initiative;

  EditInitiativeDataEvent({
    required this.implementationId,
    required this.initiativeTitle,
    required this.userId,
    required this.initiative,
  });
}

class DeleteInitiativeEvent extends InitiativeEvent {
  final String implementationId;
  final String initiativeId;

  DeleteInitiativeEvent({
    required this.implementationId,
    required this.initiativeId,
  });
}
