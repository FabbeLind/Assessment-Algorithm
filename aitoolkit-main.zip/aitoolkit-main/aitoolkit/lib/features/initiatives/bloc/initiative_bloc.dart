import 'dart:async';

import 'package:aitoolkit/features/initiatives/entities/section_model.dart';
import 'package:aitoolkit/features/initiatives/model/initiative_model.dart';
import 'package:aitoolkit/features/initiatives/model/list_section_model.dart';
import 'package:aitoolkit/features/initiatives/model/text_section_model.dart';
import 'package:aitoolkit/features/initiatives/repository/initiative_repo.dart';
import 'package:app_utils/app_utils.dart';
import 'package:bloc/bloc.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../model/initiative_active_option_model.dart';
import '../model/task_model.dart';
import '../widgets/initiative_list_section_card.dart';
import '../widgets/initiative_text_section_card.dart';

part 'initiative_event.dart';
part 'initiative_state.dart';

class InitiativeBloc extends Bloc<InitiativeEvent, InitiativeState> {
  InitiativeBloc() : super(InitiativeInitialState()) {
    on<InitiativeStatusChange>(_onInitiativeStatusChange);
    on<GetInitiativeListEvent>(_getInitiativeEvent);
    on<AddInitiativeEvent>(_addInitiativeEvent);
    on<ViewInitiativeEvent>(_viewInitiativeEvent);
    on<EditInitiativeInitialEvent>(_editInitiativeInitialEvent);
    on<EditInitiativeDataEvent>(_editInitiativeDataEvent);
    on<DeleteInitiativeEvent>(_deleteInitiativeEvent);
  }

  DateTime? startTime;
  DateTime? endTime;
  List<SectionModel> sectionList = [];
  List<InitiativeActiveOptionModel> activeOptionList = [];
  List<InitiativeOptionEnum> optionList = [];
  List<TaskModel> goalList = [];
  List<TaskModel> objectiveList = [];
  TextEditingController vision = TextEditingController();
  TextEditingController description = TextEditingController();

  final InitiativeRepo _initiativeRepo = InitiativeRepo.instance;

  Future<void> _addInitiativeEvent(AddInitiativeEvent event, Emitter<InitiativeState> emit) async {
    try {
      Debug.log("Add Initiative Data -->> $goalList \n$objectiveList \n$vision \n$description");
      if (startTime != null && endTime != null && event.initiativeTitle.isNotEmpty) {
        if ((endTime!.isAfter(startTime!))) {
          updateSectionList(event.userId);
          emit(AddInitiativeLoadingState());
          InitiativeModel initiative = InitiativeModel(
            refId: event.implementationId,
            title: event.initiativeTitle,
            startTime: startTime!,
            endTime: endTime!,
            createdBy: event.userId,
          );
          Debug.log("Add Initiative -> $sectionList // $initiative");
          await _initiativeRepo.addInitiative(
            section: sectionList,
            implementationId: event.implementationId,
            initiativeModel: initiative,
          );
          emit(AddInitiativeSuccessState());
        } else {
          emit(AddInitiativeErrorState(AppString.selectValidTimeInterval));
        }
      } else {
        if (event.initiativeTitle.isEmpty) {
          emit(AddInitiativeErrorState(AppString.titleIsRequired));
        } else if (startTime == null) {
          emit(AddInitiativeErrorState(AppString.startTimeIsRequired));
        } else if (endTime == null) {
          emit(AddInitiativeErrorState(AppString.endTimeIsRequired));
        }
      }
    } catch (e, st) {
      emit(AddInitiativeErrorState("Error while adding initiative."));
      Debug.log("Error while adding initiative -> $e", st);
    }
  }

  Future<void> _viewInitiativeEvent(ViewInitiativeEvent event, Emitter<InitiativeState> emit) async {
    try {
      emit(ViewInitiativeLoadingState());
      setDefaultInitiativeData();
      sectionList = await _initiativeRepo.getSection(
        implementationId: event.initiative.refId,
        initiativeId: event.initiative.id ?? "",
      );
      startTime = event.initiative.startTime;
      endTime = event.initiative.endTime;
      setInitiativeDataWidget(sectionList, readOnly: true, initiative: event.initiative);
      emit(ViewInitiativeSuccessState(event.initiative));
    } catch (e, st) {
      emit(ViewInitiativeErrorState("Error while fetching initiative"));
      Debug.log(e, st);
    }
  }

  Future<void> _getInitiativeEvent(GetInitiativeListEvent event, Emitter<InitiativeState> emit) async {
    try {
      emit(InitiativeLoadingState());
      List<InitiativeModel> initiativeList =
          await _initiativeRepo.getInitiative(implementationId: event.implementationId);

      emit(InitiativeSuccessState(initiativeList));
    } catch (e, st) {
      emit(InitiativeErrorState("Error while fetching initiatives"));
      Debug.log(e, st);
    }
  }

  void setInitiativeDataWidget(List<SectionModel> sectionList,
      {required bool readOnly, required InitiativeModel initiative}) {
    Debug.log("SectionList Length --->>> ${sectionList.length} ");
    Debug.log("setInitiativeDataWidget start-> $goalList $objectiveList ${vision.text} ${description.text}");
    activeOptionList.clear();
    optionList.clear();
    for (int i = 0; i < sectionList.length; i++) {
      SectionModel section = sectionList[i];
      InitiativeOptionEnum? option = getInitiativeOption(section.title);
      if (option != null) {
        switch (option.type) {
          case SectionType.text:
            section as TextSectionModel;
            Debug.log("Section Detail --->>> ${sectionList[i]}");
            TextEditingController? controller;
            if (option == InitiativeOptionEnum.vision) {
              vision.text = section.text;
              Debug.log("Initial Text -> ${vision.text} // ${section.text}");
              controller = vision;
            } else if (option == InitiativeOptionEnum.description) {
              description.text = section.text;
              Debug.log("Initial Text -> ${description.text} // ${section.text}");
              controller = description;
            }
            if (controller != null) {
              InitiativeActiveOptionModel activeOption = InitiativeActiveOptionModel(
                option: option,
                index: section.index!,
                sectionType: SectionType.text,
                section: section,
                widget: InitiativeTextSectionCard(
                  key: Key(option.title),
                  readOnly: readOnly,
                  option: option,
                  controller: controller,
                  onCloseTap: () {
                    optionList.add(option);
                    activeOptionList.removeWhere((element) => element.option.title == option.title);
                    controller?.clear();
                    emit(EditInitiativeDataUpdateState(initiative));
                  },
                ),
              );
              activeOptionList.add(activeOption);
            }
            break;
          case SectionType.list:
            section as ListSectionModel;
            List<TaskModel> taskList = [];
            if (option == InitiativeOptionEnum.goals) {
              goalList.clear();
              goalList.addAll(section.list);
              taskList = goalList;
              Debug.log("Initial List -> $goalList // ${section.list} // $taskList");
            } else if (option == InitiativeOptionEnum.objectives) {
              objectiveList.clear();
              objectiveList.addAll(section.list);
              taskList = objectiveList;
              Debug.log("Initial List -> $objectiveList // ${section.list} // $taskList");
            }
            InitiativeActiveOptionModel activeOption = InitiativeActiveOptionModel(
              section: section,
              option: option,
              index: section.index!,
              sectionType: SectionType.list,
              widget: InitiativeOptionTaskInputCard(
                key: Key(option.title),
                readOnly: readOnly,
                option: option,
                onCloseTap: () {
                  optionList.add(option);
                  activeOptionList.removeWhere((element) => element.option.title == option.title);
                  taskList.clear();
                  emit(EditInitiativeDataUpdateState(initiative));
                },
                taskList: taskList,
                onChanged: (updatedList) {
                  Debug.log("Updated list -> $updatedList || $taskList");
                  taskList.clear();
                  taskList.addAll(updatedList);
                  emit(EditInitiativeDataUpdateState(initiative));
                },
              ),
            );
            activeOptionList.add(activeOption);
            break;
        }
      }
    }
    optionList.clear();
    optionList.addAll(InitiativeOptionEnum.values);
    Set<InitiativeOptionEnum> commonOption =
        optionList.map((e) => e).toSet().intersection(activeOptionList.map((e) => e.option).toSet());
    optionList.removeWhere((element) => commonOption.contains(element));
    Debug.log("Active Option List -> ${activeOptionList.length} // $activeOptionList ");
    Debug.log("Option List -> ${optionList.length} // $optionList");
  }

  void updateSectionList(String userId, {String initiativeId = ''}) {
    sectionList.clear();
    DateTime now = DateTime.now();
    for (int i = 0; i < activeOptionList.length; i++) {
      var activeOption = activeOptionList[i];
      bool isSectionExist = activeOption.section != null;
      String? createdBy = isSectionExist ? activeOption.section!.createdBy : userId;
      String? id = isSectionExist ? activeOption.section!.id : '';
      String? refId = isSectionExist ? activeOption.section!.refId : initiativeId;
      DateTime? createdAt = isSectionExist ? activeOption.section!.createdAt : now;
      DateTime? updatedAt = isSectionExist ? now : now;
      switch (activeOption.option.title) {
        case AppString.vision:
          if (vision.text.isNotEmpty) {
            sectionList.add(TextSectionModel(
              index: i,
              title: activeOption.option.title,
              type: activeOption.sectionType.type,
              text: vision.text,
              createdBy: createdBy,
              id: id,
              refId: refId,
              updatedAt: updatedAt,
              createdAt: createdAt,
            ));
          }
          break;
        case AppString.description:
          if (description.text.isNotEmpty) {
            sectionList.add(TextSectionModel(
              index: i,
              title: activeOption.option.title,
              type: activeOption.option.type.type,
              text: description.text,
              createdBy: createdBy,
              id: id,
              refId: refId,
              updatedAt: updatedAt,
              createdAt: createdAt,
            ));
          }
          break;
        case AppString.goals:
          goalList.removeWhere((element) => element.text.isEmpty);
          if (goalList.isNotEmpty) {
            sectionList.add(ListSectionModel(
              index: i,
              title: activeOption.option.title,
              type: activeOption.option.type.type,
              list: goalList,
              createdBy: createdBy,
              id: id,
              refId: refId,
              updatedAt: updatedAt,
              createdAt: createdAt,
            ));
          }
          break;
        case AppString.objectives:
          objectiveList.removeWhere((element) => element.text.isEmpty);
          if (objectiveList.isNotEmpty) {
            sectionList.add(ListSectionModel(
              index: i,
              title: activeOption.option.title,
              type: activeOption.option.type.type,
              list: objectiveList,
              createdBy: createdBy,
              id: id,
              refId: refId,
              updatedAt: updatedAt,
              createdAt: createdAt,
            ));
          }
          break;
      }
    }
  }

  void setDefaultInitiativeData() {
    startTime = null;
    endTime = null;
    optionList.clear();
    activeOptionList.clear();
    objectiveList.clear();
    goalList.clear();
    vision.clear();
    description.clear();
    optionList.addAll(InitiativeOptionEnum.values);
  }

  Future<void> _onInitiativeStatusChange(InitiativeStatusChange event, Emitter<InitiativeState> emit) async {
    switch (event.status) {
      case AppBarStatus.add:
        emit(AddInitiative());
      case AppBarStatus.view:
        if (event.initiative != null) {
          emit(ViewInitiativeSuccessState(event.initiative!));
        }
      case AppBarStatus.edit:
        emit(EditInitiative());
      case AppBarStatus.none:
        emit(InitiativeInitialState());
    }
  }

  Future<void> _editInitiativeInitialEvent(EditInitiativeInitialEvent event, Emitter<InitiativeState> emit) async {
    try {
      emit(EditInitiativeLoadingState());
      setInitiativeDataWidget(
        sectionList,
        readOnly: false,
        initiative: event.initiative,
      );
      emit(EditInitiativeDataLoadedState(event.initiative));
    } catch (e, st) {
      emit(EditInitiativeErrorState("Error while loading the edit data"));
      Debug.log(e, st);
    }
  }

  Future<void> _editInitiativeDataEvent(EditInitiativeDataEvent event, Emitter<InitiativeState> emit) async {
    try {
      emit(EditInitiativeLoadingState());
      Map<String, dynamic> initiativeUpdateData = {};
      if (startTime != event.initiative.startTime) {
        initiativeUpdateData["startTime"] = startTime;
      }
      if (endTime != event.initiative.endTime) {
        initiativeUpdateData["endTime"] = endTime;
      }
      if (event.initiativeTitle != event.initiative.title) {
        initiativeUpdateData["title"] = event.initiativeTitle;
      }
      if (initiativeUpdateData.isNotEmpty) {
        initiativeUpdateData["updatedAt"] = Timestamp.fromDate(DateTime.now());
      }
      updateSectionList(event.userId, initiativeId: event.initiative.id.toString());
      await _initiativeRepo.editInitiative(
        implementationId: event.implementationId,
        sectionModel: sectionList,
        initiative: event.initiative,
        updatedInitiative: initiativeUpdateData,
      );
      emit(EditInitiativeSuccessState(event.initiative));
    } catch (e, st) {
      emit(EditInitiativeErrorState("Error while saving initiative"));
      Debug.log(e, st);
    }
  }

  Future<void> _deleteInitiativeEvent(DeleteInitiativeEvent event, Emitter<InitiativeState> emit) async {
    try {
      emit(DeleteInitiativeLoadingState());
      await _initiativeRepo.deleteInitiative(
        implementationId: event.implementationId,
        initiativeId: event.initiativeId,
      );
      emit(DeleteInitiativeSuccessState());
    } catch (e) {
      emit(DeleteInitiativeErrorState("Error while deleting initiative"));
    }
  }
}
