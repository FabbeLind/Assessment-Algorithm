part of 'initiative_bloc.dart';

abstract class InitiativeState {}

abstract class InitiativeActionState extends InitiativeState {}

// Action State

class AddInitiative extends InitiativeActionState {}

class ViewInitiative extends InitiativeActionState {}

class DeleteInitiative extends InitiativeActionState {}

class EditInitiative extends InitiativeActionState {}

class InitiativeInitialState extends InitiativeState {}

class InitiativeLoadingState extends InitiativeState {}

class InitiativeSuccessState extends InitiativeState {
  List<InitiativeModel> initiativeList;

  InitiativeSuccessState(this.initiativeList);
}

class InitiativeErrorState extends InitiativeState {
  final String message;

  InitiativeErrorState(this.message);
}

class AddInitiativeInitialState extends AddInitiative {}

class AddInitiativeLoadingState extends AddInitiative {}

class AddInitiativeSuccessState extends AddInitiative {}

class AddInitiativeErrorState extends AddInitiative {
  final String message;

  AddInitiativeErrorState(this.message);
}

class ViewInitiativeInitialState extends ViewInitiative {}

class ViewInitiativeLoadingState extends ViewInitiative {}

class ViewInitiativeSuccessState extends ViewInitiative {
  final InitiativeModel initiative;

  ViewInitiativeSuccessState(this.initiative);
}

class ViewInitiativeErrorState extends ViewInitiative {
  final String message;

  ViewInitiativeErrorState(this.message);
}

class DeleteInitiativeLoadingState extends DeleteInitiative {}

class DeleteInitiativeSuccessState extends DeleteInitiative {}

class DeleteInitiativeErrorState extends DeleteInitiative {
  final String message;

  DeleteInitiativeErrorState(this.message);
}

class EditInitiativeInitialState extends EditInitiative {}

class EditInitiativeLoadingState extends EditInitiative {}

class EditInitiativeSuccessState extends EditInitiative {
  InitiativeModel initiative;

  EditInitiativeSuccessState(this.initiative);
}

class EditInitiativeErrorState extends EditInitiative {
  final String message;

  EditInitiativeErrorState(this.message);
}

class EditInitiativeUpdateState extends EditInitiative {
  InitiativeModel initiative;

  EditInitiativeUpdateState(this.initiative);
}

class EditInitiativeDataLoadedState extends EditInitiativeUpdateState {
  EditInitiativeDataLoadedState(super.initiative);
}

class EditInitiativeDataUpdateState extends EditInitiativeUpdateState {
  EditInitiativeDataUpdateState(super.initiative);
}
