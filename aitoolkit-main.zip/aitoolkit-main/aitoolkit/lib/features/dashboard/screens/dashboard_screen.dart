import 'dart:io';

import 'package:aitoolkit/features/home/screen/home_screen.dart';
import 'package:aitoolkit/features/profile/screens/profile_screen.dart';
import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';

class DashBoardScreen extends StatefulWidget {
  const DashBoardScreen({super.key});

  @override
  State<DashBoardScreen> createState() => _DashBoardScreenState();
}

class _DashBoardScreenState extends State<DashBoardScreen> {
  List<Widget> tabBarScreenList = [
    const HomeScreen(),
    const ProfileScreen(),
  ];

  int currentIndex = 0;

  void changeScreenIndex(int index) {
    setState(() {
      currentIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: _buildBottomNavBar(),
      body: SafeArea(
        child: IndexedStack(
          index: currentIndex,
          children: tabBarScreenList,
        ),
      ),
    );
  }

  Widget _buildBottomNavBar() {
    EdgeInsetsGeometry iconPadding = EdgeInsets.only(
      top: 17.h,
      bottom: 17.h + (Platform.isIOS ? 16.h : 0.h),
      right: 37.w,
      left: 37.w,
    );
    return Container(
      decoration: BoxDecoration(
        color: AppThemeData.bottomNavColor,
        boxShadow: [
          BoxShadow(
            color: AppThemeData.primaryShadowColor,
            offset: const Offset(0, -4),
            blurRadius: 10,
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          GestureDetector(
            onTap: () {
              changeScreenIndex(0);
            },
            behavior: HitTestBehavior.translucent,
            child: Padding(
              padding: iconPadding,
              child: SvgPicture.asset(
                AppAsset.home,
                height: 26.w,
                width: 25.w,
                colorFilter: ColorFilter.mode(
                    currentIndex == 0 ? AppThemeData.black : AppThemeData.grey700.withOpacity(0.34), BlendMode.srcIn),
              ),
            ),
          ),
          GestureDetector(
            onTap: () {
              changeScreenIndex(1);
            },
            behavior: HitTestBehavior.translucent,
            child: Padding(
              padding: iconPadding,
              child: SvgPicture.asset(
                AppAsset.profile,
                height: 27.w,
                width: 25.w,
                colorFilter: ColorFilter.mode(
                    currentIndex == 1 ? AppThemeData.black : AppThemeData.grey700.withOpacity(0.47), BlendMode.srcIn),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
