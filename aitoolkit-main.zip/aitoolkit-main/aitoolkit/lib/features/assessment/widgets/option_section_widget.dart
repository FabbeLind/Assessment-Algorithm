import 'dart:io';

import 'package:aitoolkit/features/assessment/model/assessment_section_model.dart';
import 'package:aitoolkit/features/assessment/widgets/assessment_underline_text_field.dart';
import 'package:aitoolkit/widgets/app_image.dart';
import 'package:app_utils/app_utils.dart';
import 'package:app_utils/file_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../../widgets/app_underline_text_field.dart';
import '../../../widgets/primary_animated_container.dart';

class OptionSectionWidget extends StatefulWidget {
  const OptionSectionWidget({
    super.key,
    required this.index,
    required this.section,
    required this.onSectionChange,
    required this.onDeleteTap,
    required this.onCopyTap,
  });

  final int index;
  final AssessmentSectionModel section;
  final Function(AssessmentSectionModel section) onSectionChange;
  final Function() onDeleteTap;
  final Function() onCopyTap;

  @override
  State<OptionSectionWidget> createState() => _OptionSectionWidgetState();
}

class _OptionSectionWidgetState extends State<OptionSectionWidget> with SingleTickerProviderStateMixin {
  late AssessmentSectionModel section;

  @override
  void initState() {
    section = widget.section;
    super.initState();
  }

  void callSectionCallback() => widget.onSectionChange.call(section);

  @override
  Widget build(BuildContext context) {
    return PrimaryAnimatedContainer(
      playAnimation: widget.section.playAnimation,
      onAnimationChange: (value) {
        section = section.copyWith(playAnimation: value);
        callSectionCallback();
      },
      title: "${AppString.section} ${widget.section.index}",
      padding: EdgeInsets.only(top: 6.h, bottom: 8.h),
      margin: EdgeInsets.symmetric(vertical: 10.h),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(height: 6.h),
          _buildDragIcon(),
          _buildSectionTitle(),
          _buildSectionDescription(),
          SizedBox(height: 14.h),
          _buildSectionActionWidget(),
        ],
      ),
    );
  }

  Widget _buildSectionActionWidget() {
    return Align(
      alignment: Alignment.centerRight,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          GestureDetector(
            onTap: () async {
              String? image = await FileUtil().pickImage();
              if (image != null) {
                section = section.copyWith(image: image);
                callSectionCallback();
              }
            },
            child: section.image != null
                ? ClipRRect(
                    borderRadius: BorderRadius.circular(2.r),
                    child: section.image.isImageNetwork
                        ? AppImage(
                            section.image!,
                            size: 21.w,
                            borderRadius: 2.r,
                          )
                        : Image.file(
                            File(section.image!),
                            height: 21.w,
                            width: 21.w,
                            fit: BoxFit.cover,
                          ),
                  ).addTapAreaAll(6.w)
                : _buildIcon(AppAsset.media),
          ),
          GestureDetector(
            onTap: widget.onCopyTap,
            child: _buildIcon(AppAsset.copy),
          ),
          GestureDetector(
            onTap: widget.onDeleteTap,
            child: _buildIcon(AppAsset.deleteOutlined),
          ),
        ],
      ).paddingOnly(right: 14.w),
    );
  }

  Widget _buildSectionDescription() {
    return AppUnderlineTextField(
      controller: section.description,
      onChanged: (value) => callSectionCallback(),
      hintText: AppString.description,
    );
  }

  Widget _buildSectionTitle() {
    return AppUnderlineTextField(
      controller: section.title,
      onChanged: (value) => callSectionCallback(),
      hintText: AppString.title,
    );
  }

  Widget _buildDragIcon() {
    return SvgPicture.asset(
      AppAsset.dragCard1,
      height: 20.w,
      width: 20.w,
    );
  }

  Widget _buildIcon(String icon) {
    return SvgPicture.asset(
      icon,
      height: 21.w,
      width: 21.w,
    ).addTapAreaAll(6.w);
  }
}
