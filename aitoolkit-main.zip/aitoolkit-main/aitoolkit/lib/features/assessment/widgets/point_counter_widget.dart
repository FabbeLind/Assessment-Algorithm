import 'package:app_utils/app_utils.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class PointCounterWidget extends StatefulWidget {
  const PointCounterWidget({
    super.key,
    this.initialValue = 0,
    required this.onChangeValue,
  });

  final int initialValue;
  final Function(int value) onChangeValue;

  @override
  State<PointCounterWidget> createState() => _PointCounterWidgetState();
}

class _PointCounterWidgetState extends State<PointCounterWidget> {
  int value = 0;

  @override
  void initState() {
    Debug.log("PointCounterWidget InitState Call");
    value = widget.initialValue;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Debug.log("Build Point Counter Widget");
    return Container(
      padding: EdgeInsets.all(1.w),
      decoration: BoxDecoration(
        color: AppThemeData.pointBgColor,
        borderRadius: BorderRadius.circular(8.r),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          GestureDetector(
            onTap: () {
              if (value > 0) {
                value--;
                widget.onChangeValue.call(value);
                setState(() {});
              }
            },
            child: Text(
              "-",
              style: AppTextStyle.defaultF16W5Primary,
            ).addTapAreaSymmetric(horizontal: 7.w),
          ),
          Container(
            color: AppThemeData.white,
            padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
            child: Text(
              value.toString(),
              style: AppTextStyle.defaultF16W3Primary,
            ),
          ),
          GestureDetector(
            onTap: () {
              value++;
              widget.onChangeValue.call(value);
              setState(() {});
            },
            child: Text(
              "+",
              style: AppTextStyle.defaultF16W5Primary,
            ).addTapAreaSymmetric(horizontal: 5.w),
          ),
        ],
      ),
    );
  }
}
