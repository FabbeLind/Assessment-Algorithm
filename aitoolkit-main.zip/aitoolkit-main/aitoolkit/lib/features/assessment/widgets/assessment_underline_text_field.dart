import 'package:aitoolkit/widgets/app_underline_text_field.dart';
import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';

class AssessmentUnderlineTextField extends StatefulWidget {
  const AssessmentUnderlineTextField({
    super.key,
    required this.controller,
    required this.hintText,
    this.questionView = QuestionViewType.none,
    this.onChanged,
    this.pointWidget,
    this.textInputAction = TextInputAction.next,
  });

  final TextEditingController controller;
  final String? hintText;
  final Function(String)? onChanged;
  final Widget? pointWidget;
  final QuestionViewType questionView;
  final TextInputAction textInputAction;

  @override
  State<AssessmentUnderlineTextField> createState() =>
      _AssessmentUnderlineTextFieldState();
}

class _AssessmentUnderlineTextFieldState
    extends State<AssessmentUnderlineTextField> {
  late FocusNode focusNode;

  @override
  void initState() {
    focusNode = FocusNode();
    super.initState();
  }

  @override
  void dispose() {
    focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    bool isDefaultView = widget.questionView == QuestionViewType.none;
    return AppUnderlineTextField(
      controller: widget.controller,
      onChanged: widget.onChanged,
      hintText: widget.hintText,
      crossAxisAlignment:
          isDefaultView ? CrossAxisAlignment.start : CrossAxisAlignment.end,
      textInputAction: widget.textInputAction,
      readOnly: widget.questionView != QuestionViewType.none,
      suffixWidget: _suffixWidget(widget.questionView),
    );
  }

  Widget _suffixWidget(QuestionViewType questionView) {
    switch (questionView) {
      case QuestionViewType.point:
        if (widget.pointWidget != null) {
          return widget.pointWidget!;
        } else {
          return const SizedBox.shrink();
        }
      case QuestionViewType.continueOption:
        return const SizedBox.shrink();
      case QuestionViewType.none:
        return GestureDetector(
          onTap: () {
            widget.controller.clear();
            if (focusNode.hasFocus) {
              focusNode.unfocus();
            }
          },
          child: SvgPicture.asset(
            AppAsset.crossActive,
            height: 18.w,
            width: 18.w,
          ).addTapAreaOnly(top: 12.h, right: 20.w, bottom: 12.h, left: 5.w),
        );
    }
  }
}
