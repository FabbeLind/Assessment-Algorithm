import 'package:aitoolkit/features/assessment/model/answer_model.dart';
import 'package:aitoolkit/features/assessment/widgets/check_box_selection_card.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class CheckBoxViewWidget extends StatefulWidget {
  const CheckBoxViewWidget({
    super.key,
    required this.optionList,
    required this.selectedOption,
    required this.onOptionSelect,
    this.readOnly = false,
  });

  final List<AnswerModel> optionList;
  final List<String> selectedOption;
  final Function(List<String> selectedId, List<String> selectedValue) onOptionSelect;
  final bool readOnly;

  @override
  State<CheckBoxViewWidget> createState() => _CheckBoxViewWidgetState();
}

class _CheckBoxViewWidgetState extends State<CheckBoxViewWidget> {
  List<bool> optionListStatus = [];

  @override
  void initState() {
    loadInitialData();
    super.initState();
  }

  void loadInitialData() {
    optionListStatus.clear();
    optionListStatus = widget.optionList.map((e) => false).toList();
    for (int i = 0; i < widget.optionList.length; i++) {
      for (var element in widget.selectedOption) {
        if (element == widget.optionList[i].id) {
          optionListStatus[i] = true;
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      physics: const NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      padding: EdgeInsets.symmetric(
        horizontal: 40.w,
        vertical: 40.h,
      ),
      itemCount: widget.optionList.length,
      itemBuilder: (context, index) {
        var option = widget.optionList[index];
        return GestureDetector(
          onTap: widget.readOnly
              ? null
              : () {
                  optionListStatus[index] = !optionListStatus[index];
                  List<AnswerModel> selectedList = updatedSelectionList();
                  widget.onOptionSelect
                      .call(selectedList.map((e) => e.id).toList(), selectedList.map((e) => e.answer.text).toList());
                  setState(() {});
                },
          child: CheckBoxSelectionCard(
            isSelected: optionListStatus[index],
            text: option.answer.text,
            readOnly: widget.readOnly,
          ),
        );
      },
      separatorBuilder: (context, index) => SizedBox(height: 35.h),
    );
  }

  List<AnswerModel> updatedSelectionList() {
    List<AnswerModel> selectionList = [];
    for (int i = 0; i < optionListStatus.length; i++) {
      if (optionListStatus[i] == true) {
        selectionList.add(widget.optionList[i]);
      }
    }
    return selectionList;
  }
}
