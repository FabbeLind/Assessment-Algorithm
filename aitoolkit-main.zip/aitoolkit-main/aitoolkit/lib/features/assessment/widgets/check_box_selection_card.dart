import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../../widgets/primary_container.dart';

class CheckBoxSelectionCard extends StatelessWidget {
  const CheckBoxSelectionCard({
    super.key,
    required this.isSelected,
    required this.text,
    this.readOnly = false,
  });

  final bool isSelected;
  final String text;
  final bool readOnly;

  @override
  Widget build(BuildContext context) {
    return PrimaryContainer(
      color: Colors.transparent,
      border: Border.all(
        color: isSelected ? AppThemeData.secondaryBorderColor : AppThemeData.primaryBorderColor,
        width: 1.w,
      ),
      radius: 8.r,
      boxShadow: const [],
      padding: EdgeInsets.symmetric(
        vertical: 11.h,
        horizontal: 23.w,
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(
              text,
              style: isSelected
                  ? AppTextStyle.headline.copyWith(fontWeight: FontWeight.w400)
                  : AppTextStyle.headline.copyWith(fontWeight: FontWeight.w300),
            ),
          ),
          SizedBox(width: 10.w),
          Container(
            height: 17.w,
            width: 17.w,
            padding: EdgeInsets.all(3.w),
            decoration: BoxDecoration(
              color: isSelected ? AppThemeData.primaryBorderColor : Colors.transparent,
              borderRadius: BorderRadius.circular(50.r),
              border: Border.all(
                color: isSelected ? AppThemeData.secondaryBorderColor : AppThemeData.primaryBorderColor,
              ),
            ),
            child: isSelected
                ? Center(
                    child: SvgPicture.asset(
                      AppAsset.tickOutlined,
                      fit: BoxFit.cover,
                      colorFilter: readOnly ? const ColorFilter.mode(AppThemeData.white, BlendMode.srcIn) : null,
                    ),
                  )
                : null,
          ),
        ],
      ),
    );
  }
}
