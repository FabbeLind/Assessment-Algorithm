import 'package:aitoolkit/widgets/app_widget.dart';
import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class AssessmentCloseButton extends StatelessWidget {
  const AssessmentCloseButton({super.key});

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.topRight,
      child: GestureDetector(
        onTap: () {
          Navigator.pop(context);
        },
        child: AppWidget.crossIcon().addTapAreaSymmetric(horizontal: 14.w),
      ),
    );
  }
}
