import 'dart:io';

import 'package:aitoolkit/features/assessment/model/answer_model.dart';
import 'package:aitoolkit/features/assessment/model/assessment_question_model.dart';
import 'package:aitoolkit/features/assessment/widgets/assessment_underline_text_field.dart';
import 'package:aitoolkit/features/assessment/widgets/point_counter_widget.dart';
import 'package:aitoolkit/features/assessment/widgets/pop_up_widgets/question_menu_pop_up.dart';
import 'package:aitoolkit/widgets/primary_text_field.dart';
import 'package:app_utils/app_utils.dart';
import 'package:app_utils/file_utils.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../../routes/route_arguments.dart';
import '../../../routes/routes.dart';
import '../../../widgets/app_animation_switcher.dart';
import '../../../widgets/app_image.dart';
import '../../../widgets/primary_animated_container.dart';

class OptionQuestionWidget extends StatefulWidget {
  const OptionQuestionWidget({
    super.key,
    required this.index,
    required this.question,
    required this.onQuestionChange,
    required this.onDeleteTap,
    required this.onCopyTap,
  });

  final int index;
  final AssessmentQuestionModel question;
  final Function(AssessmentQuestionModel question) onQuestionChange;
  final Function() onDeleteTap;
  final Function() onCopyTap;

  @override
  State<OptionQuestionWidget> createState() => _OptionQuestionWidgetState();
}

class _OptionQuestionWidgetState extends State<OptionQuestionWidget> {
  bool isRequired = false;
  late AssessmentQuestionModel question;
  List<int> pointList = [];
  int questionPoint = 0;

  void callQuestionCallback() => widget.onQuestionChange.call(question);

  @override
  void initState() {
    question = widget.question;
    questionPoint = question.questionPoint;
    super.initState();
  }

  @override
  void dispose() {
    if (question.answers.isNotEmpty) {
      for (var controller in question.answers) {
        controller.answer.dispose();
        controller.focusNode.dispose();
      }
    }
    super.dispose();
  }

  @override
  void didUpdateWidget(covariant OptionQuestionWidget oldWidget) {
    question = widget.question;
    if (oldWidget.question.questionView != widget.question.questionView) {
      WidgetsBinding.instance.scheduleFrameCallback((_) => setState(() {}));
    }
    super.didUpdateWidget(oldWidget);
  }

  @override
  Widget build(BuildContext context) {
    bool defaultView = question.questionView == QuestionViewType.none;
    return PrimaryAnimatedContainer(
      title: "${AppString.question} ${widget.question.index}",
      playAnimation: widget.question.playAnimation,
      onAnimationChange: (value) {
        question = question.copyWith(playAnimation: value);
        callQuestionCallback();
      },
      margin: EdgeInsets.symmetric(vertical: 10.h),
      onExpansionChange: (value) {
        changeQuestionView(QuestionViewType.none);
      },
      child: AppAnimationSwitcher(
        direction: AnimationDirection.vertical,
        child: Column(
          key: ValueKey(defaultView),
          children: [
            SizedBox(height: 6.h),
            switch (question.questionView) {
              QuestionViewType.none => _buildDragCardIcon(),
              QuestionViewType.point => _buildSetPointText(),
              QuestionViewType.continueOption => const SizedBox.shrink(),
            },
            _buildQuestionTextField(),
            (question.questionType != QuestionType.freeText)
                ? Theme(
                    data: Theme.of(context).copyWith(
                      canvasColor: Colors.transparent,
                      shadowColor: Colors.transparent,
                    ),
                    child: AnimatedSize(
                      duration: const Duration(milliseconds: 500),
                      alignment: Alignment.topCenter,
                      curve: Curves.decelerate,
                      child: ReorderableListView(
                        buildDefaultDragHandles: question.questionView == QuestionViewType.none,
                        physics: const NeverScrollableScrollPhysics(),
                        shrinkWrap: true,
                        onReorder: reorderData,
                        onReorderStart: (index) {
                          HapticFeedback.heavyImpact();
                        },
                        onReorderEnd: (index) {
                          HapticFeedback.lightImpact();
                        },
                        children: [
                          for (int index = 0; index < question.answers.length; index++)
                            _buildOptionTextFieldWidget(
                              controller: question.answers[index].answer,
                              focusNode: question.answers[index].focusNode,
                              index: question.answers[index].index,
                              defaultView: defaultView,
                            ),
                        ],
                      ),
                    ),
                  )
                : const SizedBox.shrink(),
            switch (question.questionView) {
              QuestionViewType.continueOption => _buildContinueAllToWidget(),
              QuestionViewType.none =>
                (question.questionType != QuestionType.freeText) ? _buildAddMoreWidget() : const SizedBox.shrink(),
              QuestionViewType.point => const SizedBox.shrink(),
            },
            _actionWidget(question.questionView),
          ],
        ),
      ),
    );
  }

  void updateQuestionPoint(int point) {
    question = question.copyWith(questionPoint: point);
    Debug.log("Question point after change --->>> ${question.questionPoint} // $questionPoint");
  }

  void reorderData(int oldIndex, int newIndex) {
    if (newIndex > oldIndex) {
      newIndex -= 1;
    }
    final items = question.answers.removeAt(oldIndex);
    question.answers.insert(newIndex, items);
    updateOptionIndex();
    callQuestionCallback();
    setState(() {});
  }

  void changeQuestionView(QuestionViewType viewType) {
    setState(() => question = question.copyWith(questionView: viewType));
    callQuestionCallback();
  }

  void updateOptionIndex() {
    for (int i = 0; i < question.answers.length; i++) {
      question.answers[i] = question.answers[i].copyWith(index: i);
    }
  }

  Widget _buildSetPointText() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        SvgPicture.asset(
          AppAsset.starReview,
          height: 21.w,
          width: 21.w,
        ),
        SizedBox(width: 7.w),
        Text(
          AppString.setPoints,
          style: AppTextStyle.title3,
        ),
      ],
    );
  }

  Widget _buildRequiredSwitch() {
    return SizedBox(
      height: 25.h,
      child: FittedBox(
        fit: BoxFit.contain,
        child: CupertinoSwitch(
          trackColor: AppThemeData.switchBgColor,
          value: question.required,
          onChanged: (value) {
            setState(() {
              question = question.copyWith(required: value);
            });
            callQuestionCallback();
          },
        ),
      ),
    );
  }

  Widget _buildVerticalDivider() {
    return Container(
      height: 34.h,
      width: 1.w,
      color: AppThemeData.primaryBorderColor,
      margin: EdgeInsets.symmetric(horizontal: 10.w),
    );
  }

  Widget _buildIcon(String icon, {Function()? onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: SvgPicture.asset(
        icon,
        height: 21.w,
        width: 21.w,
      ).addTapAreaAll(6.w),
    );
  }

  Widget _buildQuestionTextField() {
    return AssessmentUnderlineTextField(
      controller: question.title,
      hintText: AppString.question,
      questionView: question.questionView,
      pointWidget: PointCounterWidget(
        key: UniqueKey(),
        initialValue: question.questionPoint,
        onChangeValue: (value) {
          updateQuestionPoint(value);
          // questionPoint = value;
        },
      ).paddingOnly(right: 25.w),
    );
  }

  Widget _buildDragCardIcon() {
    return SvgPicture.asset(
      AppAsset.dragCard1,
      height: 20.w,
      width: 20.w,
    );
  }

  String getActionText(AnswerActionType nextAction, {required String defaultText}) {
    switch (nextAction) {
      case AnswerActionType.section:
        return "$defaultText ${AnswerActionType.section.selectionText}";
      case AnswerActionType.question:
        return "$defaultText ${AnswerActionType.question.selectionText}";
      case AnswerActionType.end:
        return AnswerActionType.end.selectionText;
      default:
        return defaultText.addEllipse();
    }
  }

  Widget _buildOptionTextFieldWidget({
    required TextEditingController controller,
    required FocusNode focusNode,
    required int index,
    required bool defaultView,
  }) {
    pointList.add(question.answers[index].point);
    Widget optionTextField = PrimaryTextField(
      controller: controller,
      focusNode: focusNode,
      contentPadding: EdgeInsets.only(bottom: 5.h),
      border: InputBorder.none,
      readOnly: question.questionView != QuestionViewType.none,
      isDense: true,
      maxLines: 1,
      textInputAction: TextInputAction.next,
      keyboardType: TextInputType.text,
    );
    String actionText = getActionText(question.answers[index].nextAction, defaultText: AppString.continueTo);
    return GestureDetector(
      key: ValueKey(controller),
      onTap: question.questionView == QuestionViewType.continueOption
          ? () {
              Navigator.pushNamed(
                context,
                Routes.assessmentValueSelectionScreen,
                arguments: AssessmentValueSectionRouteArgument(
                  selectionType: AssessmentValueSelectionType.options,
                  defaultIndex: question.answers[index].nextAction.index,
                ),
              ).then((value) {
                if (value != null && (value is int)) {
                  AnswerActionType nextAction = getAnswerNextActionTypeByIndex(value);
                  question.answers[index] = question.answers[index].copyWith(nextAction: nextAction);
                  setState(() {});
                  callQuestionCallback();
                }
              });
            }
          : null,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (defaultView) ...[
            _buildDragIcon(),
            _buildPrefixCircle(),
            SizedBox(width: 10.w),
          ],
          if (!defaultView) SizedBox(width: 20.w),
          Expanded(
            child: Column(
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Expanded(
                      child: (question.questionView == QuestionViewType.continueOption)
                          ? Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                optionTextField,
                                Text(
                                  actionText,
                                  style: AppTextStyle.title3,
                                ).paddingOnly(bottom: 3.h),
                              ],
                            )
                          : optionTextField,
                    ),
                    switch (question.questionView) {
                      QuestionViewType.none => GestureDetector(
                          onTap: () {
                            Debug.log("OPTIONS -->> $index ${question.answers.length} - ${question.answers}");
                            question.answers.removeAt(index);
                            updateOptionIndex();
                            setState(() {});
                            callQuestionCallback();
                          },
                          child: SvgPicture.asset(
                            AppAsset.crossActive,
                            height: 18.w,
                            width: 18.w,
                          ).addTapAreaOnly(bottom: 3.h, left: 5.w, right: 27.w),
                        ),
                      QuestionViewType.point => PointCounterWidget(
                          initialValue: pointList[index],
                          onChangeValue: (value) {
                            pointList[index] = value;
                            updateQuestionPoint(0);
                            setState(() {});
                          },
                        ).paddingOnly(right: 25.w),
                      QuestionViewType.continueOption => SvgPicture.asset(
                          AppAsset.forwardArrow,
                          height: 18.w,
                          width: 18.w,
                        ).addTapAreaOnly(bottom: 3.h, left: 5.w, right: 27.w),
                    }
                  ],
                ),
                _buildDivider().paddingOnly(right: 25.w)
              ],
            ),
          )
        ],
      ).addTapAreaOnly(top: 10.h),
    );
  }

  Widget _buildAddMoreWidget() {
    return GestureDetector(
      onTap: () {
        String id = Utils.generateUid();
        question.answers.add(AnswerModel(
          id: id,
          index: question.answers.length,
          point: 0,
          nextAction: AnswerActionType.none,
          nextUid: "",
          answer: TextEditingController(),
          focusNode: FocusNode(),
        ));
        setState(() {});
        callQuestionCallback();
        question.answers.last.focusNode.requestFocus();
      },
      child: Container(
        color: Colors.transparent,
        padding: EdgeInsets.fromLTRB(20.w, 10.h, 20.w, 0.h),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                _buildPrefixCircle(),
                SizedBox(width: 10.w),
                Expanded(
                  child: Text(
                    AppString.addMore,
                    style: AppTextStyle.title3Options,
                  ),
                ),
                SvgPicture.asset(
                  AppAsset.addActive,
                  height: 18.w,
                  width: 18.w,
                ).paddingOnly(right: 7.w)
              ],
            ),
            SizedBox(height: 12.h),
            _buildDivider(),
          ],
        ),
      ),
    );
  }

  Widget _buildContinueAllToWidget() {
    String actionText = getActionText(question.nextAction, defaultText: AppString.continueAllTo);
    return GestureDetector(
      onTap: () {
        Navigator.pushNamed(
          context,
          Routes.assessmentValueSelectionScreen,
          arguments: AssessmentValueSectionRouteArgument(
            selectionType: AssessmentValueSelectionType.options,
            defaultIndex: question.nextAction.index,
          ),
        ).then((value) {
          if (value != null && (value is int)) {
            AnswerActionType nextAction = getAnswerNextActionTypeByIndex(value);
            question = question.copyWith(nextAction: nextAction);
            setState(() {});
            callQuestionCallback();
          }
        });
      },
      child: Container(
        color: Colors.transparent,
        padding: EdgeInsets.symmetric(horizontal: 20.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              actionText,
              textAlign: TextAlign.left,
              style: AppTextStyle.defaultF14W6Primary.copyWith(fontStyle: FontStyle.italic),
            ).paddingSymmetric(vertical: 22.h),
            _buildDivider(),
          ],
        ),
      ),
    );
  }

  Widget _buildDivider() => Divider(height: 0.h, thickness: (0.5).h, color: AppThemeData.secondaryDividerColor);

  Widget _buildPrefixCircle() {
    return Container(
      height: 17.w,
      width: 17.w,
      decoration: BoxDecoration(
        borderRadius: switch (question.questionType) {
          QuestionType.checkBox => BorderRadius.circular(5.r),
          _ => null,
        },
        border: Border.all(color: AppThemeData.primaryBorderColor),
        shape: switch (question.questionType) {
          QuestionType.checkBox => BoxShape.rectangle,
          _ => BoxShape.circle,
        },
      ),
    );
  }

  Widget _buildDragIcon() {
    return SvgPicture.asset(
      AppAsset.dragList1,
      height: 20.w,
      width: 20.w,
    );
  }

  Widget _actionWidget(QuestionViewType questionView) {
    switch (questionView) {
      case QuestionViewType.point:
        return _buildPointViewActionWidget();
      case QuestionViewType.continueOption:
        return _buildContinueActionWidget();
      case QuestionViewType.none:
        return _buildQuestionActionWidget();
    }
  }

  Widget _buildPointViewActionWidget() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        GestureDetector(
          onTap: () {
            pointList.clear();
            updateQuestionPoint(questionPoint);
            changeQuestionView(QuestionViewType.none);
          },
          child: Text(
            AppString.cancel,
            style: AppTextStyle.title3,
          ).addTapAreaSymmetric(horizontal: 20.w, vertical: 5.h),
        ),
        _buildVerticalDivider(),
        GestureDetector(
          onTap: () {
            for (int i = 0; i < question.answers.length; i++) {
              question.answers[i] = question.answers[i].copyWith(point: pointList[i]);
            }
            questionPoint = question.questionPoint;
            callQuestionCallback();
            pointList.clear();
            changeQuestionView(QuestionViewType.none);
          },
          child: Text(
            AppString.save,
            style: AppTextStyle.title3,
          ).addTapAreaOnly(right: 10.w, top: 5.h, bottom: 5.h, left: 25.w),
        ),
      ],
    ).paddingOnly(top: 6.h, bottom: 6.h, right: 15.w);
  }

  Widget _buildContinueActionWidget() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        _buildVerticalDivider(),
        GestureDetector(
          onTap: () {
            changeQuestionView(QuestionViewType.none);
          },
          child: Text(
            AppString.save,
            style: AppTextStyle.title3,
          ).addTapAreaOnly(right: 10.w, top: 5.h, bottom: 5.h, left: 15.w),
        ),
      ],
    ).paddingOnly(top: 6.h, bottom: 6.h, right: 15.w);
  }

  Widget _buildQuestionActionWidget() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        GestureDetector(
          onTap: () async {
            String? image = await FileUtil().pickImage();
            if (image != null) {
              question = question.copyWith(image: image);
              setState(() {});
              callQuestionCallback();
            }
          },
          child: question.image != null
              ? ClipRRect(
                  borderRadius: BorderRadius.circular(2.r),
                  child: question.image.isImageNetwork
                      ? AppImage(
                          question.image!,
                          size: 21.w,
                          borderRadius: 2.r,
                        )
                      : Image.file(
                          File(question.image!),
                          height: 21.w,
                          width: 21.w,
                          fit: BoxFit.cover,
                        ),
                ).addTapAreaAll(6.w)
              : _buildIcon(AppAsset.media),
        ),
        _buildIcon(
          AppAsset.copy,
          onTap: widget.onCopyTap,
        ),
        _buildIcon(
          AppAsset.deleteOutlined,
          onTap: widget.onDeleteTap,
        ),
        _buildVerticalDivider(),
        Text(
          AppString.required,
          style: AppTextStyle.title3,
        ),
        SizedBox(width: 3.w),
        _buildRequiredSwitch(),
        QuestionMenuPopUp(
          onContinueOptionTap: () {
            changeQuestionView(QuestionViewType.continueOption);
          },
          onAddPointTap: () {
            changeQuestionView(QuestionViewType.point);
          },
          onQuestionTypeTap: () {
            Navigator.pushNamed(
              context,
              Routes.assessmentValueSelectionScreen,
              arguments: AssessmentValueSectionRouteArgument(
                selectionType: AssessmentValueSelectionType.questionType,
                defaultIndex: question.questionType.index,
              ),
            ).then((value) {
              if (value != null && (value is int)) {
                QuestionType questionType = getQuestionTypeFromIndex(value);
                question = question.copyWith(questionType: questionType);
                callQuestionCallback();
              }
            });
          },
        ),
      ],
    ).paddingOnly(top: 6.h, bottom: 6.h, right: 15.w);
  }
}
