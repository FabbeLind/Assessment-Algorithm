import 'package:aitoolkit/features/assessment/widgets/multiple_choice_selection_card.dart';
import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../model/answer_model.dart';

class MultipleChoiceViewWidget extends StatefulWidget {
  const MultipleChoiceViewWidget({
    super.key,
    required this.optionList,
    required this.onOptionSelect,
    this.selectedOptionId,
    this.readOnly = false,
  });

  final List<AnswerModel> optionList;
  final String? selectedOptionId;
  final Function(String selectedId, String selectedValue) onOptionSelect;
  final bool readOnly;

  @override
  State<MultipleChoiceViewWidget> createState() => _MultipleChoiceViewWidgetState();
}

class _MultipleChoiceViewWidgetState extends State<MultipleChoiceViewWidget> {
  int selectedIndex = -1;

  @override
  void initState() {
    if (widget.selectedOptionId != null) {
      selectedIndex = widget.optionList.indexWhere((element) => element.id == widget.selectedOptionId);
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      physics: const NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      padding: EdgeInsets.symmetric(horizontal: 40.w, vertical: 40.h),
      itemCount: widget.optionList.length,
      itemBuilder: (context, index) {
        var option = widget.optionList[index];
        return GestureDetector(
          onTap: widget.readOnly
              ? null
              : () {
                  Debug.log("Multiple choice view --->>> $index // ${option.id} ${option.answer.text}");
                  selectedIndex = index;
                  widget.onOptionSelect.call(option.id, option.answer.text);
                  setState(() {});
                },
          child: MultipleChoiceSelectionCard(
            isSelected: selectedIndex == index,
            text: option.answer.text,
            readOnly: widget.readOnly,
          ),
        );
      },
      separatorBuilder: (context, index) => SizedBox(height: 35.h),
    );
  }
}
