import 'package:aitoolkit/widgets/dialogs/primary_dialog.dart';
import 'package:aitoolkit/widgets/dialogs/primary_text_field_dialog.dart';
import 'package:app_utils/app_utils.dart';
import 'package:flutter/cupertino.dart';

class AssessmentDialog {
  static Future<void> showDelete(
    BuildContext context, {
    required String title,
    required Function() onDeleteTap,
  }) async {
    String titleText = "${AppString.delete} $title";
    String descriptionText = AppString.deleteDescription(title.toLowerCase());

    await PrimaryDialog.show(
      context,
      title: titleText,
      description: descriptionText,
      suffixText: AppString.delete,
      suffixOnTap: onDeleteTap,
    );
  }

  static Future<void> showSheetUrlDialog(
    BuildContext context, {
    required String title,
    required TextEditingController controller,
    required Function() onSubmitTap,
  }) async {
    await PrimaryTextFieldDialog.show(
      context,
      title: title,
      controller: controller,
      hintText: AppString.enterSheetUrlHere,
      suffixText: AppString.submit,
      suffixOnTap: () {
        Navigator.pop(context);
        onSubmitTap.call();
      },
    );
  }
}
