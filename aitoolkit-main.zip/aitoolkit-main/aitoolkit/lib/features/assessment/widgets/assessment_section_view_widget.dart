import 'package:aitoolkit/features/assessment/model/assessment_section_model.dart';
import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../widgets/app_image.dart';

class AssessmentSectionViewWidget extends StatelessWidget {
  const AssessmentSectionViewWidget({
    super.key,
    required this.section,
  });

  final AssessmentSectionModel section;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            section.image.isNotEmptyAndNull
                ? AppImage(
                    section.image!,
                    size: 93.w,
                  )
                : const SizedBox.shrink(),
            SizedBox(height: 30.h),
            Text(
              section.description.text,
              textAlign: TextAlign.center,
              style: AppTextStyle.title3,
            )
          ],
        ).paddingSymmetric(vertical: 25.h, horizontal: 40.w),
      ),
    );
  }
}
