import 'package:app_utils/app_utils.dart';
import 'package:app_utils/constants/constants.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../storage/app_storage.dart';
import '../bloc/assessment_bloc.dart';
import '../model/assessment_model.dart';
import 'assessment_card.dart';

class AssessmentListViewWidget extends StatelessWidget {
  const AssessmentListViewWidget({
    super.key,
    required this.assessmentList,
    required this.assessmentBloc,
  });

  final List<AssessmentModel> assessmentList;
  final AssessmentBloc assessmentBloc;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: (assessmentList.isNotEmpty)
          ? Scrollbar(
              child: ListView.separated(
                shrinkWrap: true,
                padding: EdgeInsets.symmetric(
                  horizontal: 15.w,
                  vertical: 5.h,
                ),
                itemCount: assessmentList.length,
                itemBuilder: (context, index) {
                  var assessment = assessmentList[index];
                  return AssessmentCard(
                    assessment: assessment,
                    progress: assessment.progress.answerCount / assessment.progress.questionCount,
                    showEdit: AppStorage.authUid != null
                        ? assessment.createdBy == AppStorage.authUid
                            ? true
                            : false
                        : false,
                    onCopyTap: () {
                      assessmentBloc.add(CopyAssessmentEvent(assessment.copy()));
                    },
                    onEditTap: () {
                      assessmentBloc.add(EditAssessmentDataLoadEvent(assessment));
                    },
                    onCardTap: () {
                      assessmentBloc.add(AssessmentCardOnClickEvent(AppStorage.authUid ?? "", assessment));
                    },
                  );
                },
                separatorBuilder: (context, index) => SizedBox(height: 20.h),
              ),
            )
          : Align(
              alignment: Alignment.center,
              child: Text(
                AppString.noDataFound,
                style: AppTextStyle.defaultF12W5HintColor,
              ),
            ),
    );
  }
}
