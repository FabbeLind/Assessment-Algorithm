import 'package:aitoolkit/widgets/primary_pop_up.dart';
import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../../../widgets/app_pop_up_item.dart';
import '../../../../widgets/primary_container.dart';

class AssessmentMoreOptionPopUp extends StatefulWidget {
  const AssessmentMoreOptionPopUp({
    super.key,
    required this.publishOnTap,
    required this.previewOnTap,
    required this.setPointsForAllTap,
    required this.deleteAssessmentOnTap,
    required this.exportSheetTap,
    required this.importSheetTap,
  });

  final Function() publishOnTap;
  final Function() previewOnTap;
  final Function() setPointsForAllTap;
  final Function() deleteAssessmentOnTap;
  final Function() exportSheetTap;
  final Function() importSheetTap;

  @override
  State<AssessmentMoreOptionPopUp> createState() => _AssessmentMoreOptionPopUpState();
}

class _AssessmentMoreOptionPopUpState extends State<AssessmentMoreOptionPopUp> {
  Widget _buildDivider() {
    return Divider(
      color: AppThemeData.lightDividerColor,
      thickness: 1.h,
      height: 0,
    );
  }

  Widget _verticalSpace() => SizedBox(height: 5.h);

  Widget _buildMoreIcon() {
    return SvgPicture.asset(
      AppAsset.more,
      height: 22.w,
      width: 22.w,
    ).addTapAreaAll(10.w);
  }

  @override
  Widget build(BuildContext context) {
    return PrimaryPopUp(
      icon: _buildMoreIcon(),
      child: Column(
        children: [
          PrimaryContainer(
            borderRadius: BorderRadius.vertical(top: Radius.circular(8.r)),
            child: Column(
              children: [
                AppPopUpItem(
                  title: AppString.importFromGoogleSheets,
                  icon: AppAsset.import,
                  onTap: widget.importSheetTap.call,
                ),
                _buildDivider(),
                AppPopUpItem(
                  title: AppString.exportToGoogleSheets,
                  icon: AppAsset.export,
                  onTap: widget.exportSheetTap.call,
                ),
              ],
            ),
          ),
          _verticalSpace(),
          _buildBuildCenterItemCard(
            child: AppPopUpItem(
              title: AppString.setPointsForAll,
              onTap: widget.setPointsForAllTap.call,
            ),
          ),
          _verticalSpace(),
          _buildBuildCenterItemCard(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                AppPopUpItem(
                  title: AppString.preview,
                  onTap: widget.previewOnTap.call,
                ),
                _buildDivider(),
                AppPopUpItem(
                  title: AppString.publish,
                  onTap: widget.publishOnTap.call,
                ),
              ],
            ),
          ),
          _verticalSpace(),
          PrimaryContainer(
            borderRadius: BorderRadius.vertical(bottom: Radius.circular(8.r)),
            child: Column(
              children: [
                AppPopUpItem(
                  title: AppString.deleteAssessment,
                  icon: AppAsset.deleteOutlined,
                  onTap: widget.deleteAssessmentOnTap.call,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBuildCenterItemCard({required Widget child}) => PrimaryContainer(
        radius: 8.r,
        boxShadow: [
          BoxShadow(
            offset: const Offset(1, 2),
            blurRadius: 5,
            spreadRadius: 0,
            color: AppThemeData.secondaryShadowColor,
          )
        ],
        borderRadius: BorderRadius.zero,
        child: child,
      );
}
