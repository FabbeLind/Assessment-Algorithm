import 'package:aitoolkit/widgets/primary_pop_up.dart';
import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../../../widgets/app_pop_up_item.dart';
import '../../../../widgets/primary_container.dart';

class QuestionMenuPopUp extends StatefulWidget {
  const QuestionMenuPopUp({
    super.key,
    required this.onAddPointTap,
    required this.onContinueOptionTap,
    required this.onQuestionTypeTap,
  });

  final Function() onAddPointTap;
  final Function() onContinueOptionTap;
  final Function() onQuestionTypeTap;

  @override
  State<QuestionMenuPopUp> createState() => _QuestionMenuPopUpState();
}

class _QuestionMenuPopUpState extends State<QuestionMenuPopUp> {
  Widget _buildDivider() {
    return Divider(
      color: AppThemeData.lightDividerColor,
      thickness: 1.h,
      height: 0,
    );
  }

  Widget _buildMenuIcon() {
    return SvgPicture.asset(
      AppAsset.menu,
      height: 14.h,
    ).addTapAreaSymmetric(vertical: 8.h, horizontal: 10.w);
  }

  @override
  Widget build(BuildContext context) {
    return PrimaryPopUp(
      icon: _buildMenuIcon(),
      child: Column(
        children: [
          PrimaryContainer(
            child: Column(
              children: [
                AppPopUpItem(
                  title: AppString.addPointsToAnswers,
                  icon: AppAsset.starReview,
                  onTap: () {
                    widget.onAddPointTap.call();
                  },
                ),
                _buildDivider(),
                AppPopUpItem(
                  title: AppString.linkSectionOrQuestion,
                  icon: AppAsset.goToFile,
                  onTap: () {
                    widget.onContinueOptionTap.call();
                  },
                ),
                _buildDivider(),
                AppPopUpItem(
                  title: AppString.changeQuestionType,
                  onTap: () {
                    widget.onQuestionTypeTap.call();
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
