import 'dart:io';

import 'package:aitoolkit/features/assessment/bloc/assessment_bloc.dart';
import 'package:aitoolkit/features/assessment/entities/assessment_option_model.dart';
import 'package:aitoolkit/features/assessment/model/assessment_question_model.dart';
import 'package:aitoolkit/features/assessment/model/assessment_section_model.dart';
import 'package:aitoolkit/features/assessment/widgets/assessment_option_widget.dart';
import 'package:aitoolkit/features/assessment/widgets/dialogs/assessment_dialog.dart';
import 'package:aitoolkit/features/assessment/widgets/option_question_widget.dart';
import 'package:aitoolkit/features/assessment/widgets/option_section_widget.dart';
import 'package:aitoolkit/widgets/app_underline_text_field.dart';
import 'package:app_utils/app_utils.dart';
import 'package:app_utils/file_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../../widgets/app_image.dart';
import '../../../widgets/primary_animated_container.dart';
import '../model/assessment_model.dart';
import 'assessment_underline_text_field.dart';

class AssessmentAddEditViewWidget extends StatefulWidget {
  const AssessmentAddEditViewWidget({
    super.key,
    required this.assessment,
    required this.onAssessmentChange,
  });

  final AssessmentModel assessment;
  final Function(AssessmentModel assessment) onAssessmentChange;

  @override
  State<AssessmentAddEditViewWidget> createState() => _AssessmentAddEditViewWidgetState();
}

class _AssessmentAddEditViewWidgetState extends State<AssessmentAddEditViewWidget> with SingleTickerProviderStateMixin {
  String? assessmentImage;
  late AssessmentBloc assessmentBloc;
  late AssessmentModel assessment;
  TextEditingController brief = TextEditingController();
  TextEditingController description = TextEditingController();
  late ScrollController scrollController;
  int selectedIndex = -1;

  @override
  void initState() {
    scrollController = ScrollController();
    scrollController.addListener(() {});
    assessment = widget.assessment;
    description = TextEditingController(text: assessment.description);
    brief = TextEditingController(text: assessment.brief);
    assessmentBloc = context.read<AssessmentBloc>();
    super.initState();
  }

  @override
  void dispose() {
    scrollController.removeListener(() {});
    scrollController.dispose();
    description.dispose();
    brief.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Scrollbar(
        controller: scrollController,
        child: SingleChildScrollView(
          controller: scrollController,
          physics: const BouncingScrollPhysics(),
          child: BlocConsumer<AssessmentBloc, AssessmentState>(
            bloc: AssessmentBloc(),
            listener: (context, state) {},
            builder: (_, state) {
              return Column(
                children: [
                  _buildDescriptionCard(),
                  _verticalSpace(),
                  if (assessment.optionVersionList.isNotEmpty)
                    Theme(
                      data: Theme.of(context).copyWith(
                        canvasColor: Colors.transparent,
                        shadowColor: Colors.transparent,
                      ),
                      child: ReorderableListView(
                        onReorderStart: (index) {
                          HapticFeedback.heavyImpact();
                        },
                        onReorderEnd: (index) {
                          HapticFeedback.lightImpact();
                        },
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        onReorder: _reorderOption,
                        children: [
                          for (int i = 0; i < assessment.optionVersionList.last.optionList.length; i++)
                            _buildAssessmentOptionWidget(
                              index: i,
                              option: assessment.optionVersionList.last.optionList[i],
                            ),
                        ],
                      ),
                    ),
                  _verticalSpace(),
                  _buildAddAssessmentOptionWidget(),
                  SizedBox(height: 35.h),
                ],
              );
            },
          ).paddingSymmetric(horizontal: 15.w, vertical: 20.h),
        ),
      ),
    );
  }

  void _addMaxScroll() {
    scrollController.animateTo(
      scrollController.position.maxScrollExtent,
      duration: const Duration(milliseconds: 600),
      curve: Curves.ease,
    );
  }

  void _callAssessmentCallback() => widget.onAssessmentChange.call(assessment);

  void _reorderOption(int oldIndex, int newIndex) {
    if (newIndex > oldIndex) {
      newIndex -= 1;
    }
    final items = assessment.optionVersionList.last.optionList.removeAt(oldIndex);
    assessment.optionVersionList.last.optionList.insert(newIndex, items);
    _updateOptionIndex();
    setState(() {});
    _callAssessmentCallback();
  }

  void _updateOptionIndex() {
    int sectionInitialIndex = 1;
    int questionInitialIndex = 1;
    for (int i = 0; i < assessment.optionVersionList.last.optionList.length; i++) {
      AssessmentOptionModel currentOption = assessment.optionVersionList.last.optionList[i];
      switch (currentOption.type) {
        case AssessmentOptionType.section:
          currentOption as AssessmentSectionModel;
          assessment.optionVersionList.last.optionList[i] = currentOption.copyWith(index: sectionInitialIndex++);
        case AssessmentOptionType.question:
          currentOption as AssessmentQuestionModel;
          assessment.optionVersionList.last.optionList[i] = currentOption.copyWith(index: questionInitialIndex++);
      }
    }
  }

  Widget _verticalSpace() => SizedBox(height: 10.h);

  Widget _buildDescriptionCard() {
    return PrimaryAnimatedContainer(
      title: AppString.assessment,
      child: Column(
        children: [
          AppUnderlineTextField(
            controller: brief,
            onChanged: (value) {
              assessment = assessment.copyWith(brief: value);
              _callAssessmentCallback();
            },
            hintText: AppString.brief,
          ),
          AppUnderlineTextField(
            controller: description,
            onChanged: (value) {
              assessment = assessment.copyWith(description: value);
              _callAssessmentCallback();
            },
            hintText: AppString.description,
          ),
          Align(
            alignment: Alignment.centerRight,
            child: GestureDetector(
              onTap: () async {
                String? assessmentImage = await FileUtil().pickImage();
                if (assessmentImage != null) {
                  assessment = assessment.copyWith(image: assessmentImage);
                  setState(() {});
                  _callAssessmentCallback();
                }
              },
              child: assessment.image != null
                  ? ClipRRect(
                      borderRadius: BorderRadius.circular(2.r),
                      child: assessment.image.isImageNetwork
                          ? AppImage(
                              assessment.image!,
                              size: 21.w,
                              borderRadius: 2.r,
                            )
                          : Image.file(
                              File(assessment.image!),
                              height: 21.w,
                              width: 21.w,
                              fit: BoxFit.cover,
                            ),
                    ).addTapAreaSymmetric(vertical: 14.h, horizontal: 20.w)
                  : SvgPicture.asset(
                      AppAsset.media,
                      height: 21.w,
                      width: 21.w,
                    ).addTapAreaSymmetric(vertical: 14.h, horizontal: 20.w),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAddAssessmentOptionWidget() {
    return Align(
      alignment: Alignment.centerLeft,
      child: Wrap(
        alignment: WrapAlignment.start,
        runAlignment: WrapAlignment.start,
        crossAxisAlignment: WrapCrossAlignment.start,
        spacing: 16.w,
        children: List.generate(
          AssessmentOptionType.values.length,
          (index) {
            final option = AssessmentOptionType.values[index];
            return AssessmentOptionWidget(
              title: option.title,
              onTap: () => _addSectionAndQuestionOption(option),
            );
          },
        ),
      ),
    );
  }

  void _addSectionAndQuestionOption(AssessmentOptionType option) {
    String id = Utils.generateUid();
    if (option == AssessmentOptionType.section) {
      int lastIndex = _getSectionLastIndex();
      assessment.optionVersionList.last.optionList.add(
        AssessmentSectionModel(
          id: id,
          index: lastIndex + 1,
          title: TextEditingController(),
          description: TextEditingController(),
          playAnimation: true,
        ),
      );
    } else if (option == AssessmentOptionType.question) {
      int lastIndex = _getQuestionLastIndex();
      var question = AssessmentQuestionModel(
        id: id,
        index: lastIndex + 1,
        title: TextEditingController(),
        nextUid: "",
        playAnimation: true,
        answers: [],
      );
      assessment.optionVersionList.last.optionList.add(question);
    }
    setState(() {});
    _callAssessmentCallback();
  }

  int _getSectionLastIndex() {
    return assessment.optionVersionList.last.optionList.isNotEmpty
        ? assessment.optionVersionList.last.optionList
            .lastWhere((element) => element.type == AssessmentOptionType.section,
                orElse: () => AssessmentSectionModel(
                      id: "",
                      index: 0,
                      title: TextEditingController(),
                      description: TextEditingController(),
                    ))
            .index
        : 0;
  }

  int _getQuestionLastIndex() {
    return assessment.optionVersionList.last.optionList.isNotEmpty
        ? assessment.optionVersionList.last.optionList
            .lastWhere((element) => element.type == AssessmentOptionType.question,
                orElse: () => AssessmentQuestionModel(
                      id: "",
                      index: 0,
                      title: TextEditingController(),
                      answers: [],
                    ))
            .index
        : 0;
  }

  Widget _buildAssessmentOptionWidget({
    required int index,
    required AssessmentOptionModel option,
  }) {
    switch (option.type) {
      case AssessmentOptionType.section:
        option as AssessmentSectionModel;
        return OptionSectionWidget(
          key: ValueKey(option.id),
          index: index,
          section: option,
          onSectionChange: (section) {
            var previousSection = assessment.optionVersionList.last.optionList[index];
            previousSection as AssessmentSectionModel;
            if (previousSection.playAnimation && !section.playAnimation) {
              _addMaxScroll();
            }
            assessment.optionVersionList.last.optionList[index] = section;
            setState(() {});
            _callAssessmentCallback();
          },
          onDeleteTap: () {
            AssessmentDialog.showDelete(
              context,
              title: AppString.section,
              onDeleteTap: () {
                assessment.optionVersionList.last.optionList.removeAt(index);
                _updateOptionIndex();
                setState(() {});
                _callAssessmentCallback();
                Navigator.pop(context);
              },
            );
          },
          onCopyTap: () {
            var section = option.copyWith(playAnimation: true);
            assessment.optionVersionList.last.optionList.insert(index + 1, section.copy());
            _updateOptionIndex();
            setState(() {});
            _callAssessmentCallback();
          },
        );
      case AssessmentOptionType.question:
        option as AssessmentQuestionModel;
        return OptionQuestionWidget(
          key: ValueKey(option.id),
          index: index,
          question: option,
          onQuestionChange: (question) {
            var previousQuestion = assessment.optionVersionList.last.optionList[index];
            previousQuestion as AssessmentQuestionModel;
            if (previousQuestion.playAnimation && !question.playAnimation) {
              _addMaxScroll();
            }
            assessment.optionVersionList.last.optionList[index] = question;
            setState(() {});
            _callAssessmentCallback();
          },
          onDeleteTap: () {
            AssessmentDialog.showDelete(
              context,
              title: AppString.question,
              onDeleteTap: () {
                assessment.optionVersionList.last.optionList.removeAt(index);
                _updateOptionIndex();
                setState(() {});
                _callAssessmentCallback();
                Navigator.pop(context);
              },
            );
          },
          onCopyTap: () {
            var question = option.copyWith(playAnimation: true);
            assessment.optionVersionList.last.optionList.insert(index + 1, question.copy());
            _updateOptionIndex();
            setState(() {});
            _callAssessmentCallback();
          },
        );
    }
  }
}
