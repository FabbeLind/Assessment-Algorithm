import 'package:aitoolkit/widgets/primary_container.dart';
import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';

class AssessmentOptionWidget extends StatelessWidget {
  const AssessmentOptionWidget({
    super.key,
    required this.title,
    required this.onTap,
  });

  final String title;
  final Function() onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: PrimaryContainer(
        padding: EdgeInsets.fromLTRB(8.w, 1.h, 4.w, 1.h),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              title,
              style: AppTextStyle.defaultF10W7Primary,
            ),
            SvgPicture.asset(
              AppAsset.add,
              height: 24.w,
              width: 24.w,
              colorFilter: const ColorFilter.mode(AppThemeData.deepBlue, BlendMode.srcIn),
            )
          ],
        ),
      ),
    );
  }
}
