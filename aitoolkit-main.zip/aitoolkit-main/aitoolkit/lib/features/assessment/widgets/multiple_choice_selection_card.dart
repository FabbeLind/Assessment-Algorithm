import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../widgets/primary_container.dart';

class MultipleChoiceSelectionCard extends StatelessWidget {
  const MultipleChoiceSelectionCard({
    super.key,
    required this.isSelected,
    this.readOnly = false,
    required this.text,
  });

  final bool isSelected;
  final bool readOnly;
  final String text;

  @override
  Widget build(BuildContext context) {
    var theme = Theme.of(context).colorScheme;
    Color activeCardColor = readOnly ? theme.primary : Colors.transparent;
    Color inActiveCardColor = readOnly ? AppThemeData.lightShadowColor : Colors.transparent;
    return PrimaryContainer(
      color: isSelected ? activeCardColor : inActiveCardColor,
      border: Border.all(
        color: isSelected ? AppThemeData.secondaryBorderColor : AppThemeData.primaryBorderColor,
        width: 1.w,
      ),
      radius: 8.r,
      boxShadow: const [],
      padding: EdgeInsets.symmetric(
        vertical: 11.h,
        horizontal: 23.w,
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(text,
                style: isSelected
                    ? AppTextStyle.headline
                        .copyWith(fontWeight: FontWeight.w400, color: readOnly ? theme.secondary : theme.primary)
                    : AppTextStyle.headline.copyWith(fontWeight: FontWeight.w300)),
          ),
          if (!readOnly) ...[
            SizedBox(width: 10.w),
            Container(
              height: 17.w,
              width: 17.w,
              padding: EdgeInsets.all(3.w),
              decoration: BoxDecoration(
                color: isSelected ? AppThemeData.primaryBorderColor : Colors.transparent,
                borderRadius: BorderRadius.circular(50.r),
                border: Border.all(
                  color: isSelected ? AppThemeData.secondaryBorderColor : AppThemeData.primaryBorderColor,
                ),
              ),
              child: isSelected
                  ? Container(
                      decoration: BoxDecoration(
                          color: AppThemeData.secondaryBorderColor,
                          borderRadius: BorderRadius.circular(50.r),
                          border: Border.all(
                            color: AppThemeData.white,
                            width: 1.w,
                          )),
                    )
                  : null,
            ),
          ]
        ],
      ),
    );
  }
}
