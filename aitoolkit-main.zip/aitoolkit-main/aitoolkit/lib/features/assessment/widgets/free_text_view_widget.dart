import 'package:aitoolkit/widgets/primary_text_field.dart';
import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class FreeTextViewWidget extends StatefulWidget {
  const FreeTextViewWidget({
    super.key,
    required this.controller,
    this.readOnly = false,
  });

  final TextEditingController controller;
  final bool readOnly;

  @override
  State<FreeTextViewWidget> createState() => _FreeTextViewWidgetState();
}

class _FreeTextViewWidgetState extends State<FreeTextViewWidget> {
  late FocusNode focusNode;

  @override
  void initState() {
    focusNode = FocusNode();
    super.initState();
  }

  @override
  void dispose() {
    focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        GestureDetector(
          onTap: () {
            if (!focusNode.hasFocus) {
              focusNode.requestFocus();
            }
          },
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8.r),
              border: Border.all(
                  color: widget.readOnly ? AppThemeData.secondaryBorderColor : AppThemeData.primaryBorderColor,
                  width: 1.w),
            ),
            constraints: BoxConstraints(minHeight: 200.h, maxHeight: 250.h),
            child: PrimaryTextField(
              controller: widget.controller,
              focusNode: focusNode,
              isDense: true,
              readOnly: widget.readOnly,
              contentPadding: EdgeInsets.symmetric(horizontal: 16.h, vertical: 12.h),
              hintText: AppString.enterYourAnswer,
              maxLines: null,
              keyboardType: TextInputType.multiline,
              border: InputBorder.none,
            ),
          ),
        ),
        SizedBox(height: context.bottomViewInset),
      ],
    ).paddingSymmetric(horizontal: 40.w, vertical: 40.h);
  }
}
