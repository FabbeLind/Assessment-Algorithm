import 'package:aitoolkit/features/assessment/model/assessment_model.dart';
import 'package:app_utils/app_utils.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../../widgets/app_gradient_progress_bar.dart';
import '../../../widgets/primary_container.dart';

class AssessmentCard extends StatelessWidget {
  const AssessmentCard({
    super.key,
    required this.assessment,
    required this.onCardTap,
    required this.onCopyTap,
    required this.onEditTap,
    this.showEdit = false,
    required this.progress,
  });

  final AssessmentModel assessment;
  final Function() onCardTap;
  final Function() onEditTap;
  final Function() onCopyTap;
  final bool showEdit;
  final double progress;

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        GestureDetector(
          onTap: onCardTap,
          child: PrimaryContainer(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                AppGradientProgressBar(progress: progress),
                Column(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Align(
                      alignment: Alignment.center,
                      child: Text(
                        assessment.title ?? AppString.nullValue,
                        textAlign: TextAlign.center,
                        style: AppTextStyle.headline,
                      ),
                    ),
                    SizedBox(height: 16.h),
                    Text(
                      assessment.brief ?? AppString.nullValue,
                      textAlign: TextAlign.left,
                      style: AppTextStyle.body,
                    ),
                  ],
                ).paddingSymmetric(
                  horizontal: 50.w,
                  vertical: 50.h,
                ),
              ],
            ),
          ),
        ),
        if (showEdit)
          Align(
            alignment: Alignment.topRight,
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                GestureDetector(
                  onTap: onCopyTap,
                  child: SvgPicture.asset(
                    AppAsset.copy,
                    height: 21.w,
                    width: 21.w,
                  ),
                ).addTapAreaOnly(
                  top: 10.w,
                  bottom: 5.w,
                  right: 8.w,
                ),
                GestureDetector(
                  onTap: onEditTap,
                  child: SvgPicture.asset(
                    AppAsset.editActive,
                    height: 24.w,
                    width: 24.w,
                  ).addTapAreaOnly(
                    top: 10.w,
                    bottom: 5.w,
                    right: 8.w,
                  ),
                ),
              ],
            ),
          ),
      ],
    );
  }
}
