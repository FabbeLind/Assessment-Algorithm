import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../../widgets/primary_text_field.dart';

class AssessmentUnderlineTextField extends StatefulWidget {
  const AssessmentUnderlineTextField({
    super.key,
    required this.controller,
    required this.hintText,
  });

  final TextEditingController controller;
  final String? hintText;

  @override
  State<AssessmentUnderlineTextField> createState() => _AssessmentUnderlineTextFieldState();
}

class _AssessmentUnderlineTextFieldState extends State<AssessmentUnderlineTextField> {
  late FocusNode focusNode;

  @override
  void initState() {
    focusNode = FocusNode();
    super.initState();
  }

  @override
  void dispose() {
    focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: PrimaryTextField(
                controller: widget.controller,
                focusNode: focusNode,
                isDense: true,
                contentPadding: EdgeInsets.symmetric(vertical: 12.h, horizontal: 20.w),
                border: InputBorder.none,
                hintText: widget.hintText,
              ),
            ),
            GestureDetector(
              onTap: () {
                widget.controller.clear();
                if (focusNode.hasFocus) {
                  focusNode.unfocus();
                }
              },
              child: SvgPicture.asset(
                AppAsset.crossActive,
                height: 18.w,
                width: 18.w,
              ).addTapAreaOnly(top: 12.h, right: 20.w, bottom: 12.h, left: 5.w),
            ),
          ],
        ),
        Divider(height: 0.h, thickness: (0.5).h, color: AppThemeData.secondaryDividerColor)
            .defaultPadding,
      ],
    );
  }
}
