import 'package:aitoolkit/features/assessment/widgets/assessment_close_button.dart';
import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../widgets/primary_container.dart';

class AssessmentQuestionWidget extends StatefulWidget {
  const AssessmentQuestionWidget({
    super.key,
    required this.animationController,
    required this.currentQuestionIndex,
    required this.question,
    required this.totalQuestionCount,
    required this.readOnly,
    required this.prefixIcon,
    required this.suffixIcon,
    required this.questionActionType,
  });

  final AnimationController animationController;
  final int currentQuestionIndex;
  final String question;
  final int totalQuestionCount;
  final bool readOnly;
  final QuestionActionType questionActionType;
  final Widget prefixIcon;
  final Widget suffixIcon;

  @override
  State<AssessmentQuestionWidget> createState() => _AssessmentQuestionWidgetState();
}

class _AssessmentQuestionWidgetState extends State<AssessmentQuestionWidget> {
  late final Animation<Offset> _questionSlideAnimation;
  late final Animation<Offset> _indexSlideAnimation;

  @override
  void initState() {
    _questionSlideAnimation = Tween(
      begin: widget.questionActionType == QuestionActionType.next ? const Offset(1, 0) : const Offset(-1, 0),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: widget.animationController, curve: Curves.decelerate));
    _indexSlideAnimation = Tween(
      begin: const Offset(0, -1),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: widget.animationController, curve: Curves.easeOut));
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    double progressValue = widget.currentQuestionIndex / widget.totalQuestionCount;
    var theme = Theme.of(context).colorScheme;
    return PrimaryContainer(
      width: double.infinity,
      color: AppThemeData.secondaryContainerColor,
      radius: 0.r,
      boxShadow: [
        BoxShadow(
          color: AppThemeData.lightShadowColor,
          offset: const Offset(0, 4),
          spreadRadius: 0,
          blurRadius: 2,
        ),
      ],
      child: Column(
        children: [
          const AssessmentCloseButton(),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              widget.prefixIcon,
              Row(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SlideTransition(
                    position: _indexSlideAnimation,
                    child: ClipRRect(
                      child: Text(
                        widget.currentQuestionIndex.toString(),
                        textAlign: TextAlign.center,
                        style: AppTextStyle.defaultF16W5Primary,
                      ),
                    ),
                  ),
                  Text(
                    " / ${widget.totalQuestionCount}",
                    textAlign: TextAlign.center,
                    style: AppTextStyle.defaultF16W5Primary,
                  ),
                ],
              ),
              widget.suffixIcon,
            ],
          ).paddingSymmetric(horizontal: 10.w),
          TweenAnimationBuilder<double>(
            duration: const Duration(milliseconds: 1000),
            curve: Curves.decelerate,
            tween: Tween<double>(
              begin: 0,
              end: progressValue,
            ),
            builder: (context, value, _) => LinearProgressIndicator(
              value: progressValue,
              backgroundColor: theme.secondary,
              minHeight: 3.h,
              valueColor: AlwaysStoppedAnimation<Color>(theme.primary),
            ),
          ).paddingSymmetric(horizontal: 40.w),
          SizedBox(height: 40.h),
          Align(
            alignment: Alignment.centerLeft,
            child: SlideTransition(
              position: _questionSlideAnimation,
              child: Text(
                key: ValueKey(widget.currentQuestionIndex),
                widget.question,
                maxLines: 6,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.left,
                style: AppTextStyle.defaultF24W7Primary,
              ).paddingSymmetric(horizontal: 40.w),
            ),
          ),
          SizedBox(height: 45.h),
        ],
      ),
    );
  }
}
