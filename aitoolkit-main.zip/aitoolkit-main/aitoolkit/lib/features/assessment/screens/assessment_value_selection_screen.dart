import 'package:aitoolkit/widgets/app_widget.dart';
import 'package:aitoolkit/widgets/primary_app_bar.dart';
import 'package:aitoolkit/widgets/primary_button.dart';
import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../../routes/route_arguments.dart';

class AssessmentValueSelectionScreen extends StatefulWidget {
  const AssessmentValueSelectionScreen({
    super.key,
    required this.argument,
  });

  final AssessmentValueSectionRouteArgument argument;

  @override
  State<AssessmentValueSelectionScreen> createState() => _AssessmentValueSelectionScreenState();
}

class _AssessmentValueSelectionScreenState extends State<AssessmentValueSelectionScreen> {
  final List<String> _valueList = [];
  String title = "";
  int selectedIndex = -1;

  @override
  void initState() {
    title = widget.argument.selectionType.title;
    selectedIndex = widget.argument.defaultIndex;
    List<String> valueList = _getOptionList(widget.argument.selectionType);
    _valueList.addAll(valueList);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            _buildAppBarWidget(title),
            ListView.separated(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              padding: EdgeInsets.symmetric(horizontal: 35.w, vertical: 10.h),
              itemCount: _valueList.length,
              itemBuilder: (context, index) {
                String value = _valueList[index];
                if (value.isNotEmpty) {
                  if (widget.argument.selectionType == AssessmentValueSelectionType.options) {
                    if (value != AppString.endOfAssessment) {
                      value = "${AppString.continueToNext} ${value.toLowerCase()}";
                    }
                  }
                  bool isSelected = selectedIndex == index;
                  return _buildValueListWidget(
                    onTap: () {
                      setState(() {
                        selectedIndex = index;
                      });
                    },
                    value: value,
                    isSelected: isSelected,
                  );
                }
                return const SizedBox.shrink();
              },
              separatorBuilder: (context, index) => SizedBox(height: 10.h),
            ),
            if (widget.argument.selectionType == AssessmentValueSelectionType.publish)
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    PrimaryButton(
                      label: AppString.save,
                      onPressed: () {
                        Navigator.pop(context, selectedIndex);
                      },
                    ).paddingSymmetric(horizontal: 35.w, vertical: 10.h),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildValueListWidget({
    required String value,
    required bool isSelected,
    required Function() onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        color: Colors.transparent,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    value,
                    style: AppTextStyle.title3,
                  ),
                ),
                if (isSelected) SvgPicture.asset(AppAsset.tick).paddingOnly(right: 14.w),
              ],
            ),
            Container(
              height: 1.h,
              margin: EdgeInsets.only(top: 5.h, bottom: 10.h),
              width: double.infinity,
              color: AppThemeData.lightDividerColor,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAppBarWidget(String title) {
    return PrimaryAppBar(
      title: title,
      iconAndLabelColor: AppThemeData.primaryTextColor,
      prefixIcon: (onTap: _prefixOnTap(), widget: AppWidget.backArrowIcon()),
      suffixIcon: (onTap: () {}, widget: AppWidget.suffixSpace()),
    );
  }


  Function() _prefixOnTap() {
    return () {
      if (widget.argument.selectionType == AssessmentValueSelectionType.publish) {
        Navigator.pop(context);
      } else {
        Navigator.pop(context, selectedIndex);
      }
    };
  }

  List<String> _getOptionList(AssessmentValueSelectionType selectionType) {
    switch (selectionType) {
      case AssessmentValueSelectionType.publish:
        return PublishType.values.map((e) => e.title).toList();
      case AssessmentValueSelectionType.questionType:
        return QuestionType.values.map((e) => e.title).toList();
      case AssessmentValueSelectionType.options:
        return AnswerActionType.values.map((e) => e.title).toList();
    }
  }
}
