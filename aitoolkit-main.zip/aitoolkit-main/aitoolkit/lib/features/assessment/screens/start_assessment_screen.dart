import 'package:aitoolkit/features/assessment/bloc/assessment_bloc.dart';
import 'package:aitoolkit/routes/routes.dart';
import 'package:aitoolkit/widgets/loader.dart';
import 'package:aitoolkit/widgets/primary_button.dart';
import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../routes/route_arguments.dart';
import '../../../widgets/app_image.dart';
import '../model/assessment_model.dart';
import '../widgets/assessment_close_button.dart';

class StartAssessmentScreen extends StatefulWidget {
  const StartAssessmentScreen({
    super.key,
    required this.assessment,
  });

  final AssessmentModel assessment;

  @override
  State<StartAssessmentScreen> createState() => _StartAssessmentScreenState();
}

class _StartAssessmentScreenState extends State<StartAssessmentScreen> {
  late AssessmentBloc assessmentBloc;

  @override
  void initState() {
    assessmentBloc = context.read<AssessmentBloc>();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: BlocConsumer<AssessmentBloc, AssessmentState>(
        bloc: assessmentBloc,
        listener: (context, state) {
          if ((state is AssessmentLoadingState)) {
            Loader.show(context);
          } else {
            Loader.dismiss(context);
          }
        },
        builder: (context, state) {
          return SafeArea(
            child: Column(
              children: [
                const AssessmentCloseButton(),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      SizedBox(height: 140.h),
                      if (widget.assessment.image != null && (widget.assessment.image?.isNotEmpty ?? false)) ...[
                        AppImage(
                          widget.assessment.image ?? AppString.nullValue,
                          size: 93.w,
                        ),
                      ],
                      SizedBox(height: 68.h),
                      Text(
                        AppString.welcomeTo,
                        style: AppTextStyle.title1,
                      ),
                      buildVerticalSpace(),
                      Text(
                        widget.assessment.title ?? AppString.nullValue,
                        textAlign: TextAlign.center,
                        style: AppTextStyle.headline,
                      ),
                      buildVerticalSpace(),
                      Text(
                        widget.assessment.description ?? AppString.nullValue,
                        textAlign: TextAlign.center,
                        style: AppTextStyle.body,
                      ),
                      SizedBox(height: 60.h),
                      PrimaryButton(
                        label: AppString.startAssessment,
                        onPressed: () {
                          Navigator.pushReplacementNamed(
                            context,
                            Routes.assessmentScreen,
                            arguments: AssessmentRouteArgument(
                              assessment: widget.assessment,
                              assessmentAnswerList: [],
                            ),
                          );
                        },
                      ),
                    ],
                  ).paddingSymmetric(horizontal: 38.w),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget buildVerticalSpace() => SizedBox(height: 24.h);
}
