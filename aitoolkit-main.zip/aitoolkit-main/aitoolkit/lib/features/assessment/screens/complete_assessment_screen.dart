import 'package:aitoolkit/features/assessment/widgets/assessment_close_button.dart';
import 'package:aitoolkit/widgets/primary_button.dart';
import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class CompleteAssessmentScreen extends StatelessWidget {
  const CompleteAssessmentScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Stack(
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset(
                  AppAsset.checkCircleImage,
                  height: 110.w,
                  width: 110.w,
                ),
                SizedBox(height: 65.h),
                Text(
                  AppString.yourAssessmentHasBeenCompleted,
                  textAlign: TextAlign.center,
                  style: AppTextStyle.defaultF24W7Primary,
                ),
                SizedBox(height: 120.h),
                PrimaryButton(
                  label: AppString.viewGeneratedReport,
                  onPressed: () {
                    Navigator.pop(context);
                  },
                )
              ],
            ).paddingSymmetric(horizontal: 38.w),
            const AssessmentCloseButton(),
          ],
        ),
      ),
    );
  }
}
