import 'package:aitoolkit/features/assessment/entities/assessment_answer_model.dart';
import 'package:aitoolkit/features/assessment/entities/assessment_option_model.dart';
import 'package:aitoolkit/features/assessment/model/assessment_progress.dart';
import 'package:aitoolkit/features/assessment/model/assessment_question_model.dart';
import 'package:aitoolkit/features/assessment/model/assessment_section_model.dart';
import 'package:aitoolkit/features/assessment/model/report_model.dart';
import 'package:aitoolkit/features/assessment/widgets/assessment_section_view_widget.dart';
import 'package:aitoolkit/features/assessment/widgets/free_text_view_widget.dart';
import 'package:aitoolkit/storage/app_storage.dart';
import 'package:aitoolkit/widgets/app_snackbar.dart';
import 'package:aitoolkit/widgets/dialogs/primary_dialog.dart';
import 'package:aitoolkit/widgets/primary_button.dart';
import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../../routes/route_arguments.dart';
import '../../../routes/routes.dart';
import '../../../widgets/app_image.dart';
import '../../../widgets/loader.dart';
import '../bloc/assessment_bloc.dart';
import '../model/multiple_answer_model.dart';
import '../model/single_answer_model.dart';
import '../widgets/assessment_close_button.dart';
import '../widgets/assessment_question_widget.dart';
import '../widgets/check_box_view_widget.dart';
import '../widgets/multiple_choice_view_widget.dart';

class AssessmentScreen extends StatefulWidget {
  const AssessmentScreen({
    super.key,
    required this.assessmentArgs,
  });

  final AssessmentRouteArgument assessmentArgs;

  @override
  State<AssessmentScreen> createState() => _AssessmentScreenState();
}

class _AssessmentScreenState extends State<AssessmentScreen> with SingleTickerProviderStateMixin {
  final List<AssessmentOptionModel> _optionList = [];
  int _currentIndex = 0;
  String _selectedSingleValue = "";
  String _selectedSingleId = "";
  final List<String> _selectedMultipleValue = [];
  final List<String> _selectedMultipleId = [];
  final List<AssessmentAnswerModel> _assessmentAnswerList = [];
  final TextEditingController _freeText = TextEditingController();
  bool _ignoring = false;
  bool _readOnly = false;
  QuestionActionType _questionActionType = QuestionActionType.next;
  late ReportModel _report;
  late AssessmentBloc _assessmentBloc;
  late final AnimationController _animationController;
  late final Animation<Offset> _slideAnimation;

  @override
  void initState() {
    _assessmentBloc = context.read<AssessmentBloc>();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 1.0),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.decelerate,
    ));
    if (!widget.assessmentArgs.preview) {
      if (widget.assessmentArgs.report != null) {
        _report = widget.assessmentArgs.report!;
        _setAssessmentOptionList();
        WidgetsBinding.instance.addPostFrameCallback((_) {
          _showResumeAssessmentDialog();
        });
      } else {
        _assessmentBloc.add(AddReportEvent(
          userId: AppStorage.authUid ?? "",
          assessment: widget.assessmentArgs.assessment,
        ));
      }
    }
    _loadInitialData();
    super.initState();
  }

  void _setAssessmentOptionList() {
    Debug.log("Assessment Version --->>> ${_report.assessmentVersion}");
    if (widget.assessmentArgs.assessment.optionVersionList.isNotEmpty) {
      _optionList.clear();
      int latestVersion = (_report.assessmentVersion > widget.assessmentArgs.assessment.optionVersionList.length)
          ? widget.assessmentArgs.assessment.optionVersionList.last.version
          : _report.assessmentVersion - 1;
      Debug.log(
          "Report length --->>> $latestVersion // ${_report.assessmentVersion} // ${widget.assessmentArgs.assessment.optionVersionList.length}");
      _optionList.addAll(widget.assessmentArgs.assessment.optionVersionList[latestVersion].optionList);
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<AssessmentBloc, AssessmentState>(
      bloc: _assessmentBloc,
      listener: _assessmentListener,
      builder: (context, state) {
        if (_optionList.isNotEmpty) {
          var option = _optionList[_currentIndex];
          bool isRequired = _isQuestionOptional(option);
          return Scaffold(
            extendBodyBehindAppBar: true,
            resizeToAvoidBottomInset: false,
            appBar: _buildAppBar(),
            bottomNavigationBar: (!_readOnly && !widget.assessmentArgs.preview)
                ? Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      _buildNextButton(option, state),
                      if (!isRequired) ...[
                        SizedBox(height: 20.h),
                        _buildSkipButton(option),
                      ],
                    ],
                  ).paddingFromLTRB(38.w, 15.h, 38.w, 50.h)
                : const SizedBox.shrink(),
            body: SafeArea(
              child: IgnorePointer(
                ignoring: _ignoring,
                child: Column(
                  children: [
                    AssessmentQuestionWidget(
                      key: ValueKey(_currentIndex),
                      animationController: _animationController,
                      question: _getOptionTitle(option),
                      currentQuestionIndex: _currentIndex + 1,
                      totalQuestionCount: _optionList.length,
                      readOnly: _readOnly,
                      questionActionType: _questionActionType,
                      prefixIcon: _buildPrefixIcon(option),
                      suffixIcon: _buildSuffixIcon(option),
                    ),
                    Expanded(
                      child: SlideTransition(
                        position: _slideAnimation,
                        child: switch (option.type) {
                          AssessmentOptionType.section =>
                            AssessmentSectionViewWidget(section: option as AssessmentSectionModel),
                          AssessmentOptionType.question => Builder(
                              builder: (_) {
                                option as AssessmentQuestionModel;
                                return Scrollbar(
                                  child: SingleChildScrollView(
                                    primary: true,
                                    child: Column(
                                      children: [
                                        SizedBox(height: 30.h),
                                        option.image.isNotEmptyAndNull
                                            ? AppImage(
                                                option.image!,
                                                size: 93.w,
                                              )
                                            : const SizedBox.shrink(),
                                        switch (option.questionType) {
                                          QuestionType.multipleChoice => MultipleChoiceViewWidget(
                                              key: UniqueKey(),
                                              optionList: option.answers,
                                              selectedOptionId: _selectedSingleId,
                                              readOnly: _readOnly,
                                              onOptionSelect: (String selectedId, String selectedValue) {
                                                _selectedSingleId = selectedId;
                                                _selectedSingleValue = selectedValue;
                                              },
                                            ),
                                          QuestionType.checkBox => CheckBoxViewWidget(
                                              key: UniqueKey(),
                                              optionList: option.answers,
                                              selectedOption: _selectedMultipleId,
                                              readOnly: _readOnly,
                                              onOptionSelect: (List<String> selectedId, List<String> selectedValue) {
                                                _selectedMultipleId.clear();
                                                _selectedMultipleValue.clear();
                                                _selectedMultipleId.addAll(selectedId);
                                                _selectedMultipleValue.addAll(selectedValue);
                                              },
                                            ),
                                          QuestionType.freeText => FreeTextViewWidget(
                                              key: UniqueKey(),
                                              controller: _freeText,
                                              readOnly: _readOnly,
                                            ),
                                        },
                                      ],
                                    ),
                                  ),
                                );
                              },
                            ),
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        } else {
          return _buildNoQuestionFoundWidget();
        }
      },
    );
  }

  Widget _buildNoQuestionFoundWidget() {
    return const Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            AssessmentCloseButton(),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    AppString.noQuestionFoundInThisAssessment,
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _assessmentListener(BuildContext context, AssessmentState state) {
    if ((state is AddReportLoadingState) || (state is RestartAssessmentLoadingState)) {
      Loader.show(context);
    } else if (state is AddAnswerLoadingState) {
      _ignoring = true;
    } else if (state is AddReportSuccessState) {
      _report = state.report;
      _setAssessmentOptionList();
      _setDefaultSelectedOption();
      Loader.dismiss(context);
    } else if ((state is UpdateReportSuccessState)) {
      _report = state.report;
      Loader.dismiss(context);
    } else if (state is AddAnswerSuccessState) {
      _ignoring = false;
      _onAnswerAdded(state.answer);
    } else if (state is RestartAssessmentSuccessState) {
      widget.assessmentArgs.assessmentAnswerList.clear();
      _assessmentAnswerList.clear();
      _setAssessmentOptionList();
      _setDefaultSelectedOption();
      Loader.dismiss(context);
    } else if (state is AddReportErrorState) {
      Loader.dismiss(context);
      AppSnackBar.showError(context, state.message);
    } else if (state is RestartAssessmentErrorState) {
      Loader.dismiss(context);
      AppSnackBar.showError(context, state.message);
    } else if (state is AddAnswerErrorState) {
      _ignoring = false;
      AppSnackBar.showError(context, state.message);
    } else if (state is UpdateReportErrorState) {
      AppSnackBar.showError(context, state.message);
    }
  }

  void _onAnswerAdded(AssessmentAnswerModel answer) {
    int totalPoint = _updateAssessmentAnswerList(answer);
    _assessmentBloc.add(UpdateAssessmentReportEvent(
        implementationId: widget.assessmentArgs.assessment.refId, report: _report.copyWith(point: totalPoint)));
    if (_optionList.isNotEmpty) {
      _changeQuestionOnTap(QuestionActionType.next, _optionList[_currentIndex]);
    }
  }

  Future<void> _showResumeAssessmentDialog() async {
    await PrimaryDialog.show(
      context,
      title: AppString.resumeYourAssessment,
      description: AppString.resumeYourAssessmentDesc,
      prefixText: AppString.restart,
      suffixText: AppString.resume,
      prefixOnTap: () {
        Navigator.pop(context);
        int totalQuestion = widget.assessmentArgs.assessment.optionVersionList.last.optionList
            .where((e) => e.type == AssessmentOptionType.question)
            .toList()
            .length;
        _assessmentBloc.add(RestartAssessmentEvent(
          userId: AppStorage.authUid ?? "",
          implementationId: widget.assessmentArgs.assessment.refId,
          report: _report,
          reportVersion: widget.assessmentArgs.assessment.optionVersionList.last.version,
          progress: AssessmentProgress(
            answerCount: 0,
            questionCount: totalQuestion,
          ),
        ));
      },
      suffixOnTap: () {
        Navigator.pop(context);
      },
    );
  }

  Widget _buildPrefixIcon(AssessmentOptionModel option) {
    bool isFirstIndex = _currentIndex == 0;
    return GestureDetector(
      onTap: () {
        if (!isFirstIndex) {
          _changeQuestionOnTap(QuestionActionType.previous, option);
        }
      },
      child: SvgPicture.asset(
        AppAsset.backArrow,
        height: 22.w,
        width: 22.w,
        colorFilter: ColorFilter.mode(
            isFirstIndex ? AppThemeData.primaryBorderColor : AppThemeData.primaryIconColor, BlendMode.srcIn),
      ).addTapAreaOnly(left: 30.w, top: 10.h, bottom: 14.h),
    );
  }

  Widget _buildSuffixIcon(AssessmentOptionModel option) {
    bool isLastIndex = _currentIndex == (_optionList.length - 1);
    return GestureDetector(
      onTap: () {
        if (!isLastIndex) {
          _changeQuestionOnTap(QuestionActionType.next, option);
        }
      },
      child: SvgPicture.asset(
        AppAsset.forwardArrow,
        height: 22.w,
        width: 22.w,
        colorFilter: ColorFilter.mode(
            isLastIndex ? AppThemeData.primaryBorderColor : AppThemeData.primaryIconColor, BlendMode.srcIn),
      ).addTapAreaOnly(right: 30.w, top: 10.h, bottom: 14.h),
    );
  }

  Widget _buildSkipButton(AssessmentOptionModel option) {
    return PrimaryButton.outlined(
      label: AppString.skip,
      onPressed: () {
        _changeQuestionOnTap(QuestionActionType.next, option);
      },
    );
  }

  Widget _buildNextButton(AssessmentOptionModel option, AssessmentState state) {
    return PrimaryButton(
      isLoading: (state is AddAnswerLoadingState),
      label: _getButtonTitle(option),
      onPressed: () {
        int totalQuestion = _optionList.where((e) => e.type == AssessmentOptionType.question).toList().length;
        if (_isQuestionAnswerValid(option, submitValidation: true)) {
          switch (option.type) {
            case AssessmentOptionType.question:
              option as AssessmentQuestionModel;
              switch (option.questionType) {
                case QuestionType.multipleChoice:
                  _assessmentBloc.add(
                    AddAnswerEvent(
                      userId: AppStorage.authUid ?? "",
                      implementationId: widget.assessmentArgs.assessment.refId,
                      report: _report,
                      progress:
                          AssessmentProgress(answerCount: _assessmentAnswerList.length, questionCount: totalQuestion),
                      answer: SingleAnswerModel(
                        id: "",
                        refId: _report.id,
                        index: _currentIndex + 1,
                        type: QuestionType.multipleChoice,
                        question: option.title.text,
                        questionId: option.id,
                        point: _getPoint(option, [_selectedSingleId]),
                        answer: _selectedSingleValue,
                        answerId: _selectedSingleId,
                      ),
                    ),
                  );
                  break;
                case QuestionType.checkBox:
                  _assessmentBloc.add(
                    AddAnswerEvent(
                      userId: AppStorage.authUid ?? "",
                      implementationId: widget.assessmentArgs.assessment.refId,
                      report: _report,
                      progress:
                          AssessmentProgress(answerCount: _assessmentAnswerList.length, questionCount: totalQuestion),
                      answer: MultipleAnswerModel(
                        id: "",
                        refId: _report.id,
                        index: _currentIndex + 1,
                        type: QuestionType.checkBox,
                        question: option.title.text,
                        questionId: option.id,
                        point: _getPoint(option, _selectedMultipleId),
                        answerList: List.from(_selectedMultipleValue),
                        answerIdList: List<String>.from(_selectedMultipleId),
                      ),
                    ),
                  );
                  break;
                case QuestionType.freeText:
                  _assessmentBloc.add(
                    AddAnswerEvent(
                      userId: AppStorage.authUid ?? "",
                      implementationId: widget.assessmentArgs.assessment.refId,
                      report: _report,
                      progress:
                          AssessmentProgress(answerCount: _assessmentAnswerList.length, questionCount: totalQuestion),
                      answer: SingleAnswerModel(
                        id: "",
                        refId: _report.id,
                        index: _currentIndex + 1,
                        type: QuestionType.freeText,
                        question: option.title.text,
                        questionId: option.id,
                        point: option.questionPoint,
                        answer: _freeText.text,
                        answerId: '',
                      ),
                    ),
                  );
                  break;
              }
            case AssessmentOptionType.section:
              _changeQuestionOnTap(QuestionActionType.next, option);
          }
        } else {
          AppSnackBar.showError(context, AppString.selectAnswerBeforeSubmit);
        }
      },
    );
  }

  void _playOptionAnimation() {
    _animationController.reset();
    _animationController.forward();
  }

  int _getPoint(AssessmentQuestionModel option, List<String> selectedOption) {
    if (option.type == AssessmentOptionType.question) {
      if (option.questionPoint == 0) {
        switch (option.questionType) {
          case QuestionType.multipleChoice:
            return option.answers.firstWhere((element) => element.id == selectedOption.first).point;
          case QuestionType.checkBox:
            List<int> pointList = [];
            for (var answer in option.answers) {
              for (var option in selectedOption) {
                if (option == answer.id) {
                  pointList.add(answer.point);
                }
              }
            }
            return pointList.isNotEmpty ? pointList.reduce((value, element) => value + element) : 0;
          case QuestionType.freeText:
            return option.answers.first.point;
        }
      } else {
        return option.questionPoint;
      }
    } else {
      return 0;
    }
  }

  AppBar _buildAppBar() {
    return AppBar(
      toolbarHeight: 0,
      automaticallyImplyLeading: false,
      centerTitle: true,
      backgroundColor: AppThemeData.secondaryContainerColor,
      systemOverlayStyle: SystemUiOverlayStyle(
        statusBarColor: AppThemeData.secondaryContainerColor,
        statusBarIconBrightness: Brightness.dark,
        statusBarBrightness: Brightness.light,
      ),
    );
  }

  int _updateAssessmentAnswerList(AssessmentAnswerModel answer) {
    _assessmentAnswerList.add(answer);
    int totalPoint = 0;
    if (_assessmentAnswerList.isNotEmpty) {
      if (_assessmentAnswerList.length > 1) {
        totalPoint = _assessmentAnswerList.map((e) => e.point).toList().reduce((value, element) => value + element);
      } else {
        totalPoint = _assessmentAnswerList.first.point;
      }
    }
    return totalPoint;
  }

  void _setDefaultValues() {
    _selectedSingleValue = "";
    _selectedSingleId = "";
    _selectedMultipleValue.clear();
    _selectedMultipleId.clear();
    _freeText.clear();
  }

  void _checkAndSetAnswerReadOnly() {
    _readOnly = false;
    for (var element in widget.assessmentArgs.assessmentAnswerList) {
      if (element.index == (_currentIndex + 1)) {
        _readOnly = true;
        return;
      }
    }
  }

  String _getOptionTitle(AssessmentOptionModel option) {
    switch (option.type) {
      case AssessmentOptionType.question:
        option as AssessmentQuestionModel;
        return option.title.text;
      case AssessmentOptionType.section:
        option as AssessmentSectionModel;
        return "${AppString.section}: ${option.title.text}";
    }
  }

  String _getButtonTitle(AssessmentOptionModel option) {
    switch (option.type) {
      case AssessmentOptionType.question:
        return AppString.next;
      case AssessmentOptionType.section:
        return AppString.continueText;
    }
  }

  void _setDefaultSelectedOption() {
    _setDefaultValues();
    _checkAndSetAnswerReadOnly();
    var option = _optionList[_currentIndex];
    switch (option.type) {
      case AssessmentOptionType.question:
        option as AssessmentQuestionModel;
        switch (option.questionType) {
          case QuestionType.multipleChoice:
            for (var element in _assessmentAnswerList) {
              if (element.index == _currentIndex + 1) {
                element as SingleAnswerModel;
                _selectedSingleId = element.answerId;
              }
            }
            break;
          case QuestionType.checkBox:
            for (var element in _assessmentAnswerList) {
              if (element.index == _currentIndex + 1) {
                element as MultipleAnswerModel;
                _selectedMultipleId.addAll(element.answerIdList);
              }
            }
            break;
          case QuestionType.freeText:
            for (var element in _assessmentAnswerList) {
              if (element.index == _currentIndex + 1) {
                element as SingleAnswerModel;
                _freeText.text = element.answer;
              }
            }
            break;
        }
      case AssessmentOptionType.section:
        break;
    }
    _playOptionAnimation();
    setState(() {});
  }

  void _changeQuestionOnTap(QuestionActionType actionType, AssessmentOptionModel option) {
    switch (actionType) {
      case QuestionActionType.next:
        if ((_currentIndex + 1) == _optionList.length) {
          Navigator.pushReplacementNamed(context, Routes.completeAssessmentScreen);
        } else {
          if (_isQuestionAnswerValid(option)) {
            _questionActionType = QuestionActionType.next;
            if (option.type == AssessmentOptionType.question) {
              option as AssessmentQuestionModel;
              switch (option.nextAction) {
                case AnswerActionType.section:
                  _setValidCurrentIndex(option.nextUid);
                case AnswerActionType.question:
                  _setValidCurrentIndex(option.nextUid);
                case AnswerActionType.end:
                  Navigator.pushReplacementNamed(context, Routes.completeAssessmentScreen);
                case AnswerActionType.none:
                  int answerIndex = _assessmentAnswerList.indexWhere((element) => element.questionId == option.id);
                  if (answerIndex != -1) {
                    var assessmentAnswer = _assessmentAnswerList[answerIndex];
                    switch (assessmentAnswer.type) {
                      case QuestionType.multipleChoice:
                        assessmentAnswer as SingleAnswerModel;
                        int index = option.answers.indexWhere((element) => element.id == assessmentAnswer.answerId);
                        if (index != -1) {
                          _setValidCurrentIndex(option.answers[index].nextUid);
                        } else {
                          _currentIndex++;
                        }
                      case QuestionType.checkBox:
                        assessmentAnswer as MultipleAnswerModel;
                        int index =
                            option.answers.indexWhere((element) => element.id == assessmentAnswer.answerIdList.first);
                        if (index != -1) {
                          _setValidCurrentIndex(option.answers[index].nextUid);
                        } else {
                          _currentIndex++;
                        }
                      case QuestionType.freeText:
                        assessmentAnswer as SingleAnswerModel;
                        _setValidCurrentIndex(option.nextUid);
                    }
                  } else {
                    _currentIndex++;
                  }
              }
              _setPreviousIndex(option.id, _currentIndex);
            } else if (option.type == AssessmentOptionType.section) {
              _currentIndex++;
              _setPreviousIndex(option.id, _currentIndex);
            }
            _setDefaultSelectedOption();
          } else {
            AppSnackBar.showError(context, AppString.submitAnswerBeforeNext);
          }
        }
      case QuestionActionType.previous:
        _questionActionType = QuestionActionType.previous;
        _setValidCurrentIndex(option.previousUid, QuestionActionType.previous);
        _setDefaultSelectedOption();
    }
    setState(() {});
  }

  void _setPreviousIndex(String previousUid, int newIndex) {
    final option = _optionList[newIndex];
    switch (option.type) {
      case AssessmentOptionType.question:
        option as AssessmentQuestionModel;
        _optionList[newIndex] = option.copyWith(previousUid: previousUid);
        break;
      case AssessmentOptionType.section:
        option as AssessmentSectionModel;
        _optionList[newIndex] = option.copyWith(previousUid: previousUid);
        break;
    }
  }

  void _setValidCurrentIndex(String uid, [QuestionActionType type = QuestionActionType.next]) {
    int index = _optionList.indexWhere((element) => element.id == uid);
    if (index != -1) {
      _currentIndex = index;
    } else {
      switch (type) {
        case QuestionActionType.next:
          _currentIndex++;
        case QuestionActionType.previous:
          _currentIndex--;
      }
    }
  }

  bool _isQuestionAnswerValid(AssessmentOptionModel option, {bool submitValidation = false}) {
    bool isValid = false;
    if (option.type == AssessmentOptionType.question) {
      option as AssessmentQuestionModel;
      if (submitValidation) {
        if ((_selectedSingleId.isNotEmpty || _selectedMultipleId.isNotEmpty || _freeText.text.isNotEmpty)) {
          isValid = true;
        }
      } else {
        if (option.required) {
          for (var element in _assessmentAnswerList) {
            if (element.index == (_currentIndex + 1)) {
              isValid = true;
            }
          }
        } else {
          isValid = true;
        }
      }
    } else {
      isValid = true;
    }
    return isValid;
  }

  bool _isQuestionOptional(AssessmentOptionModel option) {
    bool isOptional = false;
    if (option.type == AssessmentOptionType.question) {
      option as AssessmentQuestionModel;
      if (option.required) {
        isOptional = true;
      }
    } else {
      isOptional = true;
    }
    return isOptional;
  }

  void _loadInitialData() {
    _assessmentAnswerList.addAll(widget.assessmentArgs.assessmentAnswerList);
    if (_optionList.isNotEmpty) {
      _setDefaultSelectedOption();
    }
  }
}
