import 'package:aitoolkit/features/assessment/bloc/assessment_bloc.dart';
import 'package:aitoolkit/features/assessment/model/assessment_progress.dart';
import 'package:aitoolkit/features/assessment/model/assessment_question_model.dart';
import 'package:aitoolkit/features/assessment/widgets/assessment_add_edit_view_widget.dart';
import 'package:aitoolkit/features/assessment/widgets/assessment_list_view_widget.dart';
import 'package:aitoolkit/features/assessment/widgets/dialogs/assessment_dialog.dart';
import 'package:aitoolkit/routes/route_arguments.dart';
import 'package:aitoolkit/storage/app_storage.dart';
import 'package:aitoolkit/widgets/app_snackbar.dart';
import 'package:aitoolkit/widgets/primary_app_bar.dart';
import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../../routes/routes.dart';
import '../../../widgets/loader.dart';
import '../model/assessment_model.dart';
import '../model/assessment_version_model.dart';
import '../widgets/pop_up_widgets/assessment_more_option_pop_up.dart';

class AssessmentDashboardScreen extends StatefulWidget {
  const AssessmentDashboardScreen({
    super.key,
    required this.argument,
  });

  final AssessmentDashboardRouteArgument argument;

  @override
  State<AssessmentDashboardScreen> createState() => _AssessmentDashboardScreenState();
}

class _AssessmentDashboardScreenState extends State<AssessmentDashboardScreen> {
  @override
  void initState() {
    super.initState();
    uid = AppStorage.authUid;
    assessmentList.addAll(widget.argument.assessmentList);
    assessmentBloc.add(AssessmentInitialEvent(uid, widget.argument.implementationId));
  }

  String? uid;
  final AssessmentBloc assessmentBloc = AssessmentBloc();
  List<AssessmentModel> assessmentList = [];
  TextEditingController title = TextEditingController();
  AssessmentModel? assessment;
  bool showPopUp = true;

  @override
  Widget build(BuildContext context) {
    var theme = Theme.of(context).colorScheme;
    return BlocProvider(
      create: (context) => assessmentBloc,
      child: Scaffold(
        extendBodyBehindAppBar: true,
        resizeToAvoidBottomInset: true,
        backgroundColor: AppThemeData.white,
        appBar: _buildAppBar(),
        body: SafeArea(
          child: BlocConsumer<AssessmentBloc, AssessmentState>(
            bloc: assessmentBloc,
            listener: assessmentListener,
            buildWhen: (previous, current) => !(previous is AssessmentActionState && current is AssessmentSuccessState),
            builder: (_, state) {
              return Column(
                children: [
                  _buildAppBarWidget(state, theme),
                  (state is AssessmentActionState)
                      ? (assessment != null)
                          ? AssessmentAddEditViewWidget(
                              assessment: assessment!,
                              onAssessmentChange: (updatedAssessment) {
                                assessment = updatedAssessment;
                              },
                            )
                          : const SizedBox.shrink()
                      : AssessmentListViewWidget(
                          assessmentList: assessmentList,
                          assessmentBloc: assessmentBloc,
                        ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildAppBarWidget(AssessmentState state, ColorScheme theme) {
    return PrimaryAppBar(
      controller: title,
      labelText: AppString.title,
      title: _getAssessmentTitle(state),
      appBarActive: (state is AssessmentActionState),
      status: _getAssessmentActiveStatus(state),
      iconAndLabelColor: theme.primary,
      prefixIcon: (widget: _prefixIcon(state), onTap: _prefixOnTap(state)),
      suffixIcon: (widget: _suffixIcon(state), onTap: _suffixOnTap(state)),
      moreSuffixIcon: _moreIcon(state),
      showMoreOption: (_getAssessmentActiveStatus(state) == AppBarStatus.add) ||
          (_getAssessmentActiveStatus(state) == AppBarStatus.edit),
    );
  }

  void assessmentListener(BuildContext context, AssessmentState state) {
    if ((state is AssessmentDataLoadingState) || (state is CopyAssessmentLoadingState)) {
      Loader.show(context);
    } else if (state is AssessmentErrorState) {
      Loader.dismiss(context);
      AppSnackBar.showError(context, state.message);
    } else if (state is CopyAssessmentErrorState) {
      Loader.dismiss(context);
      AppSnackBar.showError(context, state.message);
    } else if (state is AssessmentDataErrorState) {
      Loader.dismiss(context);
      AppSnackBar.showError(context, state.message);
    } else if (state is ImportSuccessState) {
      if (assessment != null) {
        assessment!.optionVersionList.last.optionList.clear();
        assessment!.optionVersionList.last.optionList.addAll(state.optionList);
      }
      Loader.dismiss(context);
    } else if (state is ExportSuccessState) {
      Loader.dismiss(context);
    } else if (state is AssessmentSuccessState) {
      Loader.dismiss(context);
      assessmentList.clear();
      assessmentList.addAll(state.assessmentList);
    } else if (state is AssessmentReportNotExistSuccessState) {
      Loader.dismiss(context);
      Navigator.pushNamed(context, Routes.startAssessmentScreen, arguments: state.assessment).then((value) {
        assessmentBloc.add(AssessmentInitialEvent(uid, widget.argument.implementationId));
      });
    } else if (state is AssessmentReportExistSuccessState) {
      Loader.dismiss(context);
      Navigator.pushNamed(context, Routes.assessmentScreen,
              arguments: AssessmentRouteArgument(
                  assessment: state.assessment, assessmentAnswerList: state.assessmentAnswerList, report: state.report))
          .then((value) {
        assessmentBloc.add(AssessmentInitialEvent(uid, widget.argument.implementationId));
      });
    } else if (state is CopyAssessmentSuccessState) {
      Loader.dismiss(context);
      assessmentBloc.add(AssessmentInitialEvent(uid, widget.argument.implementationId));
    } else if (state is AssessmentActionState) {
      Debug.log("Assessment Action State --->>> ${state.status} ${state.appBarStatus}");
      switch (state.status) {
        case AssessmentActionStateEnum.initial:
          if (state.appBarStatus == AppBarStatus.add) {
            onAddInit();
          } else if (state.appBarStatus == AppBarStatus.edit) {
            Loader.dismiss(context);
            if (state.assessment != null) {
              onEditInit(state.assessment!);
            }
          }
        case AssessmentActionStateEnum.loading:
          Loader.show(context);
        case AssessmentActionStateEnum.success:
          Loader.dismiss(context);
          assessmentBloc.add(AssessmentInitialEvent(uid, widget.argument.implementationId));
        case AssessmentActionStateEnum.error:
          Loader.dismiss(context);
          if (state.message != null) {
            AppSnackBar.showError(context, state.message ?? "");
          }
          break;
      }
    } else {
      Loader.dismiss(context);
    }
  }

  void onAddInit() {
    title.clear();
    DateTime now = DateTime.now();
    assessment = AssessmentModel(
      id: "",
      refId: widget.argument.implementationId,
      refSheetUrl: "",
      optionVersionList: [AssessmentVersionModel(version: 1, optionList: [])],
      publishType: PublishType.toThisImplementation,
      createdBy: AppStorage.authUid ?? "",
      createdAt: now,
      updatedAt: now,
      progress: AssessmentProgress.empty(),
    );
  }

  void onEditInit(AssessmentModel selectedAssessment) {
    title.text = selectedAssessment.title ?? "";
    AssessmentVersionModel newVersion = selectedAssessment.optionVersionList.last.copy();
    newVersion = newVersion.copyWith(version: selectedAssessment.optionVersionList.last.version + 1);
    selectedAssessment.optionVersionList.add(newVersion);
    assessment = selectedAssessment;
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      toolbarHeight: 0,
      automaticallyImplyLeading: false,
      centerTitle: true,
      backgroundColor: AppThemeData.white,
      systemOverlayStyle: const SystemUiOverlayStyle(
        statusBarColor: AppThemeData.white,
        statusBarIconBrightness: Brightness.dark,
        statusBarBrightness: Brightness.light,
      ),
    );
  }

  Widget _moreIcon(AssessmentState state) {
    return AssessmentMoreOptionPopUp(
      publishOnTap: () {
        Navigator.pushNamed(
          context,
          Routes.assessmentValueSelectionScreen,
          arguments: AssessmentValueSectionRouteArgument(
            selectionType: AssessmentValueSelectionType.publish,
            defaultIndex: assessment?.publishType.index ?? 0,
          ),
        ).then((value) {
          if (value != null && (value is int)) {
            PublishType publishType = getPublishTypeFromIndex(value);
            if (assessment != null) {
              assessment = assessment!.copyWith(publishType: publishType);
            }
          }
        });
      },
      deleteAssessmentOnTap: () {
        AssessmentDialog.showDelete(
          context,
          title: AppString.assessment,
          onDeleteTap: () {
            Navigator.pop(context);
            if (assessment != null && (state is AssessmentActionState)) {
              assessmentBloc.add(DeleteAssessmentEvent(assessment!, state.appBarStatus));
            }
          },
        );
      },
      previewOnTap: () {
        if (assessment != null) {
          Navigator.pushNamed(
            context,
            Routes.assessmentScreen,
            arguments: AssessmentRouteArgument(
              preview: true,
              assessment: assessment!,
              assessmentAnswerList: [],
            ),
          );
        }
      },
      setPointsForAllTap: () {
        if (assessment != null && (assessment?.optionVersionList.isNotEmpty ?? false)) {
          for (int i = 0; i < assessment!.optionVersionList.last.optionList.length; i++) {
            final option = assessment!.optionVersionList.last.optionList[i];
            if (option.type == AssessmentOptionType.question) {
              option as AssessmentQuestionModel;
              assessment!.optionVersionList.last.optionList[i] = option.copyWith(questionView: QuestionViewType.point);
            }
          }
          setState(() {});
        }
      },
      exportSheetTap: () async {
        if (assessment != null && (state is AssessmentActionState)) {
          TextEditingController sheetUrl = TextEditingController();
          await AssessmentDialog.showSheetUrlDialog(
            context,
            title: AppString.importFromGoogleSheets,
            controller: sheetUrl,
            onSubmitTap: () {
              assessmentBloc.add(ExportGoogleSheet(
                version: assessment!.optionVersionList.last,
                status: state.appBarStatus,
                sheetId: sheetUrl.text.getGoogleSheetId,
              ));
            },
          );
        }
      },
      importSheetTap: () async {
        if (assessment != null && (state is AssessmentActionState)) {
          TextEditingController sheetUrl = TextEditingController();
          await AssessmentDialog.showSheetUrlDialog(
            context,
            title: AppString.exportToGoogleSheets,
            controller: sheetUrl,
            onSubmitTap: () {
              assessmentBloc.add(ImportGoogleSheet(
                status: state.appBarStatus,
                sheetId: sheetUrl.text.getGoogleSheetId,
                workSheetId: sheetUrl.text.getWorkSheetId,
              ));
            },
          );
        }
      },
    );
  }

  Function() _prefixOnTap(AssessmentState state) {
    return () {
      if (state is AssessmentActionState && (state.appBarStatus == AppBarStatus.edit)) {
        assessmentBloc.add(AssessmentInitialEvent(uid, widget.argument.implementationId));
      } else if ((state is AssessmentActionState) && (state.appBarStatus == AppBarStatus.add)) {
        assessmentBloc.add(AssessmentInitialEvent(uid, widget.argument.implementationId));
      } else {
        Navigator.pop(context);
      }
    };
  }

  Function() _suffixOnTap(AssessmentState state) {
    return () async {
      if ((state is AssessmentActionState) && (state.appBarStatus == AppBarStatus.add)) {
        if (assessment != null) {
          assessment = assessment!.copyWith(title: title.text);
          assessmentBloc.add(AddAssessmentEvent(assessment!, widget.argument.implementationId));
        }
      } else if ((state is AssessmentActionState) && (state.appBarStatus == AppBarStatus.edit)) {
        assessment = assessment!.copyWith(title: title.text);
        assessmentBloc.add(EditAssessmentEvent(assessment!));
      } else {
        assessmentBloc.add(AssessmentStatusChange(AppBarStatus.add));
      }
    };
  }

  Widget _prefixIcon(AssessmentState state) {
    String prefixIcon = AppAsset.backArrowBlack;
    if (state is AssessmentActionState) {
      if (state.appBarStatus == AppBarStatus.view) {
        prefixIcon = AppAsset.backArrowActive;
      } else if (state.appBarStatus == AppBarStatus.edit) {
        prefixIcon = AppAsset.crossActive;
      } else if (state.appBarStatus == AppBarStatus.add) {
        prefixIcon = AppAsset.crossActive;
      }
    }
    return SvgPicture.asset(
      prefixIcon,
      height: 24.w,
      width: 24.w,
    );
  }

  Widget _suffixIcon(AssessmentState state) {
    String suffixIcon = AppAsset.addBlack;
    if (state is AssessmentActionState) {
      if (state.appBarStatus == AppBarStatus.view) {
        suffixIcon = AppAsset.editActive;
      } else if (state.appBarStatus == AppBarStatus.edit) {
        suffixIcon = AppAsset.tickActive;
      } else if (state.appBarStatus == AppBarStatus.add) {
        suffixIcon = AppAsset.tickActive;
      }
    }
    return SvgPicture.asset(
      suffixIcon,
      height: 24.w,
      width: 24.w,
    );
  }

  AppBarStatus _getAssessmentActiveStatus(AssessmentState state) {
    if (state is AssessmentActionState) {
      return state.appBarStatus;
    } else {
      return AppBarStatus.none;
    }
  }

  String _getAssessmentTitle(AssessmentState state) {
    String title = AppString.assessments;
    if (state is AssessmentActionState) {
      if (state.appBarStatus == AppBarStatus.view) {
        title = AppString.viewAssessment;
      } else if (state.appBarStatus == AppBarStatus.edit) {
        title = AppString.editAssessment;
      } else if (state.appBarStatus == AppBarStatus.add) {
        title = AppString.newAssessment;
      }
    }
    return title;
  }
}
