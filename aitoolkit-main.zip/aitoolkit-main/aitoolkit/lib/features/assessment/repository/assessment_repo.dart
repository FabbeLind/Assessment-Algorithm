import 'dart:convert';

import 'package:aitoolkit/features/assessment/entities/assessment_answer_model.dart';
import 'package:aitoolkit/features/assessment/model/assessment_model.dart';
import 'package:aitoolkit/features/assessment/model/assessment_progress.dart';
import 'package:aitoolkit/features/assessment/model/multiple_answer_model.dart';
import 'package:aitoolkit/features/assessment/model/report_model.dart';
import 'package:aitoolkit/features/assessment/model/single_answer_model.dart';
import 'package:app_services/firebase/firebase_firestore_service.dart';
import 'package:app_services/google_sheet_service.dart';
import 'package:app_utils/app_utils.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../entities/assessment_option_model.dart';
import '../model/answer_model.dart';
import '../model/assessment_question_model.dart';
import '../model/assessment_section_model.dart';

part 'assessment_repo_impl.dart';

abstract class AssessmentRepo {
  static final AssessmentRepo _instance = _AssessmentRepoImpl();

  Future<List<AssessmentModel>> getAssessmentList({String? userId, required String implementationId});

  Future<String> addAssessment({
    required String implId,
    required AssessmentModel assessment,
  });

  Future<void> publishAssessmentForAll({
    required String implId,
    required String assessmentId,
  });

  Future<void> publishAssessmentForThis({required String assessmentId});

  Future<void> updateAssessment({
    required String implId,
    required String assessmentId,
    required Map<String, dynamic> updatedAssessmentMap,
  });

  Future<void> updateAssessmentProgress({
    required String implId,
    required String assessmentId,
    required String userId,
    required AssessmentProgress progress,
  });

  Future<ReportModel?> addAssessmentReport({
    required AssessmentModel assessment,
    required ReportModel report,
  });

  Future<ReportModel?> getAssessmentReported({
    required String userId,
    required String implId,
    required String assessmentId,
  });

  Future<ReportModel?> updateAssessmentReported({
    required String implementationId,
    required String reportId,
    required String assessmentId,
    required Map<String, dynamic> reportMap,
  });

  Future<List<AssessmentAnswerModel>> getAssessmentReportAnswer({
    required String implId,
    required String assessmentId,
    required String reportId,
  });

  Future<AssessmentAnswerModel?> addReportAnswer({
    required String implementationId,
    required ReportModel report,
    required AssessmentAnswerModel answer,
  });

  Future<void> deleteAssessmentAnswerList({
    required String implementationId,
    required ReportModel report,
  });

  Future<void> deleteAssessment({
    required String implementationId,
    required String assessmentId,
  });

  Future<void> exportAssessmentToSheet({
    required String sheetId,
    required String workSheetTitle,
    required List<AssessmentOptionModel> optionList,
  });

  Future<List<AssessmentOptionModel>> importAssessmentFromSheet({
    required String sheetId,
    required String workSheetId,
  });

  static AssessmentRepo get instance => _instance;
}
