part of 'assessment_repo.dart';

class _AssessmentRepoImpl extends AssessmentRepo {
  @override
  Future<List<AssessmentModel>> getAssessmentList({
    String? userId,
    required String implementationId,
  }) async {
    try {
      List<Map<String, dynamic>> assessmentData = await FirebaseFirestoreService.getAssessmentList(implementationId);
      List<Map<String, dynamic>> globalAssessmentData = await FirebaseFirestoreService.getGlobalAssessmentList();
      if (assessmentData.isNotEmpty || globalAssessmentData.isNotEmpty) {
        List<AssessmentModel> assessmentList =
            List<AssessmentModel>.from(assessmentData.map((e) => AssessmentModel.fromMap(userId, e)).toList());
        List<AssessmentModel> globalAssessmentList =
            List<AssessmentModel>.from(globalAssessmentData.map((e) => AssessmentModel.fromMap(userId, e)).toList());
        assessmentList.addAll(globalAssessmentList);
        final ids = assessmentList.map((e) => e.id).toSet();
        assessmentList.retainWhere((x) => ids.remove(x.id));
        assessmentList.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
        return assessmentList;
      }
      return [];
    } catch (e) {
      rethrow;
    }
  }

  @override
  Future<String> addAssessment({
    required String implId,
    required AssessmentModel assessment,
  }) async {
    try {
      String assessmentId = await FirebaseFirestoreService.addAssessment(
        implId: implId,
        assessmentMap: assessment.toMap(),
      );
      return assessmentId;
    } catch (e) {
      rethrow;
    }
  }

  @override
  Future<ReportModel?> addAssessmentReport({
    required AssessmentModel assessment,
    required ReportModel report,
  }) async {
    try {
      Map<String, dynamic>? reportData = await FirebaseFirestoreService.addAssessmentReport(
        implId: assessment.refId,
        assessmentId: assessment.id,
        reportMap: report.toMap(),
      );
      if (reportData != null) {
        ReportModel updatedReport = ReportModel.fromMap(reportData);
        return updatedReport;
      }
      return null;
    } catch (e) {
      rethrow;
    }
  }

  @override
  Future<ReportModel?> getAssessmentReported({
    required String userId,
    required String implId,
    required String assessmentId,
  }) async {
    try {
      Map<String, dynamic>? assessmentReport = await FirebaseFirestoreService.getAssessmentReportByUserId(
        userId: userId,
        implId: implId,
        assessmentId: assessmentId,
      );
      if (assessmentReport != null) {
        ReportModel report = ReportModel.fromMap(assessmentReport);
        return report;
      }
      return null;
    } catch (e) {
      rethrow;
    }
  }

  @override
  Future<ReportModel?> updateAssessmentReported({
    required String implementationId,
    required String reportId,
    required String assessmentId,
    required Map<String, dynamic> reportMap,
  }) async {
    try {
      Map<String, dynamic>? reportData = await FirebaseFirestoreService.updateAssessmentReport(
        implId: implementationId,
        assessmentId: assessmentId,
        reportId: reportId,
        reportMap: reportMap,
      );
      if (reportData != null) {
        ReportModel updatedReport = ReportModel.fromMap(reportData);
        return updatedReport;
      }
      return null;
    } catch (e) {
      rethrow;
    }
  }

  @override
  Future<List<AssessmentAnswerModel>> getAssessmentReportAnswer({
    required String implId,
    required String assessmentId,
    required String reportId,
  }) async {
    try {
      List<AssessmentAnswerModel> assessmentAnswerList = [];
      List<Map<String, dynamic>> assessmentAnswerDataList = await FirebaseFirestoreService.getAssessmentAnswerList(
        implId: implId,
        assessmentId: assessmentId,
        reportId: reportId,
      );
      if (assessmentAnswerDataList.isNotEmpty) {
        for (var element in assessmentAnswerDataList) {
          switch (QuestionType.values.byName(element["type"])) {
            case QuestionType.multipleChoice || QuestionType.freeText:
              assessmentAnswerList.add(SingleAnswerModel.fromMap(element));
              break;
            case QuestionType.checkBox:
              assessmentAnswerList.add(MultipleAnswerModel.fromMap(element));
              break;
          }
        }
        assessmentAnswerList.sort((a, b) => a.index.compareTo(b.index));
        return assessmentAnswerList;
      }
      return assessmentAnswerList;
    } catch (e) {
      rethrow;
    }
  }

  @override
  Future<void> updateAssessment({
    required String implId,
    required String assessmentId,
    required Map<String, dynamic> updatedAssessmentMap,
  }) async {
    try {
      await FirebaseFirestoreService.updateAssessment(
        implId: implId,
        assessmentId: assessmentId,
        updatedAssessmentMap: updatedAssessmentMap,
      );
    } catch (e) {
      rethrow;
    }
  }

  @override
  Future<AssessmentAnswerModel?> addReportAnswer({
    required String implementationId,
    required ReportModel report,
    required AssessmentAnswerModel answer,
  }) async {
    try {
      Map<String, dynamic> answerData = {};
      String? answerId = await FirebaseFirestoreService.answerAlreadyExist(
          implId: implementationId, assessmentId: report.refId, reportId: report.id, index: answer.index);
      if ((answer.type == QuestionType.multipleChoice) || (answer.type == QuestionType.freeText)) {
        answer as SingleAnswerModel;
        if (answerId != null) {
          answerData = await FirebaseFirestoreService.updateAssessmentAnswer(
              implId: implementationId,
              assessmentId: report.refId,
              reportId: report.id,
              answerId: answerId,
              updatedAnswerMap: {"answer": answer.answer, "answerId": answer.answerId});
        } else {
          answerData = await FirebaseFirestoreService.addAssessmentAnswer(
              implId: implementationId, assessmentId: report.refId, reportId: report.id, answerMap: answer.toMap());
        }
        return SingleAnswerModel.fromMap(answerData);
      } else if (answer.type == QuestionType.checkBox) {
        answer as MultipleAnswerModel;
        if (answerId != null) {
          answerData = await FirebaseFirestoreService.updateAssessmentAnswer(
              implId: implementationId,
              assessmentId: report.refId,
              reportId: report.id,
              answerId: answerId,
              updatedAnswerMap: {"answer": answer.answerList, "answerId": answer.answerIdList});
        } else {
          answerData = await FirebaseFirestoreService.addAssessmentAnswer(
              implId: implementationId, assessmentId: report.refId, reportId: report.id, answerMap: answer.toMap());
        }
        return MultipleAnswerModel.fromMap(answerData);
      }
      return null;
    } catch (e) {
      rethrow;
    }
  }

  @override
  Future<void> deleteAssessmentAnswerList({
    required String implementationId,
    required ReportModel report,
  }) async {
    try {
      await FirebaseFirestoreService.deleteAssessmentAnswerList(
          implId: implementationId,
          assessmentId: report.refId,
          reportId: report.id,
          updateReportMap: {"point": 0, "updatedAt": Timestamp.fromDate(DateTime.now())});
    } catch (e) {
      rethrow;
    }
  }

  @override
  Future<void> deleteAssessment({
    required String implementationId,
    required String assessmentId,
  }) async {
    try {
      await FirebaseFirestoreService.deleteAssessment(implId: implementationId, assessmentId: assessmentId);
    } catch (e) {
      rethrow;
    }
  }

  @override
  Future<void> updateAssessmentProgress({
    required String implId,
    required String assessmentId,
    required String userId,
    required AssessmentProgress progress,
  }) async {
    try {
      await FirebaseFirestoreService.updateAssessmentProgress(
        implId: implId,
        assessmentId: assessmentId,
        userId: userId,
        progress: progress.toMap(),
      );
    } catch (e) {
      rethrow;
    }
  }

  @override
  Future<void> publishAssessmentForAll({
    required String implId,
    required String assessmentId,
  }) async {
    try {
      await FirebaseFirestoreService.addGlobalAssessment(implementationId: implId, assessmentId: assessmentId);
    } catch (e) {
      rethrow;
    }
  }

  @override
  Future<void> publishAssessmentForThis({required String assessmentId}) async {
    try {
      await FirebaseFirestoreService.deleteGlobalAssessment(assessmentId: assessmentId);
    } catch (e) {
      rethrow;
    }
  }

  @override
  Future<void> exportAssessmentToSheet({
    required String sheetId,
    required String workSheetTitle,
    required List<AssessmentOptionModel> optionList,
  }) async {
    try {
      await SheetService.setSheet(spreadsheetId: sheetId, workSheetTitle: workSheetTitle);
      await SheetService.clearSheet();
      await SheetService.addRowList(kOptionKeyList);
      for (int i = 0; i < optionList.length; i++) {
        final option = optionList[i];
        switch (option.type) {
          case AssessmentOptionType.question:
            option as AssessmentQuestionModel;
            var question = option.encodedMap()..update("index", (value) => i);
            await SheetService.addRowMap(question);
          case AssessmentOptionType.section:
            option as AssessmentSectionModel;
            var section = option.toMap()..update("index", (value) => i);
            await SheetService.addRowMap(section);
        }
      }
    } catch (e) {
      rethrow;
    }
  }

  @override
  Future<List<AssessmentOptionModel>> importAssessmentFromSheet(
      {required String sheetId, required String workSheetId}) async {
    try {
      List<AssessmentOptionModel> optionList = [];
      final assessmentRow = await SheetService.getSheet(
        spreadsheetId: sheetId,
        workSheetId: int.parse(workSheetId),
      );
      int questionIndex = 1;
      int sectionIndex = 1;
      for (int i = 1; i < assessmentRow.length; i++) {
        var optionRow = assessmentRow[i];
        String? image = optionRow.length > 8
            ? optionRow[8].isNotBlank
                ? optionRow[8].trim()
                : null
            : null;
        if (optionRow.length >= 3) {
          String id = Utils.generateUid();
          AssessmentOptionType optionType = AssessmentOptionType.values.byName(optionRow[1].trim().toLowerCase());
          switch (optionType) {
            case AssessmentOptionType.question:
              List<Map<String, dynamic>> answerMapList =
                  optionRow[11].isNotBlank ? jsonDecode(optionRow[11]).cast<Map<String, dynamic>>() : [];
              optionList.add(
                AssessmentQuestionModel(
                  id: optionRow[0].isNotBlank ? optionRow[0].trim() : id,
                  index: questionIndex,
                  title: TextEditingController(text: optionRow[3]),
                  questionType: optionRow[5].isNotBlank
                      ? QuestionType.values.byName(optionRow[5].trim())
                      : QuestionType.multipleChoice,
                  questionPoint: optionRow[6].isNotBlank ? int.parse(optionRow[6].trim()) : 0,
                  required: optionRow[7].isNotBlank ? bool.parse(optionRow[7]) : false,
                  image: image,
                  nextAction: optionRow[9].isNotBlank
                      ? AnswerActionType.values.byName(optionRow[9].trim().toLowerCase())
                      : AnswerActionType.none,
                  nextUid: optionRow[10].isNotBlank ? optionRow[10].trim() : "",
                  answers: List<AnswerModel>.from(answerMapList.map((e) => AnswerModel.fromMap(e)).toList()),
                ),
              );
              questionIndex++;
              break;
            case AssessmentOptionType.section:
              optionList.add(
                AssessmentSectionModel(
                  id: id,
                  index: sectionIndex,
                  title: TextEditingController(text: optionRow[3]),
                  description: TextEditingController(text: optionRow[4]),
                  image: image,
                ),
              );
              sectionIndex++;
              break;
          }
        }
      }
      return optionList;
    } catch (e) {
      rethrow;
    }
  }
}
