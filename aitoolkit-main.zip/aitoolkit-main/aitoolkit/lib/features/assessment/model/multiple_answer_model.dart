import 'package:aitoolkit/features/assessment/entities/assessment_answer_model.dart';
import 'package:app_utils/app_utils.dart';

class MultipleAnswerModel extends AssessmentAnswerModel {
  final List<String> answerList;
  final List<String> answerIdList;

  MultipleAnswerModel({
    required super.id,
    required super.refId,
    required super.index,
    required super.type,
    required super.question,
    required super.questionId,
    required super.point,
    required this.answerList,
    required this.answerIdList,
  });

  MultipleAnswerModel copyWith({
    String? id,
    String? refId,
    int? index,
    QuestionType? type,
    String? question,
    String? questionId,
    int? point,
    List<String>? answerList,
    List<String>? answerIdList,
  }) =>
      MultipleAnswerModel(
        id: id ?? this.id,
        refId: refId ?? this.refId,
        index: index ?? this.index,
        type: type ?? this.type,
        question: question ?? this.question,
        questionId: questionId ?? this.questionId,
        point: point ?? this.point,
        answerList: answerList ?? this.answerList,
        answerIdList: answerIdList ?? this.answerIdList,
      );

  factory MultipleAnswerModel.fromMap(Map<String, dynamic> json) => MultipleAnswerModel(
        id: json["id"],
        refId: json["refId"],
        index: json["index"],
        type: QuestionType.values.byName(json["type"]),
        question: json["question"],
        questionId: json["questionId"],
        point: json["point"] ?? 0,
        answerList: List<String>.from(json["answer"].map((e) => e.toString()).toList()),
        answerIdList: List<String>.from(json["answerId"].map((e) => e.toString()).toList()),
      );

  Map<String, dynamic> toMap() => {
        "id": id,
        "refId": refId,
        "index": index,
        "type": type.name,
        "question": question,
        "questionId": questionId,
        "point": point,
        "answer": answerList,
        "answerId": answerIdList,
      };

  @override
  String toString() {
    return toMap().toString();
  }
}
