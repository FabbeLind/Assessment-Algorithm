import 'dart:convert';

import 'package:aitoolkit/features/assessment/model/assessment_question_model.dart';
import 'package:aitoolkit/features/assessment/model/assessment_section_model.dart';
import 'package:app_utils/app_utils.dart';

import '../entities/assessment_option_model.dart';

class AssessmentVersionModel {
  final int version;
  final List<AssessmentOptionModel> optionList;

  AssessmentVersionModel({
    required this.version,
    required this.optionList,
  });

  AssessmentVersionModel copy() {
    return AssessmentVersionModel(
        version: version,
        optionList: optionList.map((e) {
          return switch (e.type) {
            AssessmentOptionType.question => (e as AssessmentQuestionModel).copy(),
            AssessmentOptionType.section => (e as AssessmentSectionModel).copy(),
          };
        }).toList());
  }

  AssessmentVersionModel copyWith({
    int? version,
    List<AssessmentOptionModel>? optionList,
  }) =>
      AssessmentVersionModel(
        version: version ?? this.version,
        optionList: optionList ?? this.optionList,
      );

  factory AssessmentVersionModel.fromMap(Map<String, dynamic> json) {
    return AssessmentVersionModel(
      version: json["version"],
      optionList: List<AssessmentOptionModel>.from(json["optionList"].map((e) {
        AssessmentOptionType optionType = AssessmentOptionType.values.byName(e["type"]);
        return switch (optionType) {
          AssessmentOptionType.question => AssessmentQuestionModel.fromMap(e),
          AssessmentOptionType.section => AssessmentSectionModel.fromMap(e),
        };
      }).toList()),
    );
  }

  String toMap() {
    return jsonEncode({
      "version": version,
      "optionList": optionList
          .map((e) => switch (e.type) {
                AssessmentOptionType.question => (e as AssessmentQuestionModel).toMap(),
                AssessmentOptionType.section => (e as AssessmentSectionModel).toMap(),
              })
          .toList(),
    });
  }

  @override
  String toString() {
    return toMap().toString();
  }
}
