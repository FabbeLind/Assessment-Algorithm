import 'package:aitoolkit/features/assessment/entities/assessment_answer_model.dart';
import 'package:app_utils/app_utils.dart';

class SingleAnswerModel extends AssessmentAnswerModel {
  final String answer;
  final String answerId;

  SingleAnswerModel({
    required super.id,
    required super.refId,
    required super.index,
    required super.type,
    required super.question,
    required super.questionId,
    required super.point,
    required this.answer,
    required this.answerId,
  });

  SingleAnswerModel copyWith({
    String? id,
    String? refId,
    int? index,
    QuestionType? type,
    String? question,
    String? questionId,
    int? point,
    String? answer,
    String? answerId,
  }) =>
      SingleAnswerModel(
        id: id ?? this.id,
        refId: refId ?? this.refId,
        index: index ?? this.index,
        type: type ?? this.type,
        question: question ?? this.question,
        questionId: questionId ?? this.questionId,
        point: point ?? this.point,
        answer: answer ?? this.answer,
        answerId: answerId ?? this.answerId,
      );

  factory SingleAnswerModel.fromMap(Map<String, dynamic> json) => SingleAnswerModel(
        id: json["id"],
        refId: json["refId"],
        index: json["index"],
        type: QuestionType.values.byName(json["type"]),
        question: json["question"],
        questionId: json["questionId"],
        point: json["point"] ?? 0,
        answer: json["answer"],
        answerId: json["answerId"],
      );

  Map<String, dynamic> toMap() => {
        "id": id,
        "refId": refId,
        "index": index,
        "type": type.name,
        "question": question,
        "questionId": questionId,
        "point": point,
        "answer": answer,
        "answerId": answerId,
      };

  @override
  String toString() {
    return toMap().toString();
  }
}
