import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';

class AnswerModel {
  final String id;
  final int index;
  final int point;
  final TextEditingController answer;
  final FocusNode focusNode;
  final AnswerActionType nextAction;
  final String nextUid;

  AnswerModel({
    required this.id,
    required this.index,
    required this.point,
    required this.answer,
    required this.focusNode,
    required this.nextAction,
    required this.nextUid,
  });

  AnswerModel copyWith({
    String? id,
    int? index,
    int? point,
    AnswerActionType? nextAction,
    String? nextUid,
    TextEditingController? answer,
    FocusNode? focusNode,
  }) =>
      AnswerModel(
        id: id ?? this.id,
        index: index ?? this.index,
        point: point ?? this.point,
        nextUid: nextUid ?? this.nextUid,
        nextAction: nextAction ?? this.nextAction,
        answer: answer ?? this.answer,
        focusNode: focusNode ?? this.focusNode,
      );

  AnswerModel copy() {
    return AnswerModel(
      id: Utils.generateUid(),
      index: index,
      point: point,
      answer: TextEditingController(text: answer.text),
      focusNode: FocusNode(),
      nextAction: nextAction,
      nextUid: nextUid,
    );
  }

  factory AnswerModel.fromMap(Map<String, dynamic> json) => AnswerModel(
        id: json["id"],
        index: json["index"],
        point: json["point"],
        nextUid: json["nextUid"],
        nextAction: AnswerActionType.values.byName(json["nextAction"]),
        answer: TextEditingController(text: json["answer"]),
        focusNode: FocusNode(),
      );

  Map<String, dynamic> toMap() => {
        "id": id,
        "index": index,
        "answer": answer.text,
        "point": point,
        "nextUid": nextUid,
        "nextAction": nextAction.name,
      };

  @override
  String toString() {
    return toMap().toString();
  }
}
