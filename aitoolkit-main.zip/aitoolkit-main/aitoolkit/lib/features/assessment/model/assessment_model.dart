import 'dart:convert';

import 'package:aitoolkit/features/assessment/model/assessment_progress.dart';
import 'package:aitoolkit/features/assessment/model/assessment_version_model.dart';
import 'package:app_utils/app_utils.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AssessmentModel {
  final String id;
  final String refId;
  final String refSheetUrl;
  final String? title;
  final String? brief;
  final String? description;
  final String? image;
  final PublishType publishType;
  final List<AssessmentVersionModel> optionVersionList;
  final AssessmentProgress progress;
  final String createdBy;
  final DateTime createdAt;
  final DateTime updatedAt;

  AssessmentModel({
    required this.id,
    required this.refId,
    required this.refSheetUrl,
    this.title,
    this.brief,
    this.description,
    this.image,
    required this.publishType,
    required this.optionVersionList,
    required this.progress,
    required this.createdBy,
    required this.createdAt,
    required this.updatedAt,
  });

  AssessmentModel copy() {
    return AssessmentModel(
      id: Utils.generateUid(),
      title: "$title ${AppString.copyInBraces}",
      brief: brief,
      description: description,
      image: image,
      refId: refId,
      refSheetUrl: refSheetUrl,
      publishType: publishType,
      optionVersionList: optionVersionList.map((version) => version.copy()).toList(),
      progress: progress,
      createdBy: createdBy,
      createdAt: createdAt,
      updatedAt: updatedAt,
    );
  }

  AssessmentModel copyWith({
    String? id,
    String? refId,
    String? refSheetUrl,
    String? title,
    String? brief,
    String? description,
    String? image,
    PublishType? publishType,
    List<AssessmentVersionModel>? optionVersionList,
    AssessmentProgress? progress,
    String? createdBy,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) =>
      AssessmentModel(
        id: id ?? this.id,
        refId: refId ?? this.refId,
        refSheetUrl: refSheetUrl ?? this.refSheetUrl,
        title: title ?? this.title,
        brief: brief ?? this.brief,
        description: description ?? this.description,
        image: image ?? this.image,
        publishType: publishType ?? this.publishType,
        optionVersionList: optionVersionList ?? this.optionVersionList,
        progress: progress ?? this.progress,
        createdBy: createdBy ?? this.createdBy,
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
      );

  factory AssessmentModel.fromMap(String? userId, Map<String, dynamic> json) {
    List<Map<String, dynamic>> optionVersionList =
        ((json["optionVersionList"] == null) && json["optionVersionList"].isEmpty)
            ? []
            : jsonDecode(json["optionVersionList"]).cast<Map<String, dynamic>>();
    return AssessmentModel(
      id: json["id"],
      refId: json["refId"],
      refSheetUrl: json["refSheetUrl"],
      title: json["title"],
      brief: json["brief"] ?? "",
      description: json["description"],
      image: json["image"],
      publishType: PublishType.values.byName(json["publishType"]),
      optionVersionList:
          List<AssessmentVersionModel>.from(optionVersionList.map((x) => AssessmentVersionModel.fromMap(x))).toList(),
      progress: (json["progress"] != null && userId != null)
          ? json["progress"][userId] != null
              ? AssessmentProgress.fromMap(json["progress"][userId])
              : AssessmentProgress.empty()
          : AssessmentProgress.empty(),
      createdBy: json["createdBy"],
      createdAt: (json["createdAt"] as Timestamp).toDate(),
      updatedAt: (json["updatedAt"] as Timestamp).toDate(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      "id": id,
      "refId": refId,
      "refSheetUrl": refSheetUrl,
      "title": title,
      "brief": brief,
      "description": description,
      "image": image,
      "publishType": publishType.name,
      "optionVersionList": optionVersionList.map((e) => e.toMap()).toList().toString(),
      "createdBy": createdBy,
      "createdAt": Timestamp.fromDate(createdAt),
      "updatedAt": Timestamp.fromDate(updatedAt),
    };
  }

  @override
  String toString() {
    return toMap().toString();
  }
}
