import 'dart:convert';

import 'package:aitoolkit/features/assessment/model/answer_model.dart';
import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';

import '../entities/assessment_option_model.dart';

class AssessmentQuestionModel extends AssessmentOptionModel {
  final bool playAnimation;
  final TextEditingController title;
  final bool required;
  final QuestionType questionType;
  final QuestionViewType questionView;
  final int questionPoint;
  final AnswerActionType nextAction;
  final String nextUid;
  final List<AnswerModel> answers;

  AssessmentQuestionModel({
    required super.id,
    required super.index,
    super.type = AssessmentOptionType.question,
    super.image,
    super.previousUid,
    required this.title,
    this.required = false,
    this.questionType = QuestionType.multipleChoice,
    this.questionView = QuestionViewType.none,
    this.questionPoint = 0,
    this.nextAction = AnswerActionType.none,
    this.nextUid = "",
    this.playAnimation = false,
    required this.answers,
  });

  AssessmentQuestionModel copyWith({
    String? id,
    int? index,
    TextEditingController? title,
    String? image,
    bool? required,
    QuestionType? questionType,
    QuestionViewType? questionView,
    int? questionPoint,
    AnswerActionType? nextAction,
    String? nextUid,
    String? previousUid,
    List<AnswerModel>? answers,
    bool? playAnimation,
  }) =>
      AssessmentQuestionModel(
        id: id ?? this.id,
        index: index ?? this.index,
        title: title ?? this.title,
        image: image ?? this.image,
        required: required ?? this.required,
        questionType: questionType ?? this.questionType,
        questionPoint: questionPoint ?? this.questionPoint,
        questionView: questionView ?? this.questionView,
        nextAction: nextAction ?? this.nextAction,
        nextUid: nextUid ?? this.nextUid,
        previousUid: previousUid ?? this.previousUid,
        answers: answers ?? this.answers,
        playAnimation: playAnimation ?? this.playAnimation,
      );

  AssessmentQuestionModel copy() {
    return AssessmentQuestionModel(
      id: Utils.generateUid(),
      index: index,
      type: type,
      title: TextEditingController(text: title.text),
      image: image,
      required: required,
      questionType: questionType,
      nextAction: nextAction,
      nextUid: nextUid,
      previousUid: previousUid,
      questionPoint: questionPoint,
      playAnimation: playAnimation,
      answers: answers.map((element) => element.copy()).toList(),
    );
  }

  factory AssessmentQuestionModel.fromMap(Map<String, dynamic> json) {
    return AssessmentQuestionModel(
      id: json["id"],
      index: json["index"],
      type: AssessmentOptionType.values.byName(json["type"]),
      title: TextEditingController(text: json["title"]),
      image: json["image"],
      required: json["required"],
      questionType: QuestionType.values.byName(json["questionType"]),
      questionPoint: json["questionPoint"],
      nextAction: AnswerActionType.values.byName(json["nextAction"]),
      nextUid: json["nextUid"],
      answers: List<AnswerModel>.from(json["answers"].map((x) => AnswerModel.fromMap(x))),
    );
  }

  Map<String, dynamic> toMap() => {
        "id": id,
        "index": index,
        "type": type.name,
        "title": title.text,
        "image": image,
        "required": required,
        "nextAction": nextAction.name,
        "nextUid": nextUid,
        "questionType": questionType.name,
        "questionPoint": questionPoint,
        "answers": List<dynamic>.from(answers.map((x) => x.toMap())),
      };

  Map<String, dynamic> encodedMap() => {
        "id": id,
        "index": index,
        "type": type.name,
        "title": title.text,
        "image": image,
        "required": required,
        "nextAction": nextAction.name,
        "nextUid": nextUid,
        "questionType": questionType.name,
        "questionPoint": questionPoint,
        "answers": answers.map((x) => jsonEncode(x.toMap())).toList().toString(),
      };

  @override
  String toString() {
    return toMap().toString();
  }
}
