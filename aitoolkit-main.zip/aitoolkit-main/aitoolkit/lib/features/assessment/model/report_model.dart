import 'package:cloud_firestore/cloud_firestore.dart';

class ReportModel {
  final String id;
  final String refId;
  final int point;
  final int assessmentVersion;
  final String createdBy;
  final DateTime createdAt;
  final DateTime updatedAt;

  ReportModel({
    required this.id,
    required this.refId,
    required this.point,
    required this.assessmentVersion,
    required this.createdBy,
    required this.createdAt,
    required this.updatedAt,
  });

  ReportModel copyWith({
    String? id,
    String? refId,
    int? point,
    int? assessmentVersion,
    String? createdBy,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) =>
      ReportModel(
        id: id ?? this.id,
        refId: refId ?? this.refId,
        point: point ?? this.point,
        assessmentVersion: assessmentVersion ?? this.assessmentVersion,
        createdBy: createdBy ?? this.createdBy,
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
      );

  factory ReportModel.fromMap(Map<String, dynamic> json) => ReportModel(
        id: json["id"],
        refId: json["refId"],
        point: json["point"] ?? 0,
        assessmentVersion: json["assessmentVersion"],
        createdBy: json["createdBy"],
        createdAt: (json["createdAt"] as Timestamp).toDate(),
        updatedAt: (json["updatedAt"] as Timestamp).toDate(),
      );

  Map<String, dynamic> toMap() => {
        "id": id,
        "refId": refId,
        "point": point,
        "assessmentVersion": assessmentVersion,
        "createdBy": createdBy,
        "createdAt": Timestamp.fromDate(createdAt),
        "updatedAt": Timestamp.fromDate(updatedAt),
      };

  @override
  String toString() {
    return toMap().toString();
  }
}
