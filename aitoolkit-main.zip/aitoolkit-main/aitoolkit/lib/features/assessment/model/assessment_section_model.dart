import 'package:aitoolkit/features/assessment/model/assessment_question_model.dart';
import 'package:app_utils/app_utils.dart';
import 'package:flutter/cupertino.dart';

import '../entities/assessment_option_model.dart';

class AssessmentSectionModel extends AssessmentOptionModel {
  final bool playAnimation;
  final TextEditingController title;
  final TextEditingController description;

  AssessmentSectionModel({
    required super.id,
    required super.index,
    required this.title,
    required this.description,
    super.image,
    super.previousUid,
    super.type = AssessmentOptionType.section,
    this.playAnimation = false,
  });

  AssessmentSectionModel copyWith({
    String? id,
    int? index,
    TextEditingController? title,
    TextEditingController? description,
    String? image,
    String? previousUid,
    List<AssessmentQuestionModel>? question,
    bool? playAnimation,
  }) =>
      AssessmentSectionModel(
        id: id ?? this.id,
        index: index ?? this.index,
        title: title ?? this.title,
        description: description ?? this.description,
        image: image ?? this.image,
        previousUid: previousUid ?? this.previousUid,
        playAnimation: playAnimation ?? this.playAnimation,
      );

  AssessmentSectionModel copy() {
    return AssessmentSectionModel(
      id: Utils.generateUid(),
      index: index,
      title: TextEditingController(text: title.text),
      description: TextEditingController(text: description.text),
      image: image,
      playAnimation: playAnimation,
      previousUid: previousUid,
    );
  }

  factory AssessmentSectionModel.fromMap(Map<String, dynamic> json) {
    return AssessmentSectionModel(
      id: json["id"],
      index: json["index"],
      type: AssessmentOptionType.values.byName(json["type"]),
      title: TextEditingController(text: json["title"]),
      description: TextEditingController(text: json["description"]),
      image: json["image"],
    );
  }

  Map<String, dynamic> toMap() => {
        "id": id,
        "index": index,
        "type": type.name,
        "title": title.text,
        "description": description.text,
        "image": image,
      };

  @override
  String toString() {
    return toMap().toString();
  }
}
