class AssessmentProgress {
  final int answerCount;
  final int questionCount;

  AssessmentProgress({
    required this.answerCount,
    required this.questionCount,
  });

  AssessmentProgress.empty({this.answerCount = 0, this.questionCount = 0});

  AssessmentProgress copyWith({
    int? answerCount,
    int? questionCount,
  }) {
    return AssessmentProgress(
      answerCount: answerCount ?? this.answerCount,
      questionCount: questionCount ?? this.questionCount,
    );
  }

  factory AssessmentProgress.fromMap(Map<String, dynamic> json) {
    return AssessmentProgress(
      answerCount: json["answerCount"],
      questionCount: json["questionCount"],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      "answerCount": answerCount,
      "questionCount": questionCount,
    };
  }

  @override
  String toString() {
    return toMap().toString();
  }
}
