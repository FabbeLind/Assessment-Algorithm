part of 'assessment_bloc.dart';

abstract class AssessmentEvent {}

class AssessmentInitialEvent extends AssessmentEvent {
  final String? uid;
  final String implId;

  AssessmentInitialEvent(this.uid, this.implId);
}

class AddReportEvent extends AssessmentEvent {
  final String userId;
  final AssessmentModel assessment;

  AddReportEvent({
    required this.userId,
    required this.assessment,
  });
}

class AddAnswerEvent extends AssessmentEvent {
  final String userId;
  final String implementationId;
  final ReportModel report;
  final AssessmentAnswerModel answer;
  final AssessmentProgress progress;

  AddAnswerEvent({
    required this.userId,
    required this.implementationId,
    required this.report,
    required this.answer,
    required this.progress,
  });
}

class AssessmentCardOnClickEvent extends AssessmentEvent {
  final String userId;
  final AssessmentModel assessment;

  AssessmentCardOnClickEvent(this.userId, this.assessment);
}

class AssessmentStatusChange extends AssessmentEvent {
  final AppBarStatus status;

  AssessmentStatusChange(this.status);
}

class AddAssessmentEvent extends AssessmentEvent {
  final String implementationId;
  final AssessmentModel assessment;

  AddAssessmentEvent(this.assessment, this.implementationId);
}

class EditAssessmentDataLoadEvent extends AssessmentEvent {
  final AssessmentModel assessment;

  EditAssessmentDataLoadEvent(this.assessment);
}

class CopyAssessmentEvent extends AssessmentEvent {
  final AssessmentModel assessment;

  CopyAssessmentEvent(this.assessment);
}

class EditAssessmentEvent extends AssessmentEvent {
  final AssessmentModel assessment;

  EditAssessmentEvent(this.assessment);
}

class DeleteAssessmentEvent extends AssessmentEvent {
  final AppBarStatus appBarStatus;
  final AssessmentModel assessment;

  DeleteAssessmentEvent(this.assessment, this.appBarStatus);
}

class RestartAssessmentEvent extends AssessmentEvent {
  final String userId;
  final String implementationId;
  final ReportModel report;
  final int reportVersion;
  final AssessmentProgress progress;

  RestartAssessmentEvent({
    required this.userId,
    required this.implementationId,
    required this.report,
    required this.reportVersion,
    required this.progress,
  });
}

class UpdateAssessmentReportEvent extends AssessmentEvent {
  final String implementationId;
  final ReportModel report;

  UpdateAssessmentReportEvent({
    required this.implementationId,
    required this.report,
  });
}

class UpdateAssessmentProgress extends AssessmentEvent {
  final String implementationId;
  final String assessmentId;
  final AssessmentProgress progress;

  UpdateAssessmentProgress({
    required this.implementationId,
    required this.assessmentId,
    required this.progress,
  });
}

class ExportGoogleSheet extends AssessmentEvent {
  final AppBarStatus status;
  final AssessmentVersionModel version;
  final String? sheetId;

  ExportGoogleSheet({
    required this.version,
    required this.status,
    required this.sheetId,
  });
}

class ImportGoogleSheet extends AssessmentEvent {
  final AppBarStatus status;
  final String? sheetId;
  final String? workSheetId;

  ImportGoogleSheet({
    required this.status,
    required this.sheetId,
    required this.workSheetId,
  });
}
