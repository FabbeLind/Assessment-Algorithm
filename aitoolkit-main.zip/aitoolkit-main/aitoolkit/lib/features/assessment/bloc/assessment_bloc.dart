import 'dart:async';

import 'package:aitoolkit/features/assessment/entities/assessment_option_model.dart';
import 'package:aitoolkit/features/assessment/model/assessment_model.dart';
import 'package:aitoolkit/features/assessment/model/assessment_version_model.dart';
import 'package:aitoolkit/features/assessment/model/report_model.dart';
import 'package:app_services/firebase/firebase_storage_service.dart';
import 'package:app_utils/app_utils.dart';
import 'package:bloc/bloc.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '../entities/assessment_answer_model.dart';
import '../model/assessment_progress.dart';
import '../model/assessment_question_model.dart';
import '../model/assessment_section_model.dart';
import '../repository/assessment_repo.dart';

part 'assessment_event.dart';

part 'assessment_state.dart';

class AssessmentBloc extends Bloc<AssessmentEvent, AssessmentState> {
  AssessmentBloc() : super(AssessmentInitial()) {
    on<AssessmentInitialEvent>(_assessmentInitialEvent);
    on<AddReportEvent>(_addReportEvent);
    on<UpdateAssessmentReportEvent>(_updateAssessmentReportEvent);
    on<AddAnswerEvent>(_addAnswerEvent);
    on<ExportGoogleSheet>(_exportGoogleSheet);
    on<ImportGoogleSheet>(_importGoogleSheet);
    on<AssessmentStatusChange>(_assessmentStatusChange);
    on<AssessmentCardOnClickEvent>(_assessmentCardOnClickEvent);
    on<AddAssessmentEvent>(_addAssessmentEvent);
    on<CopyAssessmentEvent>(_copyAssessmentEvent);
    on<EditAssessmentDataLoadEvent>(_editAssessmentDataLoadEvent);
    on<EditAssessmentEvent>(_editAssessmentEvent);
    on<RestartAssessmentEvent>(_restartAssessmentEvent);
    on<DeleteAssessmentEvent>(_deleteAssessmentEvent);
  }

  final AssessmentRepo _assessmentRepo = AssessmentRepo.instance;

  Future<void> _assessmentInitialEvent(AssessmentInitialEvent event, Emitter<AssessmentState> emit) async {
    try {
      emit(AssessmentLoadingState());
      List<AssessmentModel> assessmentList =
          await _assessmentRepo.getAssessmentList(userId: event.uid, implementationId: event.implId);
      Debug.log("Assessment List --->>> ${assessmentList.length}");
      emit(AssessmentSuccessState(assessmentList));
    } catch (e, st) {
      emit(AssessmentErrorState("Error occurred while getting assessment"));
      Debug.log(e, st);
    }
  }

  Future<void> _addReportEvent(AddReportEvent event, Emitter<AssessmentState> emit) async {
    try {
      emit(AddReportLoadingState());
      DateTime now = DateTime.now();
      ReportModel report = ReportModel(
        id: "",
        refId: event.assessment.id,
        point: 0,
        assessmentVersion: event.assessment.optionVersionList.last.version,
        createdBy: event.userId,
        createdAt: now,
        updatedAt: now,
      );
      ReportModel? updatedReport = await _assessmentRepo.addAssessmentReport(
        assessment: event.assessment,
        report: report,
      );
      if (updatedReport != null) {
        emit(AddReportSuccessState(updatedReport));
      } else {
        emit(AddReportErrorState("Error while adding report"));
      }
    } catch (e, st) {
      emit(AddReportErrorState("Error while adding report"));
      Debug.log(e, st);
    }
  }

  Future<void> _assessmentCardOnClickEvent(AssessmentCardOnClickEvent event, Emitter<AssessmentState> emit) async {
    try {
      emit(AssessmentDataLoadingState());
      ReportModel? report = await _assessmentRepo.getAssessmentReported(
        userId: event.userId,
        implId: event.assessment.refId,
        assessmentId: event.assessment.id,
      );
      Debug.log("Assessment Report -> $report");
      if (report != null) {
        List<AssessmentAnswerModel> assessmentAnswerList = await _assessmentRepo.getAssessmentReportAnswer(
          implId: event.assessment.refId,
          assessmentId: event.assessment.id,
          reportId: report.id,
        );
        Debug.log("Assessment Answer List -> $assessmentAnswerList");
        emit(AssessmentReportExistSuccessState(
          assessment: event.assessment,
          report: report,
          assessmentAnswerList: assessmentAnswerList,
        ));
      } else {
        emit(AssessmentReportNotExistSuccessState(event.assessment));
      }
    } on Exception catch (e) {
      emit(AssessmentDataErrorState("Error while getting assessment data"));
      Debug.log(e);
    } catch (e, st) {
      emit(AssessmentDataErrorState("Error while getting assessment data"));
      Debug.log(e, st);
    }
  }

  Future<void> _updateAssessmentReportEvent(UpdateAssessmentReportEvent event, Emitter<AssessmentState> emit) async {
    try {
      emit(UpdateReportLoadingState());
      ReportModel? report = await _assessmentRepo.updateAssessmentReported(
        implementationId: event.implementationId,
        assessmentId: event.report.refId,
        reportId: event.report.id,
        reportMap: {"point": event.report.point, "updatedAt": Timestamp.fromDate(DateTime.now())},
      );
      if (report != null) {
        emit(UpdateReportSuccessState(report));
      }
    } catch (e, st) {
      Debug.log(e, st);
      emit(UpdateReportErrorState("Error occurred while updating report"));
    }
  }

  void _assessmentStatusChange(AssessmentStatusChange event, Emitter<AssessmentState> emit) {
    switch (event.status) {
      case AppBarStatus.add:
        emit(AssessmentActionState(appBarStatus: AppBarStatus.add, status: AssessmentActionStateEnum.initial));
      case AppBarStatus.view:
        emit(AssessmentActionState(appBarStatus: AppBarStatus.view));
      case AppBarStatus.edit:
        emit(AssessmentActionState(appBarStatus: AppBarStatus.edit));
      case AppBarStatus.none:
        emit(AssessmentInitial());
    }
  }

  Future<void> _addAssessmentEvent(AddAssessmentEvent event, Emitter<AssessmentState> emit) async {
    try {
      emit(AssessmentActionState(status: AssessmentActionStateEnum.loading, appBarStatus: AppBarStatus.add));
      final assessmentData = _setNextAndPreviousIndex(event.assessment);
      Debug.log("setNextAndPreviousIndex call DONE --->>> ${assessmentData.optionVersionList.last.version}");
      AssessmentModel updatedAssessment = await uploadAssessmentImage(assessmentData);
      List<AssessmentVersionModel> updatedVersion = await uploadVersionImage(updatedAssessment.optionVersionList);
      if ((updatedAssessment.title?.isNotEmptyAndNull ?? false)) {
        DateTime now = DateTime.now();
        AssessmentModel assessment = updatedAssessment.copyWith(
          optionVersionList: updatedVersion,
          createdAt: now,
          updatedAt: now,
        );
        String assessmentId = await _assessmentRepo.addAssessment(
          implId: event.implementationId,
          assessment: assessment,
        );
        if (assessment.publishType == PublishType.toAllImplementation) {
          await _assessmentRepo.publishAssessmentForAll(implId: event.implementationId, assessmentId: assessmentId);
        } else if (assessment.publishType == PublishType.toThisImplementation) {
          await _assessmentRepo.publishAssessmentForThis(assessmentId: assessmentId);
        }
        emit(AssessmentActionState(status: AssessmentActionStateEnum.success, appBarStatus: AppBarStatus.add));
      } else if (updatedAssessment.title.isNullOrEmpty) {
        emit(AssessmentActionState(
          status: AssessmentActionStateEnum.error,
          appBarStatus: AppBarStatus.add,
          message: AppString.titleIsRequired,
        ));
      }
    } catch (e, st) {
      emit(AssessmentActionState(
        status: AssessmentActionStateEnum.error,
        appBarStatus: AppBarStatus.add,
        message: "Error occurred while adding assessment",
      ));
      Debug.log(e, st);
    }
  }

  void _editAssessmentDataLoadEvent(EditAssessmentDataLoadEvent event, Emitter<AssessmentState> emit) {
    emit(AssessmentActionState(
      status: AssessmentActionStateEnum.initial,
      appBarStatus: AppBarStatus.edit,
      assessment: event.assessment,
    ));
  }

  Future<void> _editAssessmentEvent(EditAssessmentEvent event, Emitter<AssessmentState> emit) async {
    try {
      emit(AssessmentActionState(status: AssessmentActionStateEnum.loading, appBarStatus: AppBarStatus.edit));
      final assessmentData = _setNextAndPreviousIndex(event.assessment);
      Debug.log("setNextAndPreviousIndex call DONE --->>> ${assessmentData.optionVersionList.last.version}");
      AssessmentModel assessment = await uploadAssessmentImage(assessmentData);
      List<AssessmentVersionModel> updatedVersion = await uploadVersionImage(assessment.optionVersionList);
      if ((assessment.title?.isNotEmptyAndNull ?? false)) {
        DateTime now = DateTime.now();
        Map<String, dynamic> updatedMap = {
          "optionVersionList": updatedVersion.map((e) => e.toMap()).toList().toString(),
          "updatedAt": now,
          "title": assessment.title,
          "description": assessment.description,
          "image": assessment.image,
        };
        await _assessmentRepo.updateAssessment(
          implId: assessment.refId,
          assessmentId: assessment.id,
          updatedAssessmentMap: updatedMap,
        );
        if (assessment.publishType == PublishType.toAllImplementation) {
          await _assessmentRepo.publishAssessmentForAll(implId: assessment.refId, assessmentId: assessment.id);
        } else if (assessment.publishType == PublishType.toThisImplementation) {
          await _assessmentRepo.publishAssessmentForThis(assessmentId: assessment.id);
        }
        emit(AssessmentActionState(status: AssessmentActionStateEnum.success, appBarStatus: AppBarStatus.edit));
      } else if (assessment.title == null || (assessment.title?.isEmpty ?? true)) {
        emit(AssessmentActionState(
            status: AssessmentActionStateEnum.error,
            appBarStatus: AppBarStatus.edit,
            message: AppString.titleIsRequired));
      }
      emit(AssessmentActionState(status: AssessmentActionStateEnum.success, appBarStatus: AppBarStatus.edit));
    } catch (e, st) {
      Debug.log(e, st);
      emit(AssessmentActionState(
          status: AssessmentActionStateEnum.error,
          appBarStatus: AppBarStatus.edit,
          message: "Error occurred while updating assessment"));
    }
  }

  Future<void> _addAnswerEvent(AddAnswerEvent event, Emitter<AssessmentState> emit) async {
    try {
      emit(AddAnswerLoadingState());
      AssessmentAnswerModel? answer = await _assessmentRepo.addReportAnswer(
        implementationId: event.implementationId,
        report: event.report,
        answer: event.answer,
      );
      if (answer != null) {
        await _assessmentRepo.updateAssessmentProgress(
          implId: event.implementationId,
          assessmentId: event.report.refId,
          userId: event.userId,
          progress: event.progress.copyWith(answerCount: event.progress.answerCount + 1),
        );
      }
      if (answer != null) {
        emit(AddAnswerSuccessState(answer));
      } else {
        emit(AddAnswerErrorState("Error occurred while adding answer"));
      }
    } catch (e, st) {
      Debug.log(e, st);
      emit(AddAnswerErrorState("Error occurred while adding answer"));
    }
  }

  Future<void> _restartAssessmentEvent(RestartAssessmentEvent event, Emitter<AssessmentState> emit) async {
    try {
      emit(RestartAssessmentLoadingState());
      await _assessmentRepo.deleteAssessmentAnswerList(
        implementationId: event.implementationId,
        report: event.report,
      );
      ReportModel? report = await _assessmentRepo.updateAssessmentReported(
        implementationId: event.implementationId,
        assessmentId: event.report.refId,
        reportId: event.report.id,
        reportMap: {"assessmentVersion": event.reportVersion, "updatedAt": Timestamp.fromDate(DateTime.now())},
      );
      if (report != null) {
        await _assessmentRepo.updateAssessmentProgress(
          implId: event.implementationId,
          assessmentId: event.report.refId,
          userId: event.userId,
          progress: event.progress,
        );
        emit(RestartAssessmentSuccessState(report));
      }
    } catch (e, st) {
      Debug.log(e, st);
      emit(RestartAssessmentErrorState("Error occurred while restarting assessment"));
    }
  }

  Future<AssessmentModel> uploadAssessmentImage(AssessmentModel assessment) async {
    try {
      if (assessment.image.isNotEmptyAndNull && !(assessment.image.isImageNetwork)) {
        String imageUrl = await FirebaseStorageService.uploadFileInAssessment(
            assessment.image ?? "", "assessment_${assessment.title!.trim()}_${DateTime.now().millisecondsSinceEpoch}");
        assessment = assessment.copyWith(image: imageUrl);
      }
      return assessment;
    } catch (e, st) {
      Debug.log("Error occurred while uploading image for assessment --->>> $e \n $st");
      rethrow;
    }
  }

  Future<List<AssessmentVersionModel>> uploadVersionImage(List<AssessmentVersionModel> versionList) async {
    try {
      for (int i = 0; i < versionList.last.optionList.length; i++) {
        var option = versionList.last.optionList[i];
        if (option.image.isNotEmptyAndNull && !(option.image.isImageNetwork)) {
          String imageUrl = await FirebaseStorageService.uploadFileInAssessment(
              option.image ?? "", "option_${option.id}_${DateTime.now().millisecondsSinceEpoch}");
          if (option.type == AssessmentOptionType.question) {
            option as AssessmentQuestionModel;
            versionList.last.optionList[i] = option.copyWith(image: imageUrl);
          } else if (option.type == AssessmentOptionType.section) {
            option as AssessmentSectionModel;
            versionList.last.optionList[i] = option.copyWith(image: imageUrl);
          }
        }
      }
      return versionList;
    } catch (e, st) {
      Debug.log("Error while uploading image for version-${versionList.last.version} --->>> $e \n $st");
      rethrow;
    }
  }

  Future<void> _deleteAssessmentEvent(DeleteAssessmentEvent event, Emitter<AssessmentState> emit) async {
    try {
      emit(AssessmentActionState(appBarStatus: event.appBarStatus, status: AssessmentActionStateEnum.loading));
      if (event.appBarStatus == AppBarStatus.edit) {
        await _assessmentRepo.deleteAssessment(
          implementationId: event.assessment.refId,
          assessmentId: event.assessment.id,
        );
      }
      emit(AssessmentActionState(appBarStatus: event.appBarStatus, status: AssessmentActionStateEnum.success));
    } catch (e, st) {
      Debug.log(e, st);
      emit(AssessmentActionState(
        appBarStatus: event.appBarStatus,
        status: AssessmentActionStateEnum.error,
        message: "Error occurred while deleting assessment",
      ));
    }
  }

  AssessmentModel _setNextAndPreviousIndex(AssessmentModel assessment) {
    Debug.log("setNextAndPreviousIndex call --->>> ${assessment.optionVersionList.last.version}");
    for (int i = 0; i < assessment.optionVersionList.last.optionList.length; i++) {
      var currentOption = assessment.optionVersionList.last.optionList[i];
      switch (currentOption.type) {
        case AssessmentOptionType.question:
          String nextSectionUid = _nextSectionUid(i, assessment);
          String nextQuestionUid = _nextQuestionUid(i, assessment);
          Debug.log(
              "Next Index for question-${currentOption.index} // $nextSectionUid $nextQuestionUid --->>> ${assessment.optionVersionList.last.version}");
          currentOption as AssessmentQuestionModel;
          switch (currentOption.nextAction) {
            case AnswerActionType.section:
              currentOption = currentOption.copyWith(
                nextAction: AnswerActionType.section,
                nextUid: nextSectionUid,
              );
              break;
            case AnswerActionType.question:
              currentOption = currentOption.copyWith(
                nextAction: AnswerActionType.question,
                nextUid: nextQuestionUid,
              );
              break;

            case AnswerActionType.end:
              currentOption = currentOption.copyWith(
                nextAction: AnswerActionType.end,
                nextUid: "",
              );
              break;

            case AnswerActionType.none:
              currentOption = currentOption.copyWith(
                nextAction: AnswerActionType.none,
                nextUid: "",
              );
              break;
          }
          for (int j = 0; j < currentOption.answers.length; j++) {
            switch (currentOption.answers[j].nextAction) {
              case AnswerActionType.section:
                currentOption.answers[j] = currentOption.answers[j].copyWith(
                  nextAction: AnswerActionType.section,
                  nextUid: nextSectionUid,
                );
                break;
              case AnswerActionType.question:
                currentOption.answers[j] = currentOption.answers[j].copyWith(
                  nextAction: AnswerActionType.question,
                  nextUid: nextQuestionUid,
                );
                break;
              case AnswerActionType.end:
                currentOption.answers[j] = currentOption.answers[j].copyWith(
                  nextAction: AnswerActionType.end,
                  nextUid: "",
                );
                break;
              case AnswerActionType.none:
                currentOption.answers[j] = currentOption.answers[j].copyWith(
                  nextAction: AnswerActionType.none,
                  nextUid: "",
                );
                break;
            }
          }
          assessment.optionVersionList.last.optionList[i] = currentOption;
        default:
          break;
      }
    }
    return assessment;
  }

  String _nextQuestionUid(int index, AssessmentModel assessment) {
    String questionUid = "";
    for (int i = index + 1; i < assessment.optionVersionList.last.optionList.length; i++) {
      if (assessment.optionVersionList.last.optionList[i].type == AssessmentOptionType.question) {
        questionUid = assessment.optionVersionList.last.optionList[i].id;
        return questionUid;
      }
    }
    return questionUid;
  }

  String _nextSectionUid(int index, AssessmentModel assessment) {
    String sectionUid = "";
    for (int i = index + 1; i < assessment.optionVersionList.last.optionList.length; i++) {
      if (assessment.optionVersionList.last.optionList[i].type == AssessmentOptionType.section) {
        sectionUid = assessment.optionVersionList.last.optionList[i].id;
        return sectionUid;
      }
    }
    return sectionUid;
  }

  Future<void> _copyAssessmentEvent(CopyAssessmentEvent event, Emitter<AssessmentState> emit) async {
    try {
      emit(CopyAssessmentLoadingState());
      DateTime now = DateTime.now();
      AssessmentModel assessment = event.assessment.copyWith(
        createdAt: now,
        updatedAt: now,
      );
      await _assessmentRepo.addAssessment(
        implId: event.assessment.refId,
        assessment: assessment,
      );
      emit(CopyAssessmentSuccessState());
    } catch (e, st) {
      Debug.log(e, st);
      emit(CopyAssessmentErrorState("Error occurred while creating copy of assessment"));
    }
  }

  Future<void> _exportGoogleSheet(ExportGoogleSheet event, Emitter<AssessmentState> emit) async {
    try {
      emit(AssessmentActionState(
        appBarStatus: event.status,
        status: AssessmentActionStateEnum.loading,
      ));
      if (event.sheetId.isNotEmptyAndNull) {
        await _assessmentRepo.exportAssessmentToSheet(
          sheetId: event.sheetId ?? "",
          workSheetTitle: "version${event.version.version}",
          optionList: event.version.optionList,
        );
        emit(ExportSuccessState(
          appBarStatus: event.status,
          status: AssessmentActionStateEnum.success,
        ));
      } else {
        emit(AssessmentActionState(
          appBarStatus: event.status,
          status: AssessmentActionStateEnum.error,
          message: AppString.invalidSpreadsheetLinkProvided,
        ));
      }
    } catch (e, st) {
      Debug.log(e, st);
      emit(AssessmentActionState(
        appBarStatus: event.status,
        status: AssessmentActionStateEnum.error,
        message: "Error occurred while exporting assessment",
      ));
    }
  }

  Future<void> _importGoogleSheet(ImportGoogleSheet event, Emitter<AssessmentState> emit) async {
    try {
      emit(AssessmentActionState(appBarStatus: event.status, status: AssessmentActionStateEnum.loading));
      if (event.sheetId.isNotEmptyAndNull && event.workSheetId.isNotEmptyAndNull) {
        List<AssessmentOptionModel> optionList = await _assessmentRepo.importAssessmentFromSheet(
          sheetId: event.sheetId ?? "",
          workSheetId: event.workSheetId ?? "",
        );
        if (optionList.isNotEmpty) {
          emit(ImportSuccessState(
            appBarStatus: event.status,
            status: AssessmentActionStateEnum.success,
            optionList: optionList,
          ));
        } else {
          emit(AssessmentActionState(
            appBarStatus: event.status,
            status: AssessmentActionStateEnum.error,
            message: AppString.spreadSheetIsEmpty,
          ));
        }
      } else {
        emit(AssessmentActionState(
          appBarStatus: event.status,
          status: AssessmentActionStateEnum.error,
          message: AppString.invalidSpreadsheetLinkProvided,
        ));
      }
    } catch (e, st) {
      Debug.log(e, st);
      emit(AssessmentActionState(
        appBarStatus: event.status,
        status: AssessmentActionStateEnum.error,
        message: "Error occurred while importing assessment",
      ));
    }
  }
}
