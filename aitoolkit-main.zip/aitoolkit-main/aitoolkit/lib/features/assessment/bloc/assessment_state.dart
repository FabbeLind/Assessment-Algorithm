part of 'assessment_bloc.dart';

enum AssessmentActionStateEnum { loading, success, error, initial }

sealed class AssessmentState {}

class AssessmentActionState extends AssessmentState {
  final AssessmentActionStateEnum status;
  final AppBarStatus appBarStatus;
  final String? message;
  final AssessmentModel? assessment;

  AssessmentActionState({
    this.status = AssessmentActionStateEnum.initial,
    this.appBarStatus = AppBarStatus.none,
    this.assessment,
    this.message,
  });

  AssessmentActionState copyWith({
    AssessmentActionStateEnum? status,
    AppBarStatus? appBarStatus,
    AssessmentModel? assessment,
    String? message,
  }) {
    return AssessmentActionState(
      status: status ?? this.status,
      appBarStatus: appBarStatus ?? this.appBarStatus,
      assessment: assessment ?? this.assessment,
      message: message ?? this.message,
    );
  }
}

class ImportSuccessState extends AssessmentActionState {
  final List<AssessmentOptionModel> optionList;

  ImportSuccessState({
    super.appBarStatus,
    super.status,
    super.assessment,
    super.message,
    required this.optionList,
  });
}

class ExportSuccessState extends AssessmentActionState {
  ExportSuccessState({super.appBarStatus, super.status, super.assessment, super.message});
}

class AssessmentInitial extends AssessmentState {}

class AssessmentLoadingState extends AssessmentState {}

class AssessmentErrorState extends AssessmentState {
  final String message;

  AssessmentErrorState(this.message);
}

class AssessmentSuccessState extends AssessmentState {
  List<AssessmentModel> assessmentList;

  AssessmentSuccessState(this.assessmentList);
}

class AssessmentDataLoadingState extends AssessmentState {}

class AssessmentDataErrorState extends AssessmentState {
  final String message;

  AssessmentDataErrorState(this.message);
}

class AssessmentReportExistSuccessState extends AssessmentState {
  final AssessmentModel assessment;
  final ReportModel report;
  final List<AssessmentAnswerModel> assessmentAnswerList;

  AssessmentReportExistSuccessState({
    required this.assessment,
    required this.report,
    required this.assessmentAnswerList,
  });
}

class AssessmentReportNotExistSuccessState extends AssessmentState {
  final AssessmentModel assessment;

  AssessmentReportNotExistSuccessState(this.assessment);
}

class CopyAssessmentLoadingState extends AssessmentState {}

class CopyAssessmentErrorState extends AssessmentState {
  final String message;

  CopyAssessmentErrorState(this.message);
}

class CopyAssessmentSuccessState extends AssessmentState {}

class AddReportLoadingState extends AssessmentState {}

class AddReportErrorState extends AssessmentState {
  final String message;

  AddReportErrorState(this.message);
}

class AddReportSuccessState extends AssessmentState {
  final ReportModel report;

  AddReportSuccessState(this.report);
}

class UpdateReportLoadingState extends AssessmentState {}

class UpdateReportErrorState extends AssessmentState {
  final String message;

  UpdateReportErrorState(this.message);
}

class UpdateReportSuccessState extends AssessmentState {
  final ReportModel report;

  UpdateReportSuccessState(this.report);
}

class AddAnswerLoadingState extends AssessmentState {}

class AddAnswerErrorState extends AssessmentState {
  final String message;

  AddAnswerErrorState(this.message);
}

class AddAnswerSuccessState extends AssessmentState {
  final AssessmentAnswerModel answer;

  AddAnswerSuccessState(this.answer);
}

class RestartAssessmentLoadingState extends AssessmentState {}

class RestartAssessmentErrorState extends AssessmentState {
  final String message;

  RestartAssessmentErrorState(this.message);
}

class RestartAssessmentSuccessState extends AssessmentState {
  final ReportModel report;

  RestartAssessmentSuccessState(this.report);
}

class ExportGoogleSheetLoadingState extends AssessmentState {}

class ExportGoogleSheetErrorState extends AssessmentState {
  final String message;

  ExportGoogleSheetErrorState(this.message);
}

class ExportGoogleSheetSuccessState extends AssessmentState {}
