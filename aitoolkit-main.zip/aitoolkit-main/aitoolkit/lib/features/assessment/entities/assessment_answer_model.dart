import 'package:app_utils/app_utils.dart';

abstract class AssessmentAnswerModel {
  final String id;
  final String refId;
  final int index;
  final QuestionType type;
  final int point;
  final String question;
  final String questionId;

  AssessmentAnswerModel({
    required this.id,
    required this.refId,
    required this.index,
    required this.type,
    required this.point,
    required this.question,
    required this.questionId,
  });

  @override
  String toString() {
    // ignore: unnecessary_override
    return super.toString();
  }
}
