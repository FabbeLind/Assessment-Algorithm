import 'package:app_utils/app_utils.dart';

abstract class AssessmentOptionModel {
  final String id;
  final int index;
  final String? image;
  final AssessmentOptionType type;
  final String previousUid;

  AssessmentOptionModel({
    required this.id,
    required this.index,
    this.image,
    required this.type,
    this.previousUid = "",
  });

  @override
  String toString() {
    // ignore: unnecessary_override
    return super.toString();
  }
}
