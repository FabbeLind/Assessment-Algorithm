part of 'home_repo.dart';

class _HomeRepoImpl extends HomeRepo {
  @override
  Future<ImplementationModel?> getImplementation(String? uid) async {
    try {
      if (uid != null) {
        QuerySnapshot<Object?> implementationData =
            await FirebaseFirestoreService.implementationCollection.where("uidList", arrayContains: uid).get();
        if (implementationData.size > 0) {
          final data = implementationData.docs.first.data() as Map<String, dynamic>;
          ImplementationModel model = ImplementationModel.fromMap(data);
          Debug.log("Implementation --->>> ${implementationData.docs.first.data()}");
          return model;
        }
      }
      return null;
    } catch (e, st) {
      Debug.log(e, st);
      rethrow;
    }
  }
}
