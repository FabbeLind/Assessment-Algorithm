import 'package:aitoolkit/features/implementation/model/implementation_model.dart';
import 'package:app_services/firebase/firebase_firestore_service.dart';
import 'package:app_utils/debug_log_utils.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

part 'home_repo_impl.dart';

abstract class HomeRepo {
  static final HomeRepo _instance = _HomeRepoImpl();

  Future<ImplementationModel?> getImplementation(String? uid);

  static HomeRepo get instance => _instance;
}
