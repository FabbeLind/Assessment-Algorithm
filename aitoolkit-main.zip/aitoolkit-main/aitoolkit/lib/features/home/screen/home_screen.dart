import 'package:aitoolkit/features/initiatives/model/initiative_model.dart';
import 'package:aitoolkit/features/initiatives/widgets/create_initiative_info_card.dart';
import 'package:aitoolkit/routes/route_arguments.dart';
import 'package:aitoolkit/storage/app_storage.dart';
import 'package:aitoolkit/widgets/app_option_widget.dart';
import 'package:aitoolkit/widgets/app_snackbar.dart';
import 'package:aitoolkit/widgets/primary_container.dart';
import 'package:aitoolkit/widgets/primary_home_app_bar.dart';
import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../routes/routes.dart';
import '../../../widgets/get_started_widget.dart';
import '../../../widgets/loader.dart';
import '../../assessment/bloc/assessment_bloc.dart';
import '../../assessment/model/assessment_model.dart';
import '../../initiatives/bloc/initiative_bloc.dart';
import '../bloc/home_bloc.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late HomeBloc homeBloc;
  late AssessmentBloc assessmentBloc;
  late InitiativeBloc initiativeBloc;

  @override
  void initState() {
    super.initState();
    homeBloc = context.read<HomeBloc>();
    assessmentBloc = context.read<AssessmentBloc>();
    initiativeBloc = context.read<InitiativeBloc>();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      homeBloc.add(HomeInitialEvent(uid: AppStorage.authUid ?? ""));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Align(
          alignment: Alignment.bottomRight,
          child: Image.asset(
            AppAsset.homeBgImage,
            height: context.height * 0.71,
            alignment: Alignment.bottomRight,
          ),
        ),
        BlocConsumer<HomeBloc, HomeState>(
          bloc: homeBloc,
          listenWhen: (previous, current) => previous != current,
          buildWhen: (previous, current) => previous != current,
          listener: (ctx, state) {
            if (state is HomeLoadingState) {
              Loader.show(context);
            } else if (state is HomeErrorState) {
              Loader.dismiss(context);
              AppSnackBar.showError(context, state.message);
            } else {
              Loader.dismiss(context);
            }
          },
          builder: (context, state) {
            return SingleChildScrollView(
              child: Column(
                children: [
                  const PrimaryHomeAppBar(title: AppString.home).defaultPadding,
                  SizedBox(height: 40.h),
                  if (state is ImplementationExist)
                    _buildWorkAndGetStartedWidget(
                      initiativeList: state.initiativeList,
                      assessmentList: state.assessmentList,
                    ),
                  if (state is ImplementationNotExist) _buildGetStartedCreateImplementationWidget(),
                ],
              ),
            );
          },
        ),
      ],
    );
  }

  Widget _buildGetStartedCreateImplementationWidget() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        _buildGetStartedText().defaultPadding,
        SizedBox(height: 10.h),
        _buildCreateImplementationCard().defaultPadding,
      ],
    );
  }

  Widget _buildCreateImplementationCard() {
    return GetStartedCardWidget(
      padding: EdgeInsets.fromLTRB(48.w, 43.h, 48.w, 43.h),
      image: AppAsset.aiLogo,
      title: AppString.createImplementation,
      description: AppString.createImplementationDesc,
      buttonWidth: 242.w,
      onTap: () {
        Navigator.pushNamed(context, Routes.createImplementationScreen, arguments: AppStorage.authUid);
      },
    );
  }

  Widget _buildWorkAndGetStartedWidget({
    required List<AssessmentModel> assessmentList,
    required List<InitiativeModel> initiativeList,
  }) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildMyWorkText().defaultPadding,
        SizedBox(height: 10.h),
        _buildMyWorkWidget(
          initiativeList: initiativeList,
          assessmentList: assessmentList,
        ).defaultPadding,
        SizedBox(height: 75.h),
        if (assessmentList.isNotEmpty || initiativeList.isEmpty) ...[
          _buildGetStartedText().defaultPadding,
          BlocConsumer<AssessmentBloc, AssessmentState>(
            listener: _assessmentListener,
            builder: (context, state) {
              return _buildAssessmentListView(
                assessmentList: assessmentList,
                initiativeList: initiativeList,
              );
            },
          ),
        ]
      ],
    );
  }

  void _assessmentListener(BuildContext ctx, AssessmentState state) {
    switch (state) {
      case AssessmentDataLoadingState():
        Loader.show(context);
      case AssessmentDataErrorState():
        Loader.dismiss(context);
        AppSnackBar.showError(context, state.message);
      case AssessmentReportExistSuccessState():
        Loader.dismiss(context);
        Navigator.pushNamed(context, Routes.assessmentScreen,
            arguments: AssessmentRouteArgument(
              assessment: state.assessment,
              assessmentAnswerList: state.assessmentAnswerList,
              report: state.report,
            ));
      case AssessmentReportNotExistSuccessState():
        Loader.dismiss(context);
        Navigator.pushNamed(
          context,
          Routes.startAssessmentScreen,
          arguments: state.assessment,
        );
      default:
        Loader.dismiss(context);
    }
  }

  Widget _buildAssessmentListView({
    required List<AssessmentModel> assessmentList,
    required List<InitiativeModel> initiativeList,
  }) {
    return SingleChildScrollView(
      padding: EdgeInsets.only(
        top: 10.h,
        bottom: 20.h,
      ),
      scrollDirection: Axis.horizontal,
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        if (initiativeList.isEmpty)
          CreateInitiativeInfoCard(
            width: context.width * 0.72,
            onTap: () {
              Navigator.pushNamed(context, Routes.initiativeScreen,
                  arguments: InitiativeRouteArgument(
                    initiativeList: [],
                    implementationId: homeBloc.implementation?.id ?? "",
                    status: AppBarStatus.add,
                  ));
            },
          ),
        SizedBox(width: 16.w),
        ...assessmentList.map(
          (assessment) => GetStartedCardWidget(
            title: assessment.title ?? AppString.nullValue,
            description: assessment.description ?? AppString.nullValue,
            image: assessment.image,
            width: context.width * 0.72,
            onTap: () {
              assessmentBloc.add(AssessmentCardOnClickEvent(AppStorage.authUid ?? "", assessment));
            },
          ).paddingOnly(right: 16.w),
        ),
      ]).defaultPadding,
    );
  }

  Widget _buildMyWorkText() {
    return Align(
      alignment: Alignment.centerLeft,
      child: Padding(
        padding: EdgeInsets.only(left: 15.w),
        child: Text(
          AppString.myWork,
          textAlign: TextAlign.left,
          style: AppTextStyle.title2,
        ),
      ),
    );
  }

  Widget _buildGetStartedText() {
    return Align(
      alignment: Alignment.centerLeft,
      child: Padding(
        padding: EdgeInsets.only(left: 15.w),
        child: Text(
          AppString.getStarted,
          textAlign: TextAlign.left,
          style: AppTextStyle.title2,
        ),
      ),
    );
  }

  Widget _buildMyWorkWidget({
    required List<AssessmentModel> assessmentList,
    required List<InitiativeModel> initiativeList,
  }) {
    return PrimaryContainer(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          AppOptionWidget(
            title: AppString.assessments,
            iconPath: AppAsset.graph,
            cardColor: AppThemeData.black700,
            onTap: () {
              Navigator.pushNamed(context, Routes.assessmentDashboardScreen,
                      arguments: AssessmentDashboardRouteArgument(
                          assessmentList: assessmentList, implementationId: homeBloc.implementation?.id ?? ""))
                  .then((value) => homeBloc.add(HomeInitialEvent(uid: AppStorage.authUid ?? "", showLoader: false)));
            },
          ),
          _buildDivider(),
          AppOptionWidget(
            title: AppString.initiatives,
            iconPath: AppAsset.rocket,
            cardColor: AppThemeData.cyan,
            onTap: () async {
              Debug.log("Implementation ID -->> ${homeBloc.implementation!.id}");
              Navigator.pushNamed(context, Routes.initiativeScreen,
                      arguments: InitiativeRouteArgument(
                          initiativeList: initiativeList, implementationId: homeBloc.implementation?.id ?? ""))
                  .then((value) => homeBloc.add(HomeInitialEvent(uid: AppStorage.authUid ?? "", showLoader: false)));
            },
          ),
          _buildDivider(),
          AppOptionWidget(
            title: AppString.project,
            iconPath: AppAsset.project,
            cardColor: AppThemeData.yellow,
            onTap: () {
              // TODO: Navigation to projects
              Navigator.pushNamed(context, "Projects screen");
            },
          )
        ],
      ),
    );
  }

  Widget _buildDivider() {
    return Row(
      children: [
        SizedBox(width: 59.w),
        Expanded(
          child: Divider(
            thickness: 1.h,
            height: 0.h,
          ),
        ),
      ],
    );
  }
}
