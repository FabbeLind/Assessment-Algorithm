import 'dart:async';

import 'package:aitoolkit/features/assessment/model/assessment_model.dart';
import 'package:aitoolkit/features/assessment/repository/assessment_repo.dart';
import 'package:aitoolkit/features/home/repository/home_repo.dart';
import 'package:aitoolkit/features/implementation/model/implementation_model.dart';
import 'package:aitoolkit/features/initiatives/model/initiative_model.dart';
import 'package:aitoolkit/features/initiatives/repository/initiative_repo.dart';
import 'package:app_utils/app_utils.dart';
import 'package:bloc/bloc.dart';

part 'home_event.dart';
part 'home_state.dart';

class HomeBloc extends Bloc<HomeEvent, HomeState> {
  HomeBloc() : super(HomeInitial()) {
    on<HomeInitialEvent>(_homeInitialEvent);
  }

  final HomeRepo _homeRepo = HomeRepo.instance;
  final AssessmentRepo _assessmentRepo = AssessmentRepo.instance;
  final InitiativeRepo _initiativeRepo = InitiativeRepo.instance;
  ImplementationModel? implementation;

  Future<void> _homeInitialEvent(HomeInitialEvent event, Emitter<HomeState> emit) async {
    try {
      if (event.showLoader) emit(HomeLoadingState());
      Debug.log("User uid --->>> ${event.uid}");

      implementation = await _homeRepo.getImplementation(event.uid);
      if (implementation != null) {
        final response = await Future.wait([
          _initiativeRepo.getInitiative(implementationId: implementation!.id),
          _assessmentRepo.getAssessmentList(userId: event.uid, implementationId: implementation!.id),
        ]);
        emit(ImplementationExist(
          initiativeList: response[0] as List<InitiativeModel>,
          assessmentList: response[1] as List<AssessmentModel>,
        ));
      } else {
        emit(ImplementationNotExist());
      }
    } catch (e, st) {
      emit(HomeErrorState("Error while fetching implementation status"));
      Debug.log(e, st);
    }
  }
}
