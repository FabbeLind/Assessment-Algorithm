part of 'home_bloc.dart';

abstract class HomeEvent {}

class HomeInitialEvent extends HomeEvent {
  final String uid;
  final bool showLoader;

  HomeInitialEvent({
    required this.uid,
    this.showLoader = true,
  });
}
