part of 'home_bloc.dart';

abstract class HomeState {}

class HomeInitial extends HomeState {}

class HomeLoadingState extends HomeState {}

class ImplementationExist extends HomeState {
  final List<InitiativeModel> initiativeList;
  final List<AssessmentModel> assessmentList;

  ImplementationExist({
    required this.initiativeList,
    required this.assessmentList,
  });
}

class ImplementationNotExist extends HomeState {}

class HomeErrorState extends HomeState {
  final String message;

  HomeErrorState(this.message);
}
