part of 'profile_bloc.dart';

abstract class ProfileEvent {}
