import 'package:aitoolkit/features/app/bloc/app_bloc.dart';
import 'package:aitoolkit/widgets/app_image.dart';
import 'package:aitoolkit/widgets/get_started_widget.dart';
import 'package:aitoolkit/widgets/primary_container.dart';
import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../../routes/routes.dart';
import '../../../widgets/app_option_widget.dart';
import '../../../widgets/primary_home_app_bar.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  @override
  void initState() {
    super.initState();
    appBloc = context.read<AppBloc>();
  }

  late AppBloc appBloc;

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Align(
          alignment: Alignment.bottomRight,
          child: Image.asset(
            AppAsset.homeBgImage,
            height: context.height * 0.71,
            alignment: Alignment.bottomRight,
          ),
        ),
        BlocBuilder<AppBloc, AppState>(
          bloc: appBloc,
          builder: (context, state) {
            return Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const PrimaryHomeAppBar(title: AppString.myProfile),
                SizedBox(height: 15.h),
                _buildUserProfileImageAndName(
                  profileImage: appBloc.user?.profileImage,
                  name: appBloc.user?.name,
                  id: appBloc.user?.uid,
                  onLogoutTap: () {
                    appBloc.add(AppUserLogoutEvent());
                  },
                ),
                SizedBox(height: 12.h),
                _buildUserInfoWidget(
                  iconPath: AppAsset.phone,
                  title: "(999) 999 9999",
                  titleColor: AppThemeData.hintTextColor,
                ),
                SizedBox(height: 2.h),
                _buildUserInfoWidget(
                  iconPath: AppAsset.mail,
                  title: appBloc.user?.email,
                ),
                SizedBox(height: 30.h),
                _buildProfileOptionCard(context),
                SizedBox(height: 75.h),
                _buildGetStartedText(),
                SizedBox(height: 10.h),
                _buildInviteCollaboratorWidget(context),
              ],
            ).defaultPadding;
          },
        ),
      ],
    );
  }

  Widget _buildInviteCollaboratorWidget(BuildContext context) {
    return GetStartedCardWidget(
      // padding: EdgeInsets.fromLTRB(48.w, 43.h, 48.w, 43.h),
      image: AppAsset.inviteLogo,
      title: AppString.inviteCollaborators,
      description: AppString.inviteCollaboratorsDesc,
      buttonWidth: 242.w,
      onTap: () {
        /// TODO: Navigate to invite collaborator screen
        Navigator.pushNamed(context, "Invite collaborators screen");
      },
    );
  }

  Widget _buildGetStartedText() {
    return Align(
      alignment: Alignment.centerLeft,
      child: Text(
        AppString.getStarted,
        textAlign: TextAlign.left,
        style: AppTextStyle.title2,
      ),
    );
  }

  Widget _buildProfileOptionCard(BuildContext context) {
    return PrimaryContainer(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          AppOptionWidget(
            title: AppString.security,
            iconPath: AppAsset.security,
            cardColor: AppThemeData.black,
            onTap: () {
              Navigator.pushNamed(context, Routes.securityScreen);
            },
          ),
          _buildDivider(),
          AppOptionWidget(
            title: AppString.implementation,
            iconPath: AppAsset.rocket,
            cardColor: AppThemeData.cyan,
            onTap: () {
              Navigator.pushNamed(context, Routes.viewEditImplementationScreen);
            },
          ),
        ],
      ),
    );
  }

  Widget _buildDivider() {
    return Row(
      children: [
        SizedBox(width: 59.w),
        Expanded(
          child: Divider(
            thickness: 1.h,
            height: 0.h,
          ),
        ),
      ],
    );
  }

  Widget _buildUserInfoWidget({
    required String iconPath,
    String? title,
    Color? titleColor,
  }) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        SvgPicture.asset(
          iconPath,
        ),
        SizedBox(width: 9.w),
        Text(
          title ?? "N/A",
          style: TextStyle(
            fontSize: 10.sp,
            fontWeight: FontWeight.w500,
            color: titleColor,
          ),
        ),
      ],
    ).paddingOnly(left: 8.w);
  }

  Widget _buildUserProfileImageAndName({
    String? profileImage,
    String? name,
    String? id,
    required Function() onLogoutTap,
  }) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        profileImage != null
            ? AppImage(
                profileImage,
                fit: BoxFit.cover,
                size: 46.w,
                borderRadius: 50.r,
              )
            : Image.asset(
                AppAsset.profileImagePlaceholder,
                height: 46.w,
                width: 46.w,
                fit: BoxFit.cover,
              ),
        SizedBox(width: 12.w),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                name ?? "N/A",
                style: TextStyle(
                  fontSize: 14.sp,
                  fontWeight: FontWeight.w500,
                ),
              ),
              Text(
                "id : ${id ?? "N/A"}",
                style: TextStyle(
                  fontSize: 10.sp,
                  fontWeight: FontWeight.w500,
                  color: AppThemeData.hintTextColor,
                ),
              )
            ],
          ),
        ),
        GestureDetector(
          onTap: onLogoutTap,
          child: Container(
            color: Colors.transparent,
            child: Icon(
              Icons.logout_rounded,
              size: 25.h,
              color: AppThemeData.black,
            ),
          ),
        )
      ],
    );
  }
}
