import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class AppSnackBar {
  static void showError(BuildContext context, String message) {
    Widget toast = _buildToastWidget(
      text: message,
      toastColor: AppThemeData.red,
    );
    _showToast(context, toast);
  }

  static void showDefaultToast(BuildContext context, String message) {
    Widget toast = _buildToastWidget(text: message);
    _showToast(context, toast);
  }

  static void _showToast(BuildContext context, Widget widget) {
    double keyboardHeight = MediaQuery.of(context).viewInsets.bottom + 20;
    OverlayEntry overlayEntry = OverlayEntry(
      builder: (context) => Positioned(
        bottom: keyboardHeight > 70 ? keyboardHeight : 50,
        left: 0,
        right: 0,
        child: widget,
      ),
    );

    Overlay.of(context).insert(overlayEntry);

    Future.delayed(const Duration(seconds: 2), () {
      overlayEntry.remove();
    });
  }

  static Widget _buildToastWidget({
    required String text,
    Color? toastColor,
    TextStyle? textStyle,
  }) {
    return Align(
      alignment: Alignment.bottomCenter,
      child: Material(
        color: Colors.transparent,
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: 24.w, vertical: 12.h),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(8.r),
            color: toastColor ?? AppThemeData.black,
          ),
          child: Text(
            text,
            style: textStyle ?? AppTextStyle.defaultF14W5Secondary,
          ),
        ),
      ),
    );
  }
}
