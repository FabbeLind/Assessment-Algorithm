import 'package:aitoolkit/widgets/primary_text_field.dart';
import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class AppSearchTextField extends StatelessWidget {
  AppSearchTextField({
    super.key,
    required this.focusNode,
    this.searchBarHeight,
    this.textFieldOpacity,
    required this.controller,
    required this.onChange,
    this.border,
    this.iconColor,
  });

  final FocusNode focusNode;
  final TextEditingController controller;
  final Function(String) onChange;
  final double? searchBarHeight;
  final double? textFieldOpacity;
  final BoxBorder? border;
  final Color? iconColor;

  final _debouncer = Debouncer(const Duration(milliseconds: 500));

  @override
  Widget build(BuildContext context) {
    ColorScheme theme = Theme.of(context).colorScheme;
    return GestureDetector(
      onTap: () {
        if (!focusNode.hasFocus) {
          focusNode.requestFocus();
        }
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 0),
        height: searchBarHeight,
        padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 15.h),
        decoration: BoxDecoration(
          color: theme.primaryContainer,
          borderRadius: BorderRadius.circular(8.r),
          border: border,
          boxShadow: ((searchBarHeight ?? 0) > 20.0)
              ? [
                  BoxShadow(
                    color: AppThemeData.primaryShadowColor,
                    spreadRadius: 4,
                    blurRadius: 8,
                    offset: const Offset(0, 4),
                  ),
                ]
              : [],
        ),
        child: AnimatedOpacity(
          opacity: textFieldOpacity ?? 1.0,
          duration: const Duration(milliseconds: 100),
          child: Row(
            children: [
              Image.asset(
                AppAsset.search,
                height: 16.w,
                width: 16.w,
                color: iconColor ?? AppThemeData.primaryIconColor,
              ),
              SizedBox(width: 10.w),
              Expanded(
                child: PrimaryTextField(
                  controller: controller,
                  focusNode: focusNode,
                  maxLines: 1,
                  onChanged: (value) {
                    _debouncer.call(() {
                      onChange.call(value);
                    });
                  },
                  isDense: true,
                  contentPadding: EdgeInsets.zero,
                  border: InputBorder.none,
                  hintText: AppString.searchBarHintText,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
