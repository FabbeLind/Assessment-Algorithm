import 'package:aitoolkit/widgets/app_gradient_progress_bar.dart';
import 'package:aitoolkit/widgets/app_image.dart';
import 'package:aitoolkit/widgets/primary_container.dart';
import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class WorkInfoCard extends StatelessWidget {
  const WorkInfoCard({
    super.key,
    required this.progress,
    required this.title,
    required this.desc,
    this.profileImage,
    required this.workEndDate,
  });

  final double progress;
  final String title;
  final String desc;
  final String? profileImage;
  final DateTime workEndDate;

  @override
  Widget build(BuildContext context) {
    return PrimaryContainer(
      padding: EdgeInsets.only(bottom: 17.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          AppGradientProgressBar(progress: progress),
          SizedBox(height: 10.h),
          Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(title, style: AppTextStyle.headline),
              SizedBox(height: 18.h),
              Text(
                desc,
                textAlign: TextAlign.justify,
                style: AppTextStyle.body,
              ),
              SizedBox(height: 18.h),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  profileImage != null
                      ? AppImage(
                          profileImage!,
                          borderRadius: 50.r,
                          size: 32.w,
                        )
                      : Image.asset(
                          AppAsset.userProfileImagePlaceholder,
                          height: 32.w,
                          width: 32.w,
                        ),
                  _buildWorkEndDateWidget(workEndDate.appDefaultDateFormat)
                ],
              )
            ],
          ).paddingSymmetric(horizontal: 24.w)
        ],
      ),
    );
  }

  Widget _buildWorkEndDateWidget(String workEndDateFormatted) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: 8.w,
        vertical: 6.h,
      ),
      decoration: BoxDecoration(
        color: AppThemeData.grey200,
        borderRadius: BorderRadius.circular(8.r),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text(
            AppString.end,
            style: AppTextStyle.body,
          ),
          SizedBox(width: 12.w),
          Text(
            workEndDateFormatted,
            style: AppTextStyle.body,
          )
        ],
      ),
    );
  }
}
