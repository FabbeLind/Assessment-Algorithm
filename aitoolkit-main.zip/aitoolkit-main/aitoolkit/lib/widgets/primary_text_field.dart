import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';

class PrimaryTextField extends StatefulWidget {
  const PrimaryTextField({
    super.key,
    this.labelText,
    this.height,
    this.width,
    this.hintText,
    required this.controller,
    this.validator,
    this.obscureText = false,
    this.suffixIcon,
    this.prefixIcon,
    this.focusNode,
    this.border,
    this.keyboardType,
    this.maxLines,
    this.cursorColor,
    this.contentPadding,
    this.isDense,
    this.onChanged,
    this.style,
    this.constraints,
    this.readOnly = false,
    this.filled,
    this.fillColor,
    this.borderColor,
    this.suffixEnabled = false,
    this.textInputAction,
    this.autofocus = false,
  });

  final String? labelText;
  final bool obscureText;
  final TextEditingController controller;
  final String? Function(String?)? validator;
  final String? hintText;
  final TextStyle? style;
  final double? height;
  final double? width;
  final Color? cursorColor;
  final bool suffixEnabled;
  final Widget? suffixIcon;
  final Widget? prefixIcon;
  final FocusNode? focusNode;
  final TextInputType? keyboardType;
  final InputBorder? border;
  final int? maxLines;
  final EdgeInsetsGeometry? contentPadding;
  final bool? isDense;
  final void Function(String)? onChanged;
  final BoxConstraints? constraints;
  final bool readOnly;
  final TextInputAction? textInputAction;
  final bool? filled;
  final Color? fillColor;
  final Color? borderColor;
  final bool autofocus;

  @override
  State<PrimaryTextField> createState() => _PrimaryTextFieldState();
}

class _PrimaryTextFieldState extends State<PrimaryTextField> {
  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: widget.controller,
      cursorColor: widget.cursorColor ?? AppThemeData.primaryTextColor,
      focusNode: widget.focusNode,
      autofocus: widget.autofocus,
      style: widget.style ?? AppTextStyle.title3,
      validator: widget.validator,
      obscureText: widget.obscureText,
      keyboardType: widget.keyboardType,
      readOnly: widget.readOnly,
      maxLines: widget.maxLines,
      onChanged: widget.onChanged,
      textInputAction: widget.textInputAction,
      onTap: () => Utils.closePopUp(),
      decoration: InputDecoration(
        filled: widget.filled,
        fillColor: widget.fillColor,
        constraints: widget.constraints,
        labelStyle: AppTextStyle.body.copyWith(color: AppThemeData.grey700),
        labelText: widget.labelText,
        isDense: widget.isDense,
        hintText: widget.hintText,
        contentPadding: widget.contentPadding ??
            EdgeInsets.symmetric(
              horizontal: 16.h,
              vertical: 12.h,
            ),
        hintStyle: AppTextStyle.title3.copyWith(color: AppThemeData.grey700),
        suffixIcon: widget.suffixEnabled
            ? widget.suffixIcon ??
                (widget.readOnly
                    ? null
                    : GestureDetector(
                        onTap: () {
                          widget.controller.clear();
                          if (widget.focusNode != null) {
                            if (widget.focusNode!.hasFocus) {
                              widget.focusNode!.unfocus();
                            }
                          }
                        },
                        child: FittedBox(
                          fit: BoxFit.scaleDown,
                          child: SvgPicture.asset(
                            AppAsset.cross,
                            height: 24.w,
                            width: 24.w,
                          ).addTapAreaAll(10.w),
                        ),
                      ))
            : null,
        suffixIconColor: (widget.focusNode?.hasFocus ?? false) ? AppThemeData.white : AppThemeData.hintTextColor,
        border: border(widget.borderColor ?? AppThemeData.textFieldBorderColor),
        focusedBorder: border(widget.borderColor ?? AppThemeData.textFieldBorderColor),
        disabledBorder: border(widget.borderColor ?? AppThemeData.textFieldBorderColor),
        enabledBorder: border(widget.borderColor ?? AppThemeData.textFieldBorderColor),
        focusedErrorBorder: border(AppThemeData.red),
        errorBorder: border(AppThemeData.red),
      ),
    );
  }

  InputBorder border(Color color) =>
      widget.border ??
      OutlineInputBorder(
        borderSide: BorderSide(color: color, width: 2.w),
        borderRadius: BorderRadius.circular(8.r),
      );
}
