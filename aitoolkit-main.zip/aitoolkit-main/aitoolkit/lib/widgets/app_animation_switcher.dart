import 'package:flutter/material.dart';

enum AnimationDirection { vertical, horizontal }

class AppAnimationSwitcher extends StatefulWidget {
  const AppAnimationSwitcher({
    super.key,
    required this.child,
    this.animateIn = true,
    this.direction = AnimationDirection.horizontal,
    this.transitionBuilder,
    this.layoutBuilder = AnimatedSwitcher.defaultLayoutBuilder,
    this.switchInCurve = Curves.decelerate,
    this.switchOutCurve = Curves.linear,
    this.duration = const Duration(milliseconds: 400),
  });

  final bool animateIn;
  final AnimationDirection direction;
  final Duration duration;
  final Widget Function(Widget, Animation<double>)? transitionBuilder;
  final Widget Function(Widget?, List<Widget>) layoutBuilder;
  final Widget child;
  final Curve switchInCurve;
  final Curve switchOutCurve;

  @override
  State<AppAnimationSwitcher> createState() => _AppAnimationSwitcherState();
}

class _AppAnimationSwitcherState extends State<AppAnimationSwitcher> {
  Offset beginOffsetIn = const Offset(-1.0, 0.0);
  Offset beginOffsetOut = const Offset(1.0, 0.0);

  @override
  void initState() {
    if (widget.direction == AnimationDirection.vertical) {
      beginOffsetIn = const Offset(0.0, -1.0);
      beginOffsetOut = const Offset(0.0, 1.0);
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedSwitcher(
      duration: widget.duration,
      reverseDuration: Duration.zero,
      switchInCurve: widget.switchInCurve,
      switchOutCurve: widget.switchOutCurve,
      layoutBuilder: widget.layoutBuilder,
      transitionBuilder: widget.transitionBuilder ?? defaultTransitionBuilder,
      child: widget.child,
    );
  }

  Widget defaultTransitionBuilder(Widget child, Animation<double> animation) {
    final inAnimation = Tween<Offset>(begin: beginOffsetIn, end: const Offset(0.0, 0.0)).animate(animation);
    final outAnimation = Tween<Offset>(begin: beginOffsetOut, end: const Offset(0.0, 0.0)).animate(animation);

    if (widget.animateIn) {
      return ClipRect(
        child: SlideTransition(
          position: inAnimation,
          child: child,
        ),
      );
    } else {
      return ClipRect(
        child: SlideTransition(
          position: outAnimation,
          child: child,
        ),
      );
    }
  }
}
