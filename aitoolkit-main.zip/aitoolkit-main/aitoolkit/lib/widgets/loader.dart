import 'package:app_utils/app_utils.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

const double _kLoaderSize = 14.0;

class Loader {
  Loader._();

  static bool isLoading = false;

  static Widget circularProgressIndicator([double size = _kLoaderSize]) {
    return Stack(
      alignment: Alignment.center,
      children: [
        Container(color: AppThemeData.black.withOpacity(0.2)),
        Container(
          height: 70.h,
          width: 70.h,
          decoration: BoxDecoration(
            color: AppThemeData.white,
            borderRadius: BorderRadius.circular(15.r),
          ),
          child: Center(
            child: CupertinoActivityIndicator(
              radius: _kLoaderSize.h,
              color: AppThemeData.black,
            ),
          ),
        ),
      ],
    );
  }

  static void show(BuildContext context) {
    if (isLoading) return;
    isLoading = true;
    Navigator.push(context, _LoaderDialog());
  }

  static void dismiss(BuildContext context) {
    if (isLoading) {
      isLoading = false;
      Navigator.pop(context);
    }
  }
}

class _LoaderDialog extends RawDialogRoute {
  _LoaderDialog()
      : super(
          barrierColor: AppThemeData.black.withOpacity(0.2),
          pageBuilder: (context, animation, secondaryAnimation) {
            return PopScope(
              canPop: false,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    height: 70.h,
                    width: 70.h,
                    decoration: BoxDecoration(
                      color: AppThemeData.white,
                      borderRadius: BorderRadius.circular(15.r),
                    ),
                    child: Center(
                      child: CupertinoActivityIndicator(
                        radius: _kLoaderSize.h,
                        color: AppThemeData.black,
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
}
