import 'package:app_utils/app_theme.dart';
import 'package:app_utils/constants/constants.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';

class AppOptionWidget extends StatelessWidget {
  const AppOptionWidget({
    super.key,
    required this.title,
    this.cardColor = Colors.transparent,
    required this.iconPath,
    required this.onTap,
  });

  final String title;
  final Color cardColor;
  final String iconPath;
  final Function() onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        color: Colors.transparent,
        padding: EdgeInsets.fromLTRB(17.w, 12.h, 0.w, 12.h),
        child: Row(
          children: [
            _buildIconCard(
              cardColor: cardColor,
              iconPath: iconPath,
            ),
            SizedBox(width: 15.w),
            Expanded(
              child: Text(
                title,
                textAlign: TextAlign.left,
                style: AppTextStyle.title3,
              ),
            ),
            SvgPicture.asset(
              AppAsset.forwardArrow,
              height: 22.h,
              width: 22.h,
              colorFilter: ColorFilter.mode(
                AppThemeData.iconColor,
                BlendMode.srcIn,
              ),
            ),
            SizedBox(width: 9.w),
          ],
        ),
      ),
    );
  }

  Widget _buildIconCard({
    required Color cardColor,
    required String iconPath,
  }) {
    return Container(
      height: 27.h,
      width: 27.h,
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(2.r),
      ),
      padding: EdgeInsets.all(4.h),
      child: SvgPicture.asset(iconPath),
    );
  }
}
