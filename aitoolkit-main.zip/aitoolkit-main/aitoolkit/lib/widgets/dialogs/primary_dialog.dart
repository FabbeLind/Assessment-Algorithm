import 'package:app_utils/app_utils.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class PrimaryDialog extends StatefulWidget {
  const PrimaryDialog({
    super.key,
    required this.title,
    this.description,
    this.prefixText,
    this.prefixOnTap,
    required this.suffixText,
    required this.suffixOnTap,
  });

  final String title;
  final String? description;
  final String? prefixText;
  final Function()? prefixOnTap;
  final String suffixText;
  final Function() suffixOnTap;

  static Future<void> show(
    BuildContext context, {
    required String title,
    String? description,
    String? prefixText,
    Function()? prefixOnTap,
    required String suffixText,
    required Function() suffixOnTap,
  }) async {
    await showCupertinoDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return PrimaryDialog(
          title: title,
          description: description,
          prefixText: prefixText,
          prefixOnTap: prefixOnTap,
          suffixText: suffixText,
          suffixOnTap: suffixOnTap,
        );
      },
    );
  }

  @override
  State<PrimaryDialog> createState() => _PrimaryDialogState();
}

class _PrimaryDialogState extends State<PrimaryDialog> {
  @override
  Widget build(BuildContext context) {
    return Theme(
      data: ThemeData(
          brightness: Brightness.light,
          dialogTheme: const DialogTheme(
            iconColor: Color(0xff007AFF),
          )),
      child: CupertinoAlertDialog(
        title: Text(widget.title),
        content:
            (widget.description != null) ? Text(widget.description!) : null,
        actions: <Widget>[
          CupertinoDialogAction(
            textStyle: AppTextStyle.defaultF17W5Blue,
            onPressed: widget.prefixOnTap ??
                () {
                  Navigator.pop(context);
                },
            child: Text(widget.prefixText ?? AppString.cancel),
          ),
          CupertinoDialogAction(
            textStyle: AppTextStyle.defaultF17W5Blue,
            onPressed: widget.suffixOnTap,
            child: Text(widget.suffixText),
          ),
        ],
      ),
    );
  }
}
