import 'package:app_utils/app_utils.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class PrimaryTextFieldDialog extends StatefulWidget {
  const PrimaryTextFieldDialog({
    super.key,
    required this.title,
    this.description,
    this.controller,
    this.hintText,
    this.prefixText,
    this.prefixOnTap,
    required this.suffixText,
    required this.suffixOnTap,
  });

  final String title;
  final String? description;
  final TextEditingController? controller;
  final String? prefixText;
  final String? hintText;
  final Function()? prefixOnTap;
  final String suffixText;
  final Function() suffixOnTap;

  static Future<void> show(
    BuildContext context, {
    required String title,
    String? description,
    TextEditingController? controller,
    String? hintText,
    String? prefixText,
    Function()? prefixOnTap,
    required String suffixText,
    required Function() suffixOnTap,
  }) async {
    await showCupertinoDialog(
      context: context,
      barrierDismissible: true,
      builder: (context) {
        return PrimaryTextFieldDialog(
          title: title,
          description: description,
          controller: controller,
          hintText: hintText,
          prefixText: prefixText,
          prefixOnTap: prefixOnTap,
          suffixText: suffixText,
          suffixOnTap: suffixOnTap,
        );
      },
    );
  }

  @override
  State<PrimaryTextFieldDialog> createState() => _PrimaryTextFieldDialogState();
}

class _PrimaryTextFieldDialogState extends State<PrimaryTextFieldDialog> {
  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: AppThemeData.dialogBgColor,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15.r)),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          _verticalSpace(),
          Text(
            widget.title,
            textAlign: TextAlign.center,
            style: AppTextStyle.defaultDialogTitle,
          ).paddingSymmetric(horizontal: 16.w),
          if (widget.description != null) ...[
            SizedBox(height: 5.h),
            Text(
              widget.description ?? "",
              textAlign: TextAlign.center,
              style: AppTextStyle.defaultDialogContent,
            ).paddingSymmetric(horizontal: 16.w),
          ],
          _verticalSpace(),
          CupertinoTextField(
            controller: widget.controller,
            padding: EdgeInsets.symmetric(horizontal: 24.w, vertical: 15.h),
            decoration: const BoxDecoration(
              borderRadius: BorderRadius.zero,
              color: AppThemeData.white,
            ),
            placeholder: widget.hintText ?? "",
            style: AppTextStyle.title3Options,
            placeholderStyle: AppTextStyle.title3Options,
          ),
          Row(
            children: [
              Flexible(
                child: CupertinoDialogAction(
                  textStyle: AppTextStyle.defaultF17W5Blue,
                  onPressed: widget.prefixOnTap ??
                      () {
                        Navigator.pop(context);
                      },
                  child: Text(widget.prefixText ?? AppString.cancel),
                ),
              ),
              _buildVerticalDivider(),
              Flexible(
                child: CupertinoDialogAction(
                  textStyle: AppTextStyle.defaultF17W5Blue,
                  onPressed: widget.suffixOnTap,
                  child: Text(widget.suffixText),
                ),
              ),
            ],
          )
        ],
      ),
    );
  }

  Widget _buildVerticalDivider() {
    return Container(
      height: 45,
      width: (0.5).w,
      color: AppThemeData.dividerColor,
    );
  }

  Widget _verticalSpace() => SizedBox(height: 16.h);
}
