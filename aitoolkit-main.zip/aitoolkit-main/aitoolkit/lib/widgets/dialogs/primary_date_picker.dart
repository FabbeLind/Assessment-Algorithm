import 'package:app_utils/app_utils.dart';
import 'package:flutter/cupertino.dart';

class PrimaryDatePickerBottomSheet extends StatefulWidget {
  const PrimaryDatePickerBottomSheet({
    super.key,
    this.initialDateTime,
    required this.onDateTimeChanged,
  });

  final DateTime? initialDateTime;
  final void Function(DateTime) onDateTimeChanged;

  static Future<void> show(
    BuildContext context, {
    DateTime? initialDateTime,
    required void Function(DateTime) onDateTimeChanged,
  }) async {
    await showCupertinoModalPopup(
      context: context,
      barrierDismissible: true,
      builder: (context) => PrimaryDatePickerBottomSheet(
        initialDateTime: initialDateTime,
        onDateTimeChanged: onDateTimeChanged,
      ),
    );
  }

  @override
  State<PrimaryDatePickerBottomSheet> createState() => _PrimaryDatePickerBottomSheetState();
}

class _PrimaryDatePickerBottomSheetState extends State<PrimaryDatePickerBottomSheet> {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: context.height * 0.35,
      padding: const EdgeInsets.only(top: 6.0),
      margin: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
      ),
      color: CupertinoColors.systemBackground.resolveFrom(context),
      child: SafeArea(
        top: false,
        child: CupertinoDatePicker(
          mode: CupertinoDatePickerMode.date,
          initialDateTime: widget.initialDateTime ?? DateTime.now(),
          onDateTimeChanged: widget.onDateTimeChanged,
          use24hFormat: true,
        ),
      ),
    );
  }
}
