import 'package:app_utils/app_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class PrimaryContainer extends StatelessWidget {
  const PrimaryContainer({
    super.key,
    this.height,
    this.width,
    required this.child,
    this.padding,
    this.radius,
    this.borderRadius,
    this.gradient,
    this.constraints,
    this.margin,
    this.color,
    this.boxShadow,
    this.border,
  });

  final double? height;
  final double? width;
  final Color? color;
  final List<BoxShadow>? boxShadow;
  final double? radius;
  final BorderRadiusGeometry? borderRadius;
  final Gradient? gradient;
  final BoxBorder? border;
  final EdgeInsetsGeometry? padding;
  final BoxConstraints? constraints;
  final EdgeInsetsGeometry? margin;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    var theme = Theme.of(context).colorScheme;
    return Container(
      height: height,
      width: width,
      padding: padding,
      margin: margin,
      constraints: constraints,
      decoration: BoxDecoration(
        color: gradient != null ? null : (color ?? theme.primaryContainer),
        gradient: gradient,
        borderRadius: borderRadius ?? BorderRadius.circular(radius ?? 8.r),
        border: border,
        boxShadow: boxShadow ??
            [
              BoxShadow(
                color: AppThemeData.primaryShadowColor,
                spreadRadius: 4,
                blurRadius: 8,
                offset: const Offset(0, 4),
              ),
            ],
      ),
      child: child,
    );
  }
}
