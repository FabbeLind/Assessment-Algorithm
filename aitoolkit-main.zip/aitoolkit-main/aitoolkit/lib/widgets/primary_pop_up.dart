import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class PrimaryPopUp extends StatefulWidget {
  const PrimaryPopUp({
    super.key,
    required this.child,
    required this.icon,
  });

  final Widget child;
  final Widget icon;

  @override
  State<PrimaryPopUp> createState() => _PrimaryPopUpState();
}

class _PrimaryPopUpState extends State<PrimaryPopUp> {
  final LayerLink _layerLink = LayerLink();

  void _showPopup() {
    overlayEntry = _createOverlayEntry();
    Overlay.of(context).insert(overlayEntry!);
  }

  void _hidePopup() {
    overlayEntry?.remove();
    overlayEntry = null;
  }

  OverlayEntry _createOverlayEntry() {
    RenderBox renderBox = context.findRenderObject() as RenderBox;
    var size = renderBox.size;

    return OverlayEntry(
      builder: (context) => Positioned(
        width: 250.w,
        child: CompositedTransformFollower(
          link: _layerLink,
          showWhenUnlinked: false,
          offset: Offset(-220.w, size.height + 10.h),
          child: Material(
            color: Colors.transparent,
            child: widget.child,
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return CompositedTransformTarget(
      link: _layerLink,
      child: GestureDetector(
        onTap: () {
          if (overlayEntry != null) {
            _hidePopup();
          }
          if (overlayEntry == null) {
            _showPopup();
          } else {
            _hidePopup();
          }
        },
        child: widget.icon,
      ),
    );
  }
}
