import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';

import 'primary_container.dart';

class PrimaryAnimatedContainer extends StatefulWidget {
  const PrimaryAnimatedContainer({
    super.key,
    required this.title,
    required this.child,
    this.padding = EdgeInsets.zero,
    this.margin = EdgeInsets.zero,
    this.height,
    this.onExpansionChange,
    this.playAnimation = false,
    this.onAnimationChange,
  });

  final String title;
  final Widget child;
  final EdgeInsetsGeometry padding;
  final EdgeInsetsGeometry margin;
  final double? height;
  final bool playAnimation;
  final Function(bool value)? onExpansionChange;
  final Function(bool value)? onAnimationChange;

  @override
  State<PrimaryAnimatedContainer> createState() => _PrimaryAnimatedContainerState();
}

class _PrimaryAnimatedContainerState extends State<PrimaryAnimatedContainer> with SingleTickerProviderStateMixin {
  bool _isExpanded = true;

  void toggleExpansion() {
    setState(() {
      _isExpanded = !_isExpanded;
    });
  }

  late final AnimationController _controller;
  late Animation<Offset> _offsetAnimation;
  Offset beginOffset = Offset.zero;

  @override
  void initState() {
    _controller = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    _controller.addStatusListener((status) {
      if (widget.playAnimation && status == AnimationStatus.completed) {
        if (widget.onAnimationChange != null) {
          widget.onAnimationChange!.call(false);
        }
      }
    });
    if (widget.playAnimation) {
      beginOffset = const Offset(1.5, 0.0);
      _offsetAnimation = Tween<Offset>(
        begin: beginOffset,
        end: Offset.zero,
      ).animate(CurvedAnimation(
        parent: _controller,
        curve: Curves.linear,
      ));
      _controller.forward();
    } else {
      _offsetAnimation = Tween<Offset>(
        begin: beginOffset,
        end: Offset.zero,
      ).animate(CurvedAnimation(
        parent: _controller,
        curve: Curves.linear,
      ));
    }
    super.initState();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var theme = Theme.of(context).colorScheme;
    return SlideTransition(
      position: _offsetAnimation,
      child: PrimaryContainer(
        height: widget.height,
        margin: widget.margin,
        child: AnimatedSize(
          duration: const Duration(milliseconds: 300),
          reverseDuration: const Duration(milliseconds: 300),
          alignment: Alignment.topCenter,
          curve: Curves.ease,
          child: Column(
            children: [
              GestureDetector(
                onTap: () {
                  toggleExpansion();
                  widget.onExpansionChange?.call(_isExpanded);
                },
                child: Container(
                  width: double.infinity,
                  padding: EdgeInsets.symmetric(vertical: 8.h, horizontal: 24.w),
                  decoration: BoxDecoration(
                    color: theme.primary,
                    borderRadius: BorderRadius.vertical(
                      top: Radius.circular(8.r),
                      bottom: _isExpanded ? Radius.zero : Radius.circular(8.r),
                    ),
                  ),
                  child: Row(
                    children: [
                      SizedBox(width: 15.w),
                      Expanded(
                        child: Text(
                          widget.title,
                          textAlign: TextAlign.center,
                          style: AppTextStyle.title3.copyWith(color: AppThemeData.secondaryTextColor),
                        ),
                      ),
                      AnimatedRotation(
                        duration: const Duration(milliseconds: 300),
                        turns: _isExpanded ? 0.25 : 0,
                        child: SvgPicture.asset(
                          AppAsset.chevron,
                          height: 14.w,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              _isExpanded
                  ? Padding(
                      padding: widget.padding,
                      child: widget.child,
                    )
                  : const SizedBox.shrink(),
            ],
          ),
        ),
      ),
    );
  }
}
