import 'package:app_utils/app_utils.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';

class PrimaryButton extends StatelessWidget {
  final String label;
  final Function() onPressed;
  final double? height;
  final double? width;
  final double? fontSize;
  final FontWeight? fontWeight;
  final double? borderRadius;
  final Color? color;
  final Color? labelColor;
  final String? icon;
  final double? iconSize;
  final Color? iconColor;
  final double? iconSpace;
  final TextStyle? labelStyle;
  final EdgeInsetsGeometry? padding;
  final bool enableShadow;
  final bool isLoading;
  final double? loaderRadius;
  final BoxBorder? border;
  final bool isStyleOutlined;

  const PrimaryButton({
    super.key,
    this.height,
    this.width,
    this.borderRadius,
    required this.label,
    required this.onPressed,
    this.color,
    this.labelColor,
    this.icon,
    this.labelStyle,
    this.padding,
    this.fontSize,
    this.fontWeight,
    this.iconSize,
    this.iconColor,
    this.iconSpace,
    this.enableShadow = false,
    this.isLoading = false,
    this.loaderRadius,
    this.border,
    this.isStyleOutlined = false,
  });

  const PrimaryButton.icon({
    super.key,
    required this.label,
    required this.icon,
    required this.onPressed,
    this.height,
    this.width,
    this.borderRadius,
    this.color,
    this.labelColor,
    this.labelStyle,
    this.padding,
    this.fontSize,
    this.fontWeight,
    this.iconSize,
    this.iconColor,
    this.iconSpace,
    this.enableShadow = true,
    this.isLoading = false,
    this.loaderRadius,
    this.border,
    this.isStyleOutlined = false,
  });

  const PrimaryButton.outlined({
    super.key,
    required this.label,
    required this.onPressed,
    this.height,
    this.width,
    this.borderRadius,
    this.color,
    this.labelColor,
    this.labelStyle,
    this.padding,
    this.fontSize,
    this.fontWeight,
    this.iconSize,
    this.iconColor,
    this.iconSpace,
    this.icon,
    this.enableShadow = false,
    this.isLoading = false,
    this.loaderRadius,
    this.border,
    this.isStyleOutlined = true,
  });

  @override
  Widget build(BuildContext context) {
    var theme = Theme.of(context).colorScheme;
    Color textLabelColor = labelColor ?? (isStyleOutlined ? theme.primary : theme.secondary);
    Color buttonColor = color ?? (isStyleOutlined ? theme.secondary : theme.primary);
    Color borderColor = isStyleOutlined ? textLabelColor : buttonColor;
    Color loaderColor = isStyleOutlined ? theme.primary : theme.secondary;
    Widget labelWidget = Text(
      label,
      style: labelStyle ??
          AppTextStyle.headline.copyWith(
            fontSize: fontSize ?? 16.sp,
            fontWeight: fontWeight ?? FontWeight.w600,
            color: textLabelColor,
          ),
    );
    return GestureDetector(
      onTap: isLoading ? null : onPressed,
      child: Container(
        height: height,
        width: width ?? double.infinity,
        padding: padding ?? EdgeInsets.symmetric(vertical: 12.h),
        decoration: BoxDecoration(
          color: buttonColor,
          borderRadius: BorderRadius.circular(borderRadius ?? 8.r),
          border: border ?? Border.all(color: borderColor, width: 1.w),
          boxShadow: enableShadow
              ? [
                  BoxShadow(
                    blurRadius: 4,
                    offset: const Offset(0, 4),
                    color: AppThemeData.black.withOpacity(0.25),
                  ),
                ]
              : null,
        ),
        child: isLoading
            ? CupertinoActivityIndicator(
                color: loaderColor,
                radius: loaderRadius ?? 8.w,
              )
            : Row(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (icon != null) ...[
                    icon!.endsWith(".svg")
                        ? FittedBox(
                            fit: BoxFit.scaleDown,
                            child: SvgPicture.asset(
                              icon!,
                              height: iconSize ?? 26.h,
                              width: iconSize ?? 26.h,
                              colorFilter: iconColor != null
                                  ? ColorFilter.mode(iconColor ?? AppThemeData.black, BlendMode.srcIn)
                                  : null,
                            ),
                          )
                        : Image.asset(
                            icon!,
                            height: iconSize ?? 26.h,
                            width: iconSize ?? 26.h,
                            color: iconColor ?? AppThemeData.black,
                          ),
                    SizedBox(width: iconSpace ?? 8.w),
                  ],
                  labelWidget,
                ],
              ),
      ),
    );
  }
}
