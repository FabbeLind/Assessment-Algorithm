import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';

class AppPopUpItem extends StatelessWidget {
  const AppPopUpItem({super.key, required this.title, required this.onTap, this.icon, this.iconSize});

  final String title;
  final String? icon;
  final double? iconSize;
  final Function() onTap;

  @override
  Widget build(BuildContext context) {
    Widget titleText = Text(
      title,
      textAlign: TextAlign.left,
      style: AppTextStyle.defaultF16W4Primary,
    );
    double iconScale = iconSize ?? 16.w;
    return GestureDetector(
      onTap: popUpCallback(onTap),
      child: Container(
        color: Colors.transparent,
        padding: EdgeInsets.all(10.w),
        child: (icon != null)
            ? Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  titleText,
                  SvgPicture.asset(
                    icon!,
                    height: iconScale,
                    width: iconScale,
                  ),
                ],
              )
            : Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [titleText],
              ),
      ),
    );
  }
}

VoidCallback popUpCallback(VoidCallback callback) {
  return () {
    Utils.closePopUp();
    callback();
  };
}
