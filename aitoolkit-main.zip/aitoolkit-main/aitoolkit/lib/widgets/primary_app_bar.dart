import 'package:aitoolkit/widgets/primary_text_field.dart';
import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class PrimaryAppBar extends StatefulWidget {
  const PrimaryAppBar({
    super.key,
    required this.title,
    this.appBarActive = false,
    this.status = AppBarStatus.none,
    required this.prefixIcon,
    required this.suffixIcon,
    this.controller,
    this.labelText,
    this.iconAndLabelColor,
    this.moreSuffixIcon,
    this.showMoreOption = false,
  });

  final String title;
  final bool appBarActive;
  final AppBarStatus status;
  final ({Widget widget, Function() onTap}) prefixIcon;
  final ({Widget widget, Function() onTap}) suffixIcon;
  final Widget? moreSuffixIcon;
  final TextEditingController? controller;
  final String? labelText;
  final Color? iconAndLabelColor;
  final bool showMoreOption;

  @override
  State<PrimaryAppBar> createState() => _PrimaryAppBarState();
}

class _PrimaryAppBarState extends State<PrimaryAppBar> with TickerProviderStateMixin {
  FocusNode focusNode = FocusNode();

  late AnimationController _iconController;
  late Animation<double> _opacityAnimation;
  late Animation<double> _rotationAnimation;

  @override
  void initState() {
    _iconController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
      reverseDuration: const Duration(milliseconds: 500),
    )..forward();
    _rotationAnimation = Tween<double>(
      begin: 0.5,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _iconController,
      curve: Curves.ease,
    ));
    _opacityAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _iconController,
      curve: Curves.ease,
    ));
    super.initState();
  }

  @override
  void didUpdateWidget(covariant PrimaryAppBar oldWidget) {
    if (widget.status != oldWidget.status) {
      _iconController.reset();
      _iconController.forward();
    }
    super.didUpdateWidget(oldWidget);
  }

  @override
  Widget build(BuildContext context) {
    bool readOnly = widget.status == AppBarStatus.view;
    Color iconAndTextColor =
        widget.iconAndLabelColor ?? (widget.appBarActive ? AppThemeData.black : AppThemeData.white);
    bool isActive = (widget.status != AppBarStatus.none);
    return Container(
      width: context.width,
      padding: EdgeInsets.fromLTRB(5.w, 5.h, 5.w, 10.h),
      decoration: BoxDecoration(
        color: widget.appBarActive ? AppThemeData.white : Colors.transparent,
        borderRadius: isActive
            ? BorderRadius.only(
                bottomLeft: Radius.circular(12.r),
                bottomRight: Radius.circular(12.r),
              )
            : null,
        boxShadow: isActive
            ? [
                BoxShadow(
                  color: AppThemeData.secondaryShadowColor,
                  blurRadius: 10,
                  spreadRadius: 0,
                  offset: const Offset(0, 4),
                )
              ]
            : null,
      ),
      child: AnimatedSize(
        duration: const Duration(milliseconds: 500),
        reverseDuration: const Duration(milliseconds: 500),
        alignment: Alignment.topCenter,
        curve: Curves.ease,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              mainAxisSize: MainAxisSize.max,
              children: [
                Builder(
                  builder: (_) {
                    Widget prefixIcon = GestureDetector(
                      onTap: widget.prefixIcon.onTap.call,
                      child: rotateWidget(child: widget.prefixIcon.widget).addTapAreaAll(10.w),
                    );
                    return (widget.moreSuffixIcon != null && widget.showMoreOption)
                        ? Row(
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              prefixIcon,
                              Opacity(
                                opacity: 0,
                                child: widget.moreSuffixIcon!,
                              ),
                            ],
                          )
                        : prefixIcon;
                  },
                ),
                Expanded(
                  child: ScaleTransition(
                    scale: _opacityAnimation,
                    child: Text(
                      widget.title,
                      textAlign: TextAlign.center,
                      style: AppTextStyle.headline.copyWith(color: iconAndTextColor),
                    ),
                  ),
                ),
                Builder(
                  builder: (_) {
                    Widget suffixIcon = GestureDetector(
                      onTap: widget.suffixIcon.onTap.call,
                      child: rotateWidget(child: widget.suffixIcon.widget.addTapAreaAll(10.w)),
                    );
                    return (widget.moreSuffixIcon != null && widget.showMoreOption)
                        ? Row(
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              suffixIcon,
                              rotateWidget(child: widget.moreSuffixIcon!),
                            ],
                          )
                        : suffixIcon;
                  },
                ),
              ],
            ).paddingOnly(left: 25.w, right: 15.w),
            if (isActive) ...[
              SizedBox(height: 16.h),
              PrimaryTextField(
                controller: widget.controller ?? TextEditingController(),
                labelText: widget.labelText ?? AppString.title,
                focusNode: focusNode,
                maxLines: 1,
                readOnly: readOnly,
                style: AppTextStyle.defaultF12W5Primary,
                constraints: BoxConstraints(minHeight: 47.h),
                suffixEnabled: true,
              ).paddingSymmetric(horizontal: 10.w),
              SizedBox(height: 6.h),
            ],
          ],
        ),
      ),
    );
  }

  Widget rotateWidget({required Widget child}) {
    return RotationTransition(
      turns: _rotationAnimation,
      child: child,
    );
  }
}
