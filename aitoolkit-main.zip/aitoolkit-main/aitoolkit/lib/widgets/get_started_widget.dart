import 'package:aitoolkit/widgets/app_image.dart';
import 'package:aitoolkit/widgets/primary_container.dart';
import 'package:app_utils/app_utils.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class GetStartedCardWidget extends StatelessWidget {
  const GetStartedCardWidget({
    super.key,
    this.image,
    this.imageSize,
    required this.title,
    required this.description,
    this.buttonWidth,
    this.width,
    this.padding,
    required this.onTap,
  });

  final String? image;
  final double? imageSize;
  final String title;
  final String description;
  final double? buttonWidth;
  final double? width;
  final EdgeInsetsGeometry? padding;
  final Function() onTap;

  @override
  Widget build(BuildContext context) {
    /// TODO: Adjust description text overflow
    return GestureDetector(
      onTap: onTap,
      child: PrimaryContainer(
        padding: padding ?? EdgeInsets.fromLTRB(24.w, 43.h, 24.w, 0.h),
        width: width ?? double.infinity,
        constraints: BoxConstraints(maxHeight: 250.h),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                image != null
                    ? AppImage(
                        image!,
                        size: imageSize ?? 50.h,
                      )
                    : Image.asset(
                        AppAsset.aiLogo,
                        height: 50.h,
                        width: 50.h,
                        color: AppThemeData.lightGrey,
                      ),
                SizedBox(height: 26.h),
                Text(
                  title,
                  textAlign: TextAlign.center,
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                  style: AppTextStyle.headline,
                ),
                SizedBox(height: 20.h),
              ],
            ),
            Expanded(
              child: SingleChildScrollView(
                child: Text(
                  description,
                  textAlign: TextAlign.justify,
                  maxLines: 4,
                  overflow: TextOverflow.ellipsis,
                  style: AppTextStyle.body,
                ),
              ),
            ),
            SizedBox(height: 30.h),
          ],
        ),
      ),
    );
  }
}
