import 'package:app_utils/app_utils.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:shimmer/shimmer.dart';

class AppImage extends StatelessWidget {
  const AppImage(
    this.image, {
    super.key,
    required this.size,
    this.fit,
    this.color,
    this.borderRadius,
  });

  final String image;
  final double size;
  final BoxFit? fit;
  final Color? color;
  final double? borderRadius;

  @override
  Widget build(BuildContext context) {
    /// TODO: Use app image in all over application & use named constructor
    return ClipRRect(
      borderRadius: BorderRadius.circular(borderRadius ?? 8.r),
      child: (image.isImageNetwork)
          ? CachedNetworkImage(
              imageUrl: image,
              height: size,
              width: size,
              fit: fit ?? BoxFit.cover,
              alignment: Alignment.center,
              color: color,
              imageBuilder: (context, imageUrl) {
                return Container(
                  height: size,
                  width: size,
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: imageUrl,
                      filterQuality: FilterQuality.high,
                      fit: BoxFit.cover,
                    ),
                  ),
                );
              },
              errorWidget: (context, url, error) => _buildErrorWidget(),
              placeholder: (context, url) => _buildErrorWidget(),
            )
          : (image.isImageSvg)
              ? SvgPicture.asset(
                  image,
                  height: size,
                  width: size,
                  alignment: Alignment.center,
                  colorFilter: ColorFilter.mode(color ?? AppThemeData.darkTeal, BlendMode.srcIn),
                  placeholderBuilder: (context) => _buildErrorWidget(),
                )
              : Image.asset(
                  image,
                  height: size,
                  width: size,
                  fit: fit ?? BoxFit.cover,
                  alignment: Alignment.center,
                  color: color,
                  errorBuilder: (context, error, stackTrace) => _buildErrorWidget(),
                ),
    );
  }

  Widget _buildErrorWidget() {
    return Shimmer.fromColors(
      baseColor: Colors.grey.shade200,
      highlightColor: Colors.grey.shade100,
      child: Container(
        height: size,
        width: size,
        color: AppThemeData.white,
      ),
    );
  }
}
