import 'package:app_utils/app_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../../widgets/primary_text_field.dart';

class AppUnderlineTextField extends StatefulWidget {
  const AppUnderlineTextField({
    super.key,
    required this.controller,
    required this.hintText,
    this.onChanged,
    this.pointWidget,
    this.textInputAction = TextInputAction.next,
    this.readOnly = false,
    this.crossAxisAlignment = CrossAxisAlignment.start,
    this.suffixWidget,
  });

  final TextEditingController controller;
  final String? hintText;
  final Function(String)? onChanged;
  final Widget? pointWidget;
  final bool readOnly;
  final CrossAxisAlignment crossAxisAlignment;
  final TextInputAction textInputAction;
  final Widget? suffixWidget;

  @override
  State<AppUnderlineTextField> createState() =>
      _AppUnderlineTextFieldState();
}

class _AppUnderlineTextFieldState
    extends State<AppUnderlineTextField> {
  late FocusNode focusNode;

  @override
  void initState() {
    focusNode = FocusNode();
    super.initState();
  }

  @override
  void dispose() {
    focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          crossAxisAlignment: widget.crossAxisAlignment,
          children: [
            Expanded(
              child: PrimaryTextField(
                controller: widget.controller,
                focusNode: focusNode,
                isDense: true,
                onChanged: widget.onChanged,
                textInputAction: widget.textInputAction,
                readOnly: widget.readOnly,
                contentPadding:
                EdgeInsets.symmetric(vertical: 12.h, horizontal: 20.w),
                border: InputBorder.none,
                hintText: widget.hintText,
              ),
            ),
            widget.suffixWidget ?? _buildSuffixIcon(),
          ],
        ),
        Divider(
            height: 0.h,
            thickness: (0.5).h,
            color: AppThemeData.secondaryDividerColor)
            .defaultPadding,
      ],
    );
  }

  Widget _buildSuffixIcon() {
    return GestureDetector(
      onTap: () {
        widget.controller.clear();
        if (focusNode.hasFocus) {
          focusNode.unfocus();
        }
      },
      child: SvgPicture.asset(
        AppAsset.crossActive,
        height: 18.w,
        width: 18.w,
      ).addTapAreaOnly(top: 12.h, right: 20.w, bottom: 12.h, left: 5.w),
    );
  }
}
