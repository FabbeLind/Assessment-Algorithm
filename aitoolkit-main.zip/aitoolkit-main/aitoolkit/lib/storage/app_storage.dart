import 'package:shared_preferences/shared_preferences.dart';

part 'storage_key.dart';

class AppStorage {
  static final AppStorage _instance = AppStorage._internal();

  factory AppStorage() {
    return _instance;
  }

  AppStorage._internal();

  static late SharedPreferences _prefs;

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  static Future<void> setAuthUid(String uid) async {
    await _prefs.setString(_authUid, uid);
  }

  static String? get authUid => _prefs.getString(_authUid);

  static Future<void> clear() async {
    await _prefs.clear();
  }
}
