import 'package:aitoolkit/features/app/observer/app_bloc_observer.dart';
import 'package:aitoolkit/features/app/screens/app.dart';
import 'package:aitoolkit/storage/app_storage.dart';
import 'package:app_services/firebase/firebase_firestore_service.dart';
import 'package:app_services/google_sheet_service.dart';
import 'package:app_utils/app_utils.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  Debug.enabled = true;
  await Firebase.initializeApp();
  String credential = await rootBundle.loadString('assets/credentials/sheet_service_credential.json');
  await SheetService.init(credential);
  await AppStorage().init();
  FirebaseFirestoreService.init();
  Bloc.observer = AppBlocObserver();
  await dotenv.load(fileName: ".env", isOptional: true);
  runApp(const App());

  ErrorWidget.builder = (details) {
    return Scaffold(
      body: Padding(
        padding: EdgeInsets.all(24.h),
        child: Center(
          child: Text(
            textAlign: TextAlign.center,
            details.exception.toString(),
            style: TextStyle(
              fontSize: 16.sp,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ),
    );
  };
}
