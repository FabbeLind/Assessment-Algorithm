part of 'extensions.dart';

extension DateTimeEx on DateTime {
  String get appDefaultDateFormat => DateFormat('dd MMM yy').format(this).toUpperCase();

  DateTime get startTimeOfDate => DateTime(year, month, day, 0, 0, 0);

  DateTime get endTimeOfDate => DateTime(year, month, day, 23, 59, 59);
}
