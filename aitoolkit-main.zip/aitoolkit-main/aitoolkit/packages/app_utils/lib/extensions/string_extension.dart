part of 'extensions.dart';

extension StringExtension on String {
  String addEllipse([int length = 2]) {
    String ellipseText = "";
    for (int i = 0; i < length; i++) {
      ellipseText = "$ellipseText.";
    }
    return "$this $ellipseText";
  }

  bool get isNotBlank => trim().isNotEmpty;

  String? get getGoogleSheetId {
    final RegExp regex = RegExp(r'/d/([a-zA-Z0-9-_]+)');
    final Match? match = regex.firstMatch(this);
    if (match != null && match.groupCount >= 1) {
      return match.group(1)!;
    }
    return null;
  }

  String? get getWorkSheetId {
    final RegExp regex = RegExp(r'gid=([0-9]+)');
    final Match? match = regex.firstMatch(this);
    if (match != null && match.groupCount >= 1) {
      return match.group(1)!;
    }
    return null;
  }

}

extension NullableString on String? {
  bool get isNotEmptyAndNull => this != null && (this?.isNotEmpty ?? false);

  bool get isNullOrEmpty => this == null || (this?.isEmpty ?? false);

  bool get isImageNetwork => (this!.contains("https") || this!.contains("http"));

  bool get isImageSvg => (this!.endsWith(".svg"));



}
