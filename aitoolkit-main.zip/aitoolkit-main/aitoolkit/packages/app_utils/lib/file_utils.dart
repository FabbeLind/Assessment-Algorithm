import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';

import 'app_utils.dart';

class FileUtil {
  static final _instance = FileUtil._internal();

  factory FileUtil() => _instance;

  static late ImagePicker _picker;

  FileUtil._internal() {
    _picker = ImagePicker();
  }

  Future<String?> pickImage([ImageSource source = ImageSource.gallery]) async {
    try {
      bool isGranted = await Permission.photos.isGranted;
      if (isGranted) {
        XFile? pickedFile = await _picker.pickImage(source: source);
        if (pickedFile != null) {
          return pickedFile.path;
        }
      } else {
        await Permission.photos.request();
      }
      return null;
    } catch (e, st) {
      Debug.log("Error occurred while picking image -> $e", st);
      rethrow;
    }
  }
}
