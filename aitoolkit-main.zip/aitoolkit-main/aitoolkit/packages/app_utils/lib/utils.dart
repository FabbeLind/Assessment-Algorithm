import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';

import 'constants/constants.dart';

class Utils {
  Utils._();

  static const _uuid = Uuid();

  static void hideKeyboardInApp(BuildContext context) {
    var currentFocus = FocusScope.of(context);
    if (!currentFocus.hasPrimaryFocus && currentFocus.focusedChild != null) {
      FocusManager.instance.primaryFocus!.unfocus();
    }
  }

  static double getProgressBetweenDateTime(DateTime startDate, DateTime endDate) {
    final now = DateTime.now();
    final totalDuration = endDate.difference(startDate).inMilliseconds;
    if (now.isAfter(endDate)) {
      return 1.0;
    } else if (now.isBefore(startDate)) {
      return 0.0;
    } else {
      final elapsed = now.difference(startDate).inMilliseconds;
      final newProgress = elapsed / totalDuration;
      return newProgress > 1.0 ? 1.0 : newProgress;
    }
  }

  static void closePopUp() {
    if (overlayEntry != null) {
      overlayEntry?.remove();
      overlayEntry = null;
    }
  }

  static String generateUid() {
    return _uuid.v1();
  }
}
