part of 'app_enums.dart';

enum QuestionActionType { next, previous }
