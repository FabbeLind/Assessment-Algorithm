part of 'app_enums.dart';

enum InitiativeOptionEnum {
  goals(AppString.goals, AppAsset.goal, SectionType.list),
  description(AppString.description, AppAsset.description, SectionType.text),
  vision(AppString.vision, AppAsset.vision, SectionType.text),
  objectives(AppString.objectives, AppAsset.objective, SectionType.list);

  final String title;
  final String icon;
  final SectionType type;

  const InitiativeOptionEnum(this.title, this.icon, this.type);
}

InitiativeOptionEnum? getInitiativeOption(String? title) {
  switch (title) {
    case AppString.goals:
      return InitiativeOptionEnum.goals;
    case AppString.description:
      return InitiativeOptionEnum.description;
    case AppString.vision:
      return InitiativeOptionEnum.vision;
    case AppString.objectives:
      return InitiativeOptionEnum.objectives;
    default:
      return null;
  }
}
