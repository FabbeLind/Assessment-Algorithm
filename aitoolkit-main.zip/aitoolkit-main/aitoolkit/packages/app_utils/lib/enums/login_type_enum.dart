part of 'app_enums.dart';

enum LoginType { apple, google }
