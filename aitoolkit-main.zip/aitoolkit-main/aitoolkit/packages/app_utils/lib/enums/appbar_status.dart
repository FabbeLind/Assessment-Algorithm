part of 'app_enums.dart';

enum AppBarStatus { none, add, view, edit }
