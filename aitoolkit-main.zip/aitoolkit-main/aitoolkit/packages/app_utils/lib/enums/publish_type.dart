part of 'app_enums.dart';

enum PublishType {
  toThisImplementation(AppString.toThisImplementation),
  toAllImplementation(AppString.toAllImplementation);

  final String title;

  const PublishType(this.title);
}

PublishType? getPublishType(String value) {
  switch (value) {
    case AppString.toThisImplementation:
      return PublishType.toThisImplementation;
    case AppString.toAllImplementation:
      return PublishType.toAllImplementation;
    default:
      return null;
  }
}

PublishType getPublishTypeFromIndex(int index) {
  return PublishType.values.firstWhere((element) => element.index == index);
}
