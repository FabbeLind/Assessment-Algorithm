part of 'app_enums.dart';

enum AssessmentOptionType {
  question(AppString.question),
  section(AppString.section);

  final String title;

  const AssessmentOptionType(this.title);
}
