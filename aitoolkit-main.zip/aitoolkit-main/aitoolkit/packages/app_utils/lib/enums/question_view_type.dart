part of 'app_enums.dart';

enum QuestionViewType { point, continueOption, none }
