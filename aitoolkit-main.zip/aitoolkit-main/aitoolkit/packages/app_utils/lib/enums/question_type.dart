part of 'app_enums.dart';

enum QuestionType {
  multipleChoice(AppString.multipleChoice),
  checkBox(AppString.checkBox),
  freeText(AppString.freeText);

  final String title;

  const QuestionType(this.title);
}

QuestionType getQuestionTypeFromIndex(int index) {
  return QuestionType.values.firstWhere((element) => element.index == index);
}
