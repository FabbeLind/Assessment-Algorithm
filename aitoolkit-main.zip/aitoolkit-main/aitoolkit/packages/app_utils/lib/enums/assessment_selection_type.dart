part of 'app_enums.dart';

enum AssessmentValueSelectionType {
  publish(AppString.publish),
  questionType(AppString.questionType),
  options(AppString.options);

  final String title;

  const AssessmentValueSelectionType(this.title);
}
