part of 'app_enums.dart';

enum SectionType {
  text(0),
  list(1);

  final int type;

  const SectionType(this.type);
}
