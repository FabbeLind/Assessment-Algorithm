part of 'app_enums.dart';

enum AnswerActionType {
  section(AppString.section, AppString.nextSection),
  question(AppString.question, AppString.nextQuestion),
  end(AppString.endOfAssessment, AppString.endOfAssessment),
  none("", "");

  final String title;
  final String selectionText;

  const AnswerActionType(this.title, this.selectionText);
}

AnswerActionType getAnswerNextActionTypeByIndex(int index) {
  return AnswerActionType.values.firstWhere((element) => element.index == index);
}
