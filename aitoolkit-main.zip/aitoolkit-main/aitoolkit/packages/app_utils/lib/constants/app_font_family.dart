part of 'constants.dart';

class AppFontFamily {
  static const String epilogue = "Epilogue";
  static const String roboto = "Roboto";
  static const String helveticaNeue = "HelveticaNeue";
}
