import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../app_theme.dart';

part 'app_asset.dart';

part 'app_font_family.dart';

part 'app_string.dart';

part 'app_text_style.dart';

const String kAppName = "AI TOOlKIT";

GlobalKey<NavigatorState> kNavigatorKey = GlobalKey<NavigatorState>();

OverlayEntry? overlayEntry;

List<String> kOptionKeyList = [
  'id',
  'type',
  'index',
  'title',
  'description',
  'questionType',
  'questionPoint',
  'required',
  'image',
  'nextAction',
  'nextUid',
  'answers',
];

// List<String> kAnswerKeyList = [
//   'type',
//   'questionIndex',
//   'index',
//   'answer',
//   'point',
//   'nextIndex',
//   'nextAction',
// ];
