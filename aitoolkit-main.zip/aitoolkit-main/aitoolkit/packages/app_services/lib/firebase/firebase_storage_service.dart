import 'dart:io';

import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/foundation.dart';

class FirebaseStorageService {
  static final FirebaseStorage _instance = FirebaseStorage.instance;
  static const String _assessment = "assessment";

  static final Reference _assessmentRef = _instance.ref().child(_assessment);

  static Future<String> uploadFileInAssessment(
    String filePath,
    String fileName,
  ) async {
    try {
      final uploadTask = await _assessmentRef.child(fileName).putFile(File(filePath));
      String url = await uploadTask.ref.getDownloadURL();
      _printLog("File uploaded successfully -> FileName - $fileName // $url");
      return url;
    } catch (e) {
      _printLog(e);
      rethrow;
    }
  }

  static void _printLog(Object message) {
    debugPrint("FirebaseFirestoreService --->>> $message");
  }
}
