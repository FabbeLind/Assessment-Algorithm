import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';

class FirebaseFirestoreService {
  FirebaseFirestoreService._();

  static final FirebaseFirestore _instance = FirebaseFirestore.instance;
  static late CollectionReference userCollection;
  static late CollectionReference implementationCollection;
  static late CollectionReference globalAssessmentCollection;
  static const String _userKey = 'Users';
  static const String _implementationsKey = 'Implementations';
  static const String _initiativesKey = 'Initiatives';
  static const String _assessmentsKey = 'Assessments';
  static const String _sectionKey = 'Section';
  static const String _reportKey = 'Reports';
  static const String _answerKey = 'Answers';
  static const String _dataKey = 'data';
  static const String _globalAssessmentKey = 'GlobalAssessment';

  static void init() {
    userCollection = _instance.collection(_userKey);
    implementationCollection = _instance.collection(_implementationsKey);
    globalAssessmentCollection = _instance.collection(_globalAssessmentKey);
  }

  static CollectionReference _getInitiativesRef(String implId) {
    return implementationCollection.doc(implId).collection(_initiativesKey);
  }

  static CollectionReference _getAssessmentsRef(String implId) {
    return implementationCollection.doc(implId).collection(_assessmentsKey);
  }

  static CollectionReference _getSectionRef(String implId, String initiativesId) {
    return _getInitiativesRef(implId).doc(initiativesId).collection(_sectionKey);
  }

  static CollectionReference _getReportRef(String implId, String assessmentId) {
    return _getAssessmentsRef(implId).doc(assessmentId).collection(_reportKey);
  }

  static CollectionReference _getAnswerRef(String implId, String assessmentId, String reportId) {
    return _getAssessmentsRef(implId).doc(assessmentId).collection(_reportKey).doc(reportId).collection(_answerKey);
  }

  static CollectionReference _getSectionDataRef(String implId, initiativesId, String sectionId) {
    return _getSectionRef(implId, initiativesId).doc(sectionId).collection(_dataKey);
  }

  static Future<List<Map<String, dynamic>>> getAssessmentList(String implId) async {
    try {
      List<Map<String, dynamic>> assessmentData = [];
      QuerySnapshot assessmentSnapshot = await _getAssessmentsRef(implId).get();
      for (var element in assessmentSnapshot.docs) {
        assessmentData.add(element.data() as Map<String, dynamic>);
      }
      _printLog("Assessment fetched successfully : ${assessmentData.length}");
      return assessmentData;
    } catch (e) {
      rethrow;
    }
  }

  static Future<void> addImplementation(String userId, Map<String, dynamic> implMap) async {
    try {
      DocumentReference implDocRef = await implementationCollection.add(<String, dynamic>{});
      assert(implDocRef.id.isNotEmpty && implMap.isNotEmpty);
      implMap.update("id", (value) => implDocRef.id);
      await implementationCollection.doc(implDocRef.id).set(implMap);
      _printLog("Implementation added successfully");
    } catch (e, st) {
      _printLog("Error while setImplementation call : $e $st");
      rethrow;
    }
  }

  static Future<void> updateImplementation(String implId, Map<String, dynamic> implMap) async {
    try {
      await implementationCollection.doc(implId).update(implMap);
      _printLog("Implementation updated successfully");
    } catch (e, st) {
      _printLog("Error while setImplementation call : $e $st");
      rethrow;
    }
  }

  static Future<void> setUser(String userId, Map<String, dynamic> userMap) async {
    try {
      await userCollection.doc(userId).set(userMap);
      _printLog('setUser successfully');
    } catch (e, st) {
      _printLog('setUser Error: $e $st');
      rethrow;
    }
  }

  static Future<void> updateUser(String userId, Map<String, dynamic> userMap) async {
    try {
      await userCollection.doc(userId).update(userMap);
      _printLog('updateUser successfully');
    } catch (e, st) {
      _printLog('updateUser Error: $e $st');
      rethrow;
    }
  }

  static Future<void> setImplementations(String implId, Map<String, dynamic> implMap) async {
    try {
      await implementationCollection.doc(implId).set(implMap);
      _printLog('setImplementations successfully');
    } catch (e, st) {
      _printLog('setImplementations Error: $e $st');
      rethrow;
    }
  }

  static Future<void> updateImplementations(String implId, Map<String, dynamic> implMap) async {
    try {
      await implementationCollection.doc(implId).update(implMap);
      _printLog('updateImplementations successfully');
    } catch (e, st) {
      _printLog('updateImplementations Error: $e $st');
      rethrow;
    }
  }

  static Future<String> addInitiatives(String implId, {Map<String, dynamic> initiativesMap = const {}}) async {
    CollectionReference initiativeCollection = _getInitiativesRef(implId);
    try {
      _printLog('addInitiatives start');
      DocumentReference initiativeDocRef = await initiativeCollection.add(<String, dynamic>{});
      _printLog('addInitiatives initiativeDocRef ${initiativeDocRef.id}');
      assert(initiativeDocRef.id.isNotEmpty && initiativesMap.isNotEmpty);
      initiativesMap.update('id', (value) => initiativeDocRef.id);

      await initiativeCollection.doc(initiativeDocRef.id).set(initiativesMap);
      _printLog('addInitiatives successfully ${initiativeDocRef.id}');
      return initiativeDocRef.id;
    } catch (e, st) {
      _printLog('addInitiatives Error: $e $st');
      rethrow;
    }
  }

  static Future<List<QueryDocumentSnapshot>> getInitiatives(String implId, {String searchText = ''}) async {
    CollectionReference initiativeCollection = _getInitiativesRef(implId);
    try {
      Future<QuerySnapshot<Object?>> futureInitiativeData;
      if (searchText.isNotEmpty) {
        futureInitiativeData = initiativeCollection.where("title", isEqualTo: searchText).get();
      } else {
        futureInitiativeData = initiativeCollection.get();
      }
      var initiativeData = await futureInitiativeData;
      if (initiativeData.docs.isNotEmpty) {
        return initiativeData.docs;
      }
      _printLog('getInitiatives successfully ${initiativeData.docs.length}');
      return [];
    } catch (e, st) {
      _printLog('getInitiatives Error $e $st');
      rethrow;
    }
  }

  static Future<void> updateInitiatives(
      {required String implId, required String initiativesId, Map<String, dynamic> initiativesMap = const {}}) async {
    CollectionReference initiativeCollection = _getInitiativesRef(implId);
    try {
      assert(initiativesId.isNotEmpty);
      await initiativeCollection.doc(initiativesId).update(initiativesMap);
      _printLog('updateInitiatives successfully ${initiativeCollection.id}');
    } catch (e, st) {
      _printLog('updateInitiatives Error: $e $st');
      rethrow;
    }
  }

  static Future<void> deleteInitiatives({
    required String implId,
    required String initiativesId,
  }) async {
    try {
      CollectionReference initiativeCollection = _getInitiativesRef(implId);

      assert(initiativesId.isNotEmpty);
      await initiativeCollection.doc(initiativesId).delete();
      _printLog('updateInitiatives successfully ${initiativeCollection.id}');
    } catch (e, st) {
      _printLog('updateInitiatives Error: $e $st');
      rethrow;
    }
  }

  static Future<String> addInitiativesSection(
    String implId,
    String initiativesId, {
    Map<String, dynamic> sectionMap = const {},
    String dataText = '',
    List<Map<String, dynamic>> dataTextList = const [],
  }) async {
    CollectionReference sectionCollection = _getSectionRef(implId, initiativesId);
    try {
      DocumentReference sectionDocRef = await sectionCollection.add(<String, dynamic>{});

      _printLog('addInitiativesSection: ${sectionDocRef.id} $sectionMap');
      assert(sectionDocRef.id.isNotEmpty && sectionMap.isNotEmpty);
      sectionMap.update('id', (value) => sectionDocRef.id);
      await sectionCollection.doc(sectionDocRef.id).set(sectionMap);

      if (dataText.isNotEmpty || dataTextList.isNotEmpty) {
        await addSectionData(
          implId: implId,
          initiativesId: initiativesId,
          sectionId: sectionDocRef.id,
          dataText: dataText,
          dataTextList: dataTextList,
        );
      }
      _printLog('addInitiativesSection successfully ${sectionCollection.id}');
      return sectionCollection.id;
    } catch (e, st) {
      _printLog('addInitiativesSection Error: $e $st');
      rethrow;
    }
  }

  static Future<List<Map<String, dynamic>>> getInitiativesSection(String implId, String initiativesId) async {
    try {
      QuerySnapshot sectionRef = await _getSectionRef(implId, initiativesId).get();

      _printLog('getInitiativesSection successfully ${sectionRef.docs.length}');
      return sectionRef.docs.map((e) => e.data() as Map<String, dynamic>).toList();
    } catch (e, st) {
      _printLog('getInitiativesSection Error $e $st');
      rethrow;
    }
  }

  static Future<void> updateInitiativesSection({
    required String implId,
    required String initiativesId,
    required String sectionId,
    Map<String, dynamic> sectionMap = const {},
    String dataText = '',
    List<Map<String, dynamic>> dataTextList = const [],
  }) async {
    try {
      _printLog('updateInitiativesSection sectionId: $sectionId');
      if (sectionId.isEmpty) {
        await deleteInitiativesSection(implId: implId, initiativesId: initiativesId, section: [sectionMap["title"]]);
        await addInitiativesSection(implId, initiativesId,
            sectionMap: sectionMap, dataText: dataText, dataTextList: dataTextList);
        return;
      } else {
        await deleteSectionData(implId: implId, initiativesId: initiativesId, sectionId: sectionId);

        await addSectionData(
          implId: implId,
          initiativesId: initiativesId,
          sectionId: sectionId,
          dataText: dataText,
          dataTextList: dataTextList,
        );
      }
      var sectionCollection = _getSectionRef(implId, initiativesId).doc(sectionId);
      _printLog('updateInitiativesSection  sectionMap: $sectionMap');
      _printLog('updateInitiativesSection  data: $dataText $dataTextList');

      await sectionCollection.update(sectionMap);
      _printLog('updateInitiativesSection successfully ${sectionCollection.id}');
    } catch (e, st) {
      _printLog('updateInitiativesSection Error: $e $st');
      rethrow;
    }
  }

  static Future<void> deleteInitiativesSection({
    required String implId,
    required String initiativesId,
    List<String> section = const [],
  }) async {
    var sectionCollection = _getSectionRef(implId, initiativesId);
    try {
      _printLog('updateInitiativesSection section $section');
      QuerySnapshot querySnapshot = await sectionCollection.where('title', whereIn: section).get();
      if (querySnapshot.docs.isNotEmpty) {
        for (var element in querySnapshot.docs) {
          await sectionCollection.doc(element.id).delete();
          _printLog('updateInitiativesSection delete ${element.id}');
        }
      }
      _printLog('updateInitiativesSection successfully ${querySnapshot.docs}');
    } catch (e, st) {
      _printLog('updateInitiativesSection Error: $e $st');
      rethrow;
    }
  }

  static Future<void> addSectionData({
    required String implId,
    required String initiativesId,
    required String sectionId,
    String dataText = '',
    List<Map<String, dynamic>> dataTextList = const [],
  }) async {
    CollectionReference sectionDataCollection = _getSectionDataRef(implId, initiativesId, sectionId);
    try {
      if (dataTextList.isNotEmpty) {
        for (var task in dataTextList) {
          sectionDataCollection.add(task);
        }
      } else {
        sectionDataCollection.add({"text": dataText});
      }
      _printLog('addSectionData successfully ${sectionDataCollection.id}');
    } catch (e, st) {
      _printLog('addSectionData Error: $e $st');
      rethrow;
    }
  }

  static Future<List<Map<String, dynamic>>> getSectionData(
      String implId, String initiativesId, String sectionId) async {
    try {
      QuerySnapshot sectionDataRef = await _getSectionDataRef(implId, initiativesId, sectionId).get();
      _printLog('getSectionData successfully ${sectionDataRef.docs.length}');

      return sectionDataRef.docs.map((e) => e.data() as Map<String, dynamic>).toList();
    } catch (e, st) {
      _printLog('getSectionData Error $e $st');
      rethrow;
    }
  }

  static Future<void> deleteSectionData({
    required String implId,
    required String initiativesId,
    required String sectionId,
    String dataText = '',
    List<Map<String, dynamic>> dataTextList = const [],
  }) async {
    CollectionReference sectionDataCollection = _getSectionDataRef(implId, initiativesId, sectionId);
    try {
      QuerySnapshot sectionDataRef = await sectionDataCollection.get();
      if (sectionDataRef.docs.isNotEmpty) {
        for (var element in sectionDataRef.docs) {
          await sectionDataCollection.doc(element.id).delete();
          _printLog('deleteSectionData successfully sectionId: $sectionId sectionDataId: ${element.id}');
        }
      }
    } catch (e, st) {
      _printLog('addSectionData Error: $e $st');
      rethrow;
    }
  }

  static Future<Map<String, dynamic>?> addAssessmentReport({
    required String implId,
    required String assessmentId,
    required Map<String, dynamic> reportMap,
  }) async {
    try {
      CollectionReference reportCollection = _getReportRef(implId, assessmentId);
      DocumentReference reportDocRef = await reportCollection.add(<String, dynamic>{});
      assert(reportMap.isNotEmpty);
      reportMap.update('id', (value) => reportDocRef.id);
      await reportCollection.doc(reportDocRef.id).set(reportMap);
      final reportData =
          await getAssessmentReport(implId: implId, assessmentId: assessmentId, reportId: reportDocRef.id);
      return reportData;
    } catch (e, st) {
      _printLog('Add report Error: $e $st');
      rethrow;
    }
  }

  static Future<Map<String, dynamic>?> getAssessmentReport({
    required String implId,
    required String assessmentId,
    required String reportId,
  }) async {
    try {
      CollectionReference reportCollection = _getReportRef(implId, assessmentId);
      DocumentSnapshot reportData = await reportCollection.doc(reportId).get();
      if (reportData.exists) {
        return reportData.data() as Map<String, dynamic>;
      }
      return null;
    } catch (e, st) {
      _printLog("Assessment already reported: $e $st");
      rethrow;
    }
  }

  static Future<Map<String, dynamic>?> updateAssessmentReport({
    required String implId,
    required String assessmentId,
    required String reportId,
    required Map<String, dynamic> reportMap,
  }) async {
    try {
      CollectionReference reportCollection = _getReportRef(implId, assessmentId);
      if (reportMap.isNotEmpty) {
        await reportCollection.doc(reportId).update(reportMap);
        final updatedReport = await getAssessmentReport(implId: implId, assessmentId: assessmentId, reportId: reportId);
        return updatedReport;
      }
      return null;
    } catch (e, st) {
      _printLog("Assessment already reported: $e $st");
      rethrow;
    }
  }

  static Future<Map<String, dynamic>?> getAssessmentReportByUserId({
    required String userId,
    required String implId,
    required String assessmentId,
  }) async {
    try {
      CollectionReference reportCollection = _getReportRef(implId, assessmentId);
      QuerySnapshot reportData = await reportCollection.where("createdBy", isEqualTo: userId).get();
      if (reportData.size > 0) {
        return reportData.docs.first.data() as Map<String, dynamic>;
      }
      return null;
    } catch (e, st) {
      _printLog("Assessment already reported: $e $st");
      rethrow;
    }
  }

  static Future<Map<String, dynamic>> addAssessmentAnswer({
    required String implId,
    required String assessmentId,
    required String reportId,
    required Map<String, dynamic> answerMap,
  }) async {
    try {
      CollectionReference answerCollection = _getAnswerRef(implId, assessmentId, reportId);
      assert(answerMap.isNotEmpty);
      DocumentReference answerDocRef = await answerCollection.add(<String, dynamic>{});
      answerMap.update('id', (value) => answerDocRef.id);
      await answerDocRef.set(answerMap);
      final updatedAnswer = await getAssessmentAnswer(
        implId: implId,
        assessmentId: assessmentId,
        reportId: reportId,
        answerId: answerDocRef.id,
      );
      return updatedAnswer;
    } catch (e, st) {
      _printLog('Add report Error: $e $st');
      rethrow;
    }
  }

  static Future<Map<String, dynamic>> updateAssessmentAnswer({
    required String implId,
    required String assessmentId,
    required String reportId,
    required String answerId,
    required Map<String, dynamic> updatedAnswerMap,
  }) async {
    try {
      CollectionReference answerCollection = _getAnswerRef(implId, assessmentId, reportId);
      assert(updatedAnswerMap.isNotEmpty);
      await answerCollection.doc(answerId).update(updatedAnswerMap);
      final updatedAnswer = await getAssessmentAnswer(
        implId: implId,
        assessmentId: assessmentId,
        reportId: reportId,
        answerId: answerId,
      );
      return updatedAnswer;
    } catch (e, st) {
      _printLog('Add report Error: $e $st');
      rethrow;
    }
  }

  static Future<Map<String, dynamic>> getAssessmentAnswer({
    required String implId,
    required String assessmentId,
    required String reportId,
    required String answerId,
  }) async {
    try {
      CollectionReference answerCollection = _getAnswerRef(implId, assessmentId, reportId);
      DocumentSnapshot answerData = await answerCollection.doc(answerId).get();
      return answerData.data() as Map<String, dynamic>;
    } catch (e, st) {
      _printLog('Add report Error: $e $st');
      rethrow;
    }
  }

  static Future<List<Map<String, dynamic>>> getAssessmentAnswerList({
    required String implId,
    required String assessmentId,
    required String reportId,
  }) async {
    try {
      List<Map<String, dynamic>> answerDataList = [];
      CollectionReference answerCollection = _getAnswerRef(implId, assessmentId, reportId);
      QuerySnapshot answerData = await answerCollection.get();
      if (answerData.docs.isNotEmpty) {
        for (var element in answerData.docs) {
          answerDataList.add(element.data() as Map<String, dynamic>);
        }
      }
      return answerDataList;
    } catch (e, st) {
      _printLog("Assessment already reported: $e $st");
      rethrow;
    }
  }

  static Future<void> deleteAssessmentAnswer({
    required String implId,
    required String assessmentId,
    required String reportId,
    required String answerId,
  }) async {
    try {
      CollectionReference answerCollection = _getAnswerRef(implId, assessmentId, reportId);
      await answerCollection.doc(answerId).delete();
    } catch (e, st) {
      _printLog("Assessment already reported: $e $st");
      rethrow;
    }
  }

  static Future<void> deleteAssessmentAnswerList({
    required String implId,
    required String assessmentId,
    required String reportId,
    required Map<String, dynamic> updateReportMap,
  }) async {
    try {
      CollectionReference answerCollection = _getAnswerRef(implId, assessmentId, reportId);
      QuerySnapshot answerData = await answerCollection.get();
      if (answerData.docs.isNotEmpty) {
        for (var element in answerData.docs) {
          await deleteAssessmentAnswer(
            implId: implId,
            assessmentId: assessmentId,
            reportId: reportId,
            answerId: element.id,
          );
        }
      }
      await _getReportRef(implId, assessmentId).doc(reportId).update(updateReportMap);
    } catch (e, st) {
      _printLog("Assessment already reported: $e $st");
      rethrow;
    }
  }

  static Future<String?> answerAlreadyExist(
      {required String implId, required String assessmentId, required String reportId, required int index}) async {
    try {
      QuerySnapshot answerData =
          await _getAnswerRef(implId, assessmentId, reportId).where("index", isEqualTo: index).get();
      if (answerData.size > 0) {
        return answerData.docs.first.id;
      }
      return null;
    } catch (e) {
      rethrow;
    }
  }

  static Future<Map<String, dynamic>?> getAssessment({
    required String implId,
    required String assessmentId,
  }) async {
    try {
      CollectionReference assessmentCollection = _getAssessmentsRef(implId);
      var assessmentData = await assessmentCollection.doc(assessmentId).get();
      if (assessmentData.data() != null) {
        return assessmentData.data() as Map<String, dynamic>;
      } else {
        return null;
      }
    } catch (e, st) {
      _printLog("Error on adding assessment : $e $st");
      rethrow;
    }
  }

  static Future<String> addAssessment({required String implId, required Map<String, dynamic> assessmentMap}) async {
    try {
      CollectionReference assessmentCollection = _getAssessmentsRef(implId);
      DocumentReference assessmentDocRef = await assessmentCollection.add(<String, dynamic>{});
      assert(assessmentMap.isNotEmpty);
      assessmentMap.update('id', (value) => assessmentDocRef.id);
      await assessmentCollection.doc(assessmentDocRef.id).set(assessmentMap);
      return assessmentDocRef.id;
    } catch (e, st) {
      _printLog("Error on adding assessment : $e $st");
      rethrow;
    }
  }

  static Future<void> updateAssessment({
    required String implId,
    required String assessmentId,
    required Map<String, dynamic> updatedAssessmentMap,
  }) async {
    try {
      CollectionReference assessmentCollection = _getAssessmentsRef(implId);
      assert(updatedAssessmentMap.isNotEmpty);
      await assessmentCollection.doc(assessmentId).update(updatedAssessmentMap);
    } catch (e, st) {
      _printLog("Error on adding assessment : $e $st");
      rethrow;
    }
  }

  static Future<void> deleteAssessment({
    required String implId,
    required String assessmentId,
  }) async {
    try {
      CollectionReference assessmentCollection = _getAssessmentsRef(implId);
      await assessmentCollection.doc(assessmentId).delete();
      final reportDoc = await _getReportRef(implId, assessmentId).get();
      if (reportDoc.docs.isNotEmpty) {
        for (var report in reportDoc.docs) {
          final answerDoc = await _getAnswerRef(implId, assessmentId, report.id).get();
          for (var answer in answerDoc.docs) {
            await answer.reference.delete();
          }
          await report.reference.delete();
        }
      }
    } catch (e, st) {
      _printLog("Error on adding assessment : $e $st");
      rethrow;
    }
  }

  static Future<void> updateAssessmentProgress({
    required String implId,
    required String assessmentId,
    required String userId,
    required Map<String, dynamic> progress,
  }) async {
    try {
      CollectionReference assessmentCollection = _getAssessmentsRef(implId);
      await assessmentCollection.doc(assessmentId).update({"progress.$userId": progress});
    } catch (e, st) {
      _printLog("Error on updating assessment progress : $e $st");
      rethrow;
    }
  }

  static Future<List<Map<String, dynamic>>> getGlobalAssessmentList() async {
    try {
      List<Map<String, dynamic>> globalAssessmentList = [];
      QuerySnapshot globalAssessmentSnapshot = await globalAssessmentCollection.get();
      for (var element in globalAssessmentSnapshot.docs) {
        var globalAssessment = element.data() as Map<String, dynamic>;
        Map<String,dynamic>? assessmentData = await getAssessment(
          implId: globalAssessment["implementationId"],
          assessmentId: globalAssessment["assessmentId"],
        );
        if(assessmentData != null){
          globalAssessmentList.add(assessmentData);
        }
      }
      _printLog("Global assessment fetched successfully : ${globalAssessmentList.length}");
      return globalAssessmentList;
    } catch (e, st) {
      _printLog("Error on fetching global AssessmentList : $e $st");
      rethrow;
    }
  }

  static Future<void> addGlobalAssessment({
    required String implementationId,
    required String assessmentId,
  }) async {
    try {
      bool isAssessmentGlobal = await checkAssessmentIsGlobal(assessmentId: assessmentId);
      if (!isAssessmentGlobal) {
        await globalAssessmentCollection.doc(assessmentId).set({
          "implementationId": implementationId,
          "assessmentId": assessmentId,
        });
      }
    } catch (e, st) {
      _printLog("Error on adding global assessment : $e $st");
    }
  }

  static Future<void> deleteGlobalAssessment({required String assessmentId}) async {
    try {
      bool isAssessmentGlobal = await checkAssessmentIsGlobal(assessmentId: assessmentId);
      if (isAssessmentGlobal) {
        await globalAssessmentCollection.doc(assessmentId).delete();
      }
    } catch (e, st) {
      _printLog("Error on deleting global assessment : $e $st");
    }
  }

  static Future<bool> checkAssessmentIsGlobal({required String assessmentId}) async {
    try {
      bool isGlobal = false;
      final assessmentList = await globalAssessmentCollection.where("assessmentId", isEqualTo: assessmentId).get();
      if (assessmentList.size > 0) {
        isGlobal = true;
      }
      return isGlobal;
    } catch (e, st) {
      _printLog("Error on checking assessment is global : $e $st");
      rethrow;
    }
  }

  static void _printLog(String message) {
    debugPrint("## FirebaseFirestoreService $message");
  }
}
