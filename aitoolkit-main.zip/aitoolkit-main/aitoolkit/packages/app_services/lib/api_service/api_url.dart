class ApiUrl {
  static const String addRecord = "Create-User-Record";
  static const String getRecords = "Find-User-Detail";
  static const String getUserMarker = "find-user-records";
  static const String getMarkerThreshold = "threashold";
  static const String getViewPoint = "find-view-point";
  static const String addViewPoint = "create-view-point";
  static const String startStage = "title/create-folder";
  static const String getStage = "title/find-folder";
  static const String deleteStage = "title/delete-folder";
  static const String getViewPointById = "find-title-view-point?titleId=";
}
