import 'dart:convert';
import 'dart:developer';

import 'package:dartz/dartz.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:http_interceptor/http_interceptor.dart';

Future<Map<String, String>> headers({
  required bool contentType,
  required bool bearerToken,
}) async {
  final Map<String, String> headers = <String, String>{};
  headers["accept"] = "*/*";
  if (contentType) headers["Content-Type"] = "application/json";
  // if (bearerToken ?? true && Preferences.getAuth() == true) {
  //   headers["Authorization"] = 'Bearer ${Preferences.getToken()}';
  // }
  debugPrint("header: ${headers.toString()}");

  return headers;
}

class NetworkAPICall {
  static final NetworkAPICall _networkAPICall = NetworkAPICall._internal();

  factory NetworkAPICall() {
    return _networkAPICall;
  }

  static bool connectionStatus = true;

  static bool connectionStatus404 = true;

  static http.Client get httpClient => InterceptedClient.build(
        interceptors: [
          LoggerInterceptor(),
        ],
        retryPolicy: ExpiredTokenRetryPolicy(),
      );

  NetworkAPICall._internal();

  Future<Either<dynamic, String>> get({
    required String endpoint,
    Map<String, dynamic>? queryData,
    bool contentType = false,
    bool bearerToken = false,
  }) async {
    try {
      final Uri fullURL = getUrl(
        endpoint,
        queryParameters: queryData,
      );

      log('API Url --->>> ${fullURL.path}');

      final response = await httpClient
          .get(
        fullURL,
        headers: await headers(
          contentType: contentType,
          bearerToken: bearerToken,
        ),
      )
          .timeout(
        const Duration(seconds: 30),
        onTimeout: () {
          return http.Response('Error', 408); // Request Timeout response status code
        },
      );
      log('Response status: ${response.statusCode}');
      log('Response body: ${response.body}');
      return checkResponse(response);
    } catch (e) {
      if (e.toString() == "Connection failed" || e.toString().contains("Failed host lookup")) {
        connectionStatus = false;
        // connectionStatus404  = false;
        debugPrint("connectionStatus ---> $connectionStatus");
      } else {
        connectionStatus = true;
        // connectionStatus404  = true;
      }
      httpClient.close();
      return Right(e.toString());
    }
  }

  Future<Either<dynamic, String>> post(
    String endpoint, {
    required Map<String, dynamic> body,
    Map<String, dynamic>? queryData,
    bool contentType = false,
    bool bearerToken = false,
    Map<String, String>? header,
  }) async {
    try {
      final Uri fullURL = getUrl(
        endpoint,
        queryParameters: queryData,
      );

      log('API Url --->>> ${fullURL.path}');
      log('body --->>> $body');
      final data = jsonEncode(body);
      final response = await httpClient
          .post(
        fullURL,
        body: data,
        headers: header ??
            await headers(
              contentType: contentType,
              bearerToken: bearerToken,
            ),
      )
          .timeout(
        const Duration(seconds: 30),
        onTimeout: () {
          // Time has run out, do what you wanted to do.
          return http.Response('Error', 408); // Request Timeout response status code
        },
      );

      print('Response status --->>> ${response.statusCode}');

      print("Response body 11 ---> ${response.body}");

      return checkResponse(response);
    } catch (e, st) {
      debugPrint("network error--->$e --- $st");
      debugPrint("network error1--->${e.toString()}");
      if (e.toString() == "Connection failed" || e.toString().contains("Failed host lookup")) {
        connectionStatus = false;
        debugPrint("connectionStatus --->$connectionStatus");
      } else {
        connectionStatus = true;
      }
      httpClient.close();
      return right(e.toString());
    }
  }

  Future<Either<dynamic, String>> put(
    String endpoint, {
    dynamic body,
    Map<String, dynamic>? queryData,
    bool contentType = false,
    bool bearerToken = false,
  }) async {
    try {
      final Uri fullURL = getUrl(
        endpoint,
        queryParameters: queryData,
      );

      log('API Url --->>> ${fullURL.path}');
      log('body --->>> $body');

      final data = jsonEncode(body);
      final response = await httpClient
          .put(
        fullURL,
        body: data,
        headers: await headers(
          contentType: contentType,
          bearerToken: bearerToken,
        ),
      )
          .timeout(
        const Duration(seconds: 30),
        onTimeout: () {
          // Time has run out, do what you wanted to do.
          return http.Response('Error', 408); // Request Timeout response status code
        },
      );

      // log('Response status: ${response.statusCode}');
      // log('Response body: ${response.body.toString()}');

      return Left(checkResponse(response));
    } catch (e) {
      if (e.toString() == "Connection failed" || e.toString().contains("Failed host lookup")) {
        connectionStatus = false;
        debugPrint("connectionStatus --->$connectionStatus");
      } else {
        connectionStatus = true;
      }
      httpClient.close();
      return Right(e.toString());
    }
  }

  Future<Either<dynamic, String>> delete({
    required String endpoint,
    dynamic body,
    Map<String, dynamic>? queryData,
    bool contentType = false,
    bool bearerToken = false,
  }) async {
    try {
      final Uri fullURL = getUrl(
        endpoint,
        queryParameters: queryData,
      );

      log('API Url --->>> ${fullURL.path}');
      log('body --->>> $body');

      final data = jsonEncode(body);

      final response = await httpClient
          .delete(
        fullURL,
        headers: await headers(
          contentType: contentType,
          bearerToken: bearerToken,
        ),
        body: data,
      )
          .timeout(
        const Duration(seconds: 10),
        onTimeout: () {
          return http.Response('Error', 408); // Request Timeout response status code
        },
      );
      return Left(checkResponse(response));
    } catch (e) {
      httpClient.close();
      return Right(e.toString());
    }
  }

  Future<Either<dynamic, String>> patch(
    String endpoint, {
    Map<String, dynamic>? queryData,
    Map<String, dynamic>? body,
    bool contentType = false,
    bool bearerToken = false,
  }) async {
    try {
      final Uri fullURL = getUrl(endpoint, queryParameters: queryData);
      debugPrint('API Url: $fullURL');
      log("bodyData $body");

      final data = jsonEncode(body);

      final response = await httpClient.patch(
        fullURL,
        body: data,
        headers: await headers(
          contentType: contentType,
          bearerToken: bearerToken,
        ),
      );
      log("response.statusCode ${response.statusCode} ${response.body}");
      return Left(checkResponse(response));
    } catch (e, st) {
      log("patch error:- $e  ==== $st");
      return Right(e.toString());
    }
  }

  Future<Either<dynamic, String>> postMultipartRequest(
    String endpoint, {
    Map<String, dynamic>? queryData,
    Map<String, String>? body,
    Map<String, String>? headerData,
    List<String>? images,
    String? imageKey,
    bool contentType = false,
    bool bearerToken = false,
  }) async {
    // String url = "${ApiConstant.baseUrl}$endpoint";
    String url = endpoint;
    try {
      var request = http.MultipartRequest('POST', Uri.parse(url));

      request.headers.addAll(headerData ??
          await headers(
            contentType: contentType,
            bearerToken: bearerToken,
          ));

      request.fields.addAll(body ?? {});

      try {
        for (int i = 0; i < (images?.length ?? 0); i++) {
          log("Uploading image --->>> ${images?[i]}");
          request.files.add(
            await http.MultipartFile.fromPath(
              imageKey ?? "file",
              images?[i] ?? "",
            ),
          );
        }
      } catch (e, st) {
        log("Error while uploading image --->>> $e \n $st");
      }

      http.StreamedResponse response = await request.send();

      log("Response data --->>> ${response.statusCode} ::: ${request.fields.toString()} ::: ${response.reasonPhrase}");

      if (response.statusCode == 200 || response.statusCode == 201) {
        String jsonDataString = await response.stream.bytesToString();
        final jsonData = jsonDecode(jsonDataString);
        return Left(jsonData);
      } else {
        return Right("${response.statusCode} - Something went wrong!");
      }
    } catch (exception, stackTrace) {
      debugPrint("Error while sending multipart data --->>> $exception \n $stackTrace");
      return Right(exception.toString());
    }
  }

  Uri getUrl(String endpoint, {Map<String, dynamic>? queryParameters}) {
    // String url = "${ApiConstant.baseUrl}$endpoint";
    String url = endpoint;
    if (queryParameters != null && queryParameters.isNotEmpty) {
      url = "$url?";
      for (int i = 0; i < queryParameters.entries.length; i++) {
        final element = queryParameters.entries.elementAt(i);
        url += '${element.key}=${element.value}';
        if (i < queryParameters.entries.length - 1) {
          url += '&';
        }
      }
    }
    log(Uri.parse(url).toString());
    return Uri.parse(url);
  }

  Either<dynamic, String> checkResponse(http.Response? response) {
    try {
      if (response != null) {
        switch (response.statusCode) {
          case 200:
            try {
              if (response.body.isEmpty) {
                return left("");
              } else {
                return left(jsonDecode(response.body));
              }
            } catch (e, st) {
              log("response status code 200 error : $e :::: $st");
              rethrow;
            }
          case 201:
            try {
              return Left(jsonDecode(response.body));
              // return response;
            } catch (e, st) {
              log("response status code 201 error : $e :::: $st");
              rethrow;
            }
          case 400:
            return right(jsonDecode(response.body)["message"]);
          // throw AppException(message: jsonDecode(response.body)['apierror']['description'], errorCode: 0);
          // default:
          //   try {
          //     if (response.body.isEmpty) {
          //       throw AppException(message: 'Response body is empty', errorCode: response.statusCode);
          //     }
          //     jsonDecode(response.body);
          //   } catch (e) {
          //     rethrow;
          //   }
          case 404:
            connectionStatus404 = false;
            return Right(jsonDecode(response.body)["message"]);
          case 403:
            return Right(jsonDecode(response.body)["message"]);
          case 422:
            return Right(jsonDecode(response.body)["message"]);
          case 401:

            ///open it if is it suitable place
            // await _authenticationController.refreshToken();
            return Right(jsonDecode(response.body)["message"]);
          case 500:
            return Right(jsonDecode(response.body)["message"]);
          default:
            return const Right("Unknown Error occurred. Please try again!");
        }
      } else {
        return const Right("Unknown Error occurred. Please try again!");
      }
    } catch (e) {
      return const Right("Unknown Error occurred. Please try again!");
    }
  }

/*dynamic checkResponse(http.Response response) {
    try {
      if (response.body.isEmpty) {
        throw AppException(message: 'Response body is empty', errorCode: 0);
      }
      final json = jsonDecode(utf8.decode(response.bodyBytes));
      bool isSuccess = true;
      try {
        isSuccess = json['success'] ?? false;
      } catch (e) {
        log(e.toString());
      }
      if (response.statusCode == 200) {
        isSuccess = true;
      }
      if (response.statusCode == 201) {
        isSuccess = true;
      }
      if (response.statusCode == 500) {
        // throw ToastUtils.Toast(json["error"]["message"],
        //     toastColor: AppColors.primaryColor);
      }
      if (response.statusCode == 400) {
        // throw ToastUtils.Toast(json["error"]["message"],
        //     toastColor: AppColors.primaryColor);
      }
      if (response.statusCode == 401) {
        // throw ToastUtils.Toast(json["error"]["message"],
        //     toastColor: AppColors.primaryColor);
      }

      return json;
    } catch (e) {
      rethrow;
    }
  }*/
}

class LoggerInterceptor implements InterceptorContract {
  @override
  Future<http.BaseRequest> interceptRequest({required http.BaseRequest request}) async {
    debugPrint(request.toString());
    return request;
  }

  @override
  Future<bool> shouldInterceptRequest() async {
    return true;
  }

  @override
  Future<bool> shouldInterceptResponse() async {
    return true;
  }

  @override
  Future<http.BaseResponse> interceptResponse({required http.BaseResponse response}) async {
    if (response.statusCode == 401) {}
    return response;
  }
}

class ExpiredTokenRetryPolicy extends RetryPolicy {
  @override
  int get maxRetryAttempts => 2;

  @override
  Future<bool> shouldAttemptRetryOnResponse(http.BaseResponse response) async {
    if (response.statusCode == 401) {
      ///token expire to call
      return true;
    }
    return false;
  }
}
