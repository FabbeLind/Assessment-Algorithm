import 'package:flutter/material.dart';
import 'package:gsheets/gsheets.dart';

class SheetService {
  static Future<void> init(String credential) async {
    _gSheet = GSheets(credential);
  }

  static late final GSheets _gSheet;
  static late Worksheet _worksheet;

  static Future<void> setSheet({
    required String spreadsheetId,
    required String workSheetTitle,
  }) async {
    try {
      final spreadSheet = await _gSheet.spreadsheet(spreadsheetId);
      var worksheet = spreadSheet.worksheetByTitle(workSheetTitle);
      if (worksheet != null) {
        _worksheet = worksheet;
      } else {
        _worksheet = await spreadSheet.addWorksheet(workSheetTitle);
      }
    } catch (e) {
      _printLog("setWorkSheet worksheet error --->>> $e");
      rethrow;
    }
  }

  static Future<List<List<String>>> getSheet({
    required String spreadsheetId,
    required int workSheetId,
  }) async {
    try {
      final spreadSheet = await _gSheet.spreadsheet(spreadsheetId);
      var worksheet = spreadSheet.worksheetById(workSheetId);
      if (worksheet != null) {
        return await worksheet.values.allRows();
      } else {
        throw Error.safeToString("No worksheet found with this id");
      }
    } catch (e) {
      _printLog("setWorkSheet worksheet error --->>> $e");
      rethrow;
    }
  }

  static Future<void> clearSheet() async => await _worksheet.clear();

  static Future<void> addEmptyRow() async => await _worksheet.values.appendRow([" "]);

  static Future<void> addRowMap(Map<String, dynamic> map) async {
    try {
      await _worksheet.values.map.appendRow(map);
    } catch (e) {
      rethrow;
    }
  }

  static Future<void> addRowList(List<dynamic> list) async {
    try {
      await _worksheet.values.appendRow(list);
    } catch (e) {
      rethrow;
    }
  }

  static void _printLog(Object message) {
    debugPrint("GoogleSheetService --->>> $message");
  }
}
